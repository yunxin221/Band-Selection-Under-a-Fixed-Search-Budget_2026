"""T10 deep-baseline driver: does band selection survive a modern spatial-spectral model?

This is the reduced "(a)" half of M-P2-1. It deliberately does **not** put a
deep model into the manuscript's main accuracy table -- there it would simply
outscore the hand-crafted pipeline and hand the reviewer a stick to beat the
paper with. Instead it answers one question the reviewers actually raised
(Reviewer 1 M9: no comparison against post-2020 spatial-spectral models):

    Do the 4 bands our optimiser picked also work for a modern 3-D/2-D CNN, or
    are they an artefact of the EM/SRF/RV + KNN pipeline?

Two configurations are trained on the **identical splits** used elsewhere in the
paper, which is what makes the comparison fair:

  full   -- all B bands reduced by PCA to ``--pca`` components  (HybridSN as published)
  sel4   -- only the k selected bands                            (spectral branch collapses)

Reported together, the pair yields the argument the manuscript needs: the
downlink carries k=4 of B=270 bands (a 98.5% reduction) and a modern CNN still
recovers most of the accuracy.

Usage
-----
  python t10_deep_run.py run --dataset configs/longkou.json \
      --runs output/runs/longkou_5cls --out output/runs/t10_longkou
  python t10_deep_run.py run --dataset configs/indian_pines.json \
      --runs output/runs/indian_pines --out output/runs/t10_indian --epochs 60
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from hsbs import spatial as hssp, runner as hsrun, hybridsn as hsn   # noqa: E402
from hsbs import split as split_mod                                  # noqa: E402


def _dump(out_dir: str, name: str, obj) -> str:
    os.makedirs(out_dir, exist_ok=True)
    p = os.path.join(out_dir, name)
    with open(p, 'w', encoding='utf-8') as fh:
        json.dump(obj, fh, indent=2, ensure_ascii=False)
    return p


def _split_of(splits, seed):
    for s in splits:
        if int(getattr(s, 'seed')) == int(seed):
            return s
    return splits[0]


def _read_bands(jsonl_path: str, k: int = 4) -> dict:
    out: dict = {}
    if not os.path.isfile(jsonl_path):
        return out
    with open(jsonl_path, 'r', encoding='utf-8') as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
            except Exception:
                continue
            if 'error' in d or int(d.get('k', -1)) != int(k):
                continue
            b = d.get('bands_0based') or [x - 1 for x in d.get('bands_1based', [])]
            if b:
                out.setdefault(str(d.get('method')), {})[int(d.get('seed', 0))] = [int(x) for x in b]
    return out


def _pca_fit_on(cube, n_pc, fit_idx):
    """PCA whose basis is fitted on ``fit_idx`` pixels only, then applied to all.

    Counterpart to ``hssp.pca_reduce`` (which fits on every pixel of the scene).
    Used by the ``pca<k>tr`` arm to test whether the full-branch advantage under
    a spatially disjoint split comes from a basis that has already seen the test
    blocks (leakage) rather than from the representation itself.
    """
    H, W, B = cube.shape
    X = np.asarray(cube, dtype=np.float64).reshape(H * W, B)
    Xf = X[np.asarray(fit_idx)]
    mu = Xf.mean(axis=0, keepdims=True)
    n_pc = min(int(n_pc), Xf.shape[1], Xf.shape[0] - 1)
    U, S, Vt = np.linalg.svd((Xf - mu) / np.sqrt(max(Xf.shape[0] - 1, 1)),
                             full_matrices=False)
    V = Vt[:n_pc].T                       # (B, n_pc) basis fitted on train only
    comps = (X - mu) @ V                  # applied to every pixel
    return comps.reshape(H, W, n_pc).astype(np.float32)


def _prepare_cube(ds, bands, pca: Optional[int], train_idx, pca_fit='all'):
    """Slice/reduce the cube and standardise with TRAIN statistics only.

    PCA is unsupervised and by default fitted on every pixel, which is the
    standard protocol and leaks no label information. With ``pca_fit='train'``
    the basis is fitted on the training pixels only, so that under a spatially
    disjoint split the basis has not seen the test blocks. Standardisation uses
    train pixels only in both cases, so the test split stays untouched.
    """
    cube = ds.cube[:, :, list(bands)] if bands is not None else ds.cube
    if pca and cube.shape[-1] > pca:
        if pca_fit == 'train':
            cube = _pca_fit_on(np.asarray(cube, dtype=np.float64), int(pca), train_idx)
        else:
            cube = hssp.pca_reduce(np.asarray(cube, dtype=np.float64), int(pca))
    cube = np.asarray(cube, dtype=np.float64)
    H, W, B = cube.shape
    flat = cube.reshape(H * W, B)
    mu = flat[train_idx].mean(axis=0, keepdims=True)
    sd = flat[train_idx].std(axis=0, keepdims=True)
    sd[sd < 1e-12] = 1e-12
    flat = (flat - mu) / sd
    return flat.reshape(H, W, B).astype(np.float32)


def _one_config(ds, splits, bands, label, args, seed, device):
    sp = _split_of(splits, seed)
    tr, te = np.asarray(sp.train_idx), np.asarray(sp.test_idx)
    # 'full' -> PCA to --pca components; 'pca<k>' -> PCA to k components (the fair
    # control: same k-dimensional CNN input, but the sensor still had to acquire
    # every band, so it costs the full downlink budget); 'sel<k>' -> raw k bands.
    if label in ('full', 'fulltr'):
        pca_n = args.pca
    elif label.startswith('pca'):
        pca_n = int(args.k)
    else:
        pca_n = None
    cube = _prepare_cube(ds, bands, pca_n, tr,
                         pca_fit=('train' if label.endswith('tr') else 'all'))
    lab = ds.labels()

    ytr = lab[tr].astype(np.int64) - 1     # 0-based for CrossEntropyLoss
    yte = lab[te].astype(np.int64) - 1
    if ytr.min() < 0 or yte.min() < 0:
        raise ValueError('split contains unlabelled pixels')

    ds_tr = hsn.PatchDataset(cube, tr, ytr, args.patch)
    ds_te = hsn.PatchDataset(cube, te, yte, args.patch)

    model = hsn.HybridSN(n_bands=int(cube.shape[-1]),
                         n_classes=int(len(ds.classes)),
                         patch=args.patch)
    arch = model.arch
    print('  [%s] bands=%d  patch=%d  params=%s'
          % (label, int(cube.shape[-1]), args.patch, '{:,}'.format(arch['n_params'])),
          flush=True)

    fit = hsn.train_model(model, ds_tr, epochs=args.epochs, batch_size=args.batch,
                          lr=args.lr, device=device, seed=seed,
                          val_frac=args.val_frac, verbose=True)
    met = hsn.evaluate_model(model, ds_te, batch_size=args.batch, device=device)
    return {'config': label, 'seed': int(seed),
            'n_bands_in': int(cube.shape[-1]),
            'bands_used': ([int(b) + 1 for b in bands] if bands is not None else 'all'),
            'arch': arch, 'train': fit, 'metrics': met}


def run(args) -> dict:
    torch = hsn._lazy_torch()[0]
    device = args.device
    if device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print('[device] %s' % (torch.cuda.get_device_name(0)
                           if device == 'cuda' and torch.cuda.is_available() else device),
          flush=True)

    ds, splits, _scfg, _out, _nj = hsrun.build_context(
        hsrun.load_config(args.dataset), seeds=args.seeds, verbose=False)

    if args.split_mode != 'random':
        # The random per-pixel split lets a training pixel sit inside a test
        # pixel's patch, so any neighbourhood model reads optimistically. On
        # LongKou -- few classes, large contiguous fields -- this saturates
        # (OA > 99.9% for every arm, which flattens the very gap we measure).
        # Re-partition spatially: no test pixel shares a block with a train pixel.
        splits = split_mod.make_disjoint_splits(
            ds.labels(), H=ds.height, W=ds.width, ratio=0.2,
            seeds=[int(s.seed) for s in splits], n_blocks=3, mode=args.split_mode)
        print('[split] spatially disjoint (mode=%s, n_blocks=3): %d splits'
              % (args.split_mode, len(splits)), flush=True)

    sel = _read_bands(os.path.join(args.runs, 'selection.jsonl'), k=args.k)
    method = args.bands_method
    if method not in sel:
        if not sel:
            raise SystemExit('no k=%d selection records under %s' % (args.k, args.runs))
        method = sorted(sel)[0]
        print('[warn] %s missing; using %s' % (args.bands_method, method), flush=True)

    allb = list(range(ds.n_bands))
    results = {'dataset': ds.name, 'method': method, 'k': int(args.k),
               'n_bands_original': int(ds.n_bands),
               'device': device, 'epochs': int(args.epochs), 'patch': int(args.patch),
               'split_mode': args.split_mode, 'reference': hsn.REFERENCE, 'runs': []}

    # ---- resume: reuse whatever an earlier (possibly interrupted) run already wrote ----
    prev_path = os.path.join(args.out, 't10_deep_summary.json')
    done = set()
    if args.resume and os.path.exists(prev_path):
        try:
            with open(prev_path, 'r', encoding='utf-8') as fh:
                prev = json.load(fh)
            for r in prev.get('runs', []):
                key = (r.get('config'), r.get('seed'))
                if key[0] is not None and key[1] is not None and key not in done:
                    done.add(key)
                    results['runs'].append(r)
            print('[resume] loaded %d finished arms from %s' % (len(done), prev_path),
                  flush=True)
        except Exception as exc:
            print('[resume] could not read %s (%s); starting fresh' % (prev_path, exc),
                  flush=True)
            done = set()

    def _flush():
        """Write what we have after every arm, so an interrupted run never loses work."""
        try:
            _summarise(results)
            _dump(args.out, 't10_deep_summary.json', results)
        except Exception as exc:
            print('[warn] incremental save failed: %s' % exc, flush=True)

    for seed in sorted(sel[method])[: args.max_seeds]:
        bands = sel[method][seed]
        print('[seed %d] bands=%s' % (seed, [b + 1 for b in bands]), flush=True)
        cfgs = [('full', allb), ('sel%d' % args.k, bands)]
        if args.skip_full:
            # 'full' is the only arm that does not depend on the selected bands,
            # and it is by far the most expensive (30-channel 3-D CNN, ~390 s per
            # seed against ~93 s for sel4). When the run exists to compare band
            # sets under an already-available reference, it is dead weight.
            cfgs = [c for c in cfgs if c[0] != 'full']
        if args.pca_control:
            cfgs.append(('pca%d' % args.k, allb))
        if args.pca_fit_train:
            # 'fulltr' is the decisive control: the full branch with its 30-component
            # basis fitted on the training blocks only, so that the basis has never
            # seen the test blocks. Comparing sel4 against fulltr -- rather than
            # against full -- removes the leakage channel from the full branch.
            cfgs.append(('fulltr', allb))
            cfgs.append(('pca%dtr' % args.k, allb))
        for label, band_arg in cfgs:
            if (label, seed) in done:
                print('    -> %-8s already done, skipping' % label, flush=True)
                continue
            t0 = time.perf_counter()
            r = _one_config(ds, splits, band_arg, label, args, seed, device)
            r['wall_s'] = float(time.perf_counter() - t0)
            r['seed'] = seed
            results['runs'].append(r)
            print('    -> OA %.2f%%  AA %.2f%%  Kappa %.4f  (%.1f s)'
                  % (r['metrics']['OA'], r['metrics']['AA'], r['metrics']['Kappa'],
                     r['wall_s']), flush=True)
            _flush()

    _summarise(results)
    _dump(args.out, 't10_deep_summary.json', results)
    _write_md(args.out, results)
    print('[done] -> %s' % os.path.join(args.out, 't10_deep_summary.json'), flush=True)
    return results


def _summarise(res: dict) -> None:
    by: dict = {}
    for r in res['runs']:
        by.setdefault(r['config'], []).append(r)
    res['summary'] = {}
    for cfg, recs in sorted(by.items()):
        oa = np.array([r['metrics']['OA'] for r in recs], dtype=np.float64)
        aa = np.array([r['metrics']['AA'] for r in recs], dtype=np.float64)
        kap = np.array([r['metrics']['Kappa'] for r in recs], dtype=np.float64)
        tr = np.array([r['train']['train_s'] for r in recs], dtype=np.float64)
        res['summary'][cfg] = {
            'n_seeds': int(oa.size),
            'OA_mean': float(oa.mean()), 'OA_std': float(oa.std(ddof=1)) if oa.size > 1 else 0.0,
            'AA_mean': float(aa.mean()), 'Kappa_mean': float(kap.mean()),
            'train_s_mean': float(tr.mean()),
            'n_params': int(recs[0]['arch']['n_params']),
            'spectral_dims': recs[0]['arch']['spectral_dims'],
            'kernel_depths': recs[0]['arch']['kernel_depths'],
            'n_bands_in': int(recs[0]['n_bands_in']),
        }
    full = res['summary'].get('full')
    sel = res['summary'].get('sel%d' % res['k'])
    if full and sel:
        # Two different denominators, and confusing them would overstate the claim:
        #   * DOWNLINK saving is vs the ORIGINAL band count B -- the sensor has to
        #     transmit (or store) k of B bands. PCA happens on-board afterwards and
        #     saves no bandwidth, so it must never be the reference.
        #   * MODEL INPUT saving is vs the PCA-reduced stack actually fed to the CNN.
        B = int(res.get('n_bands_original', full['n_bands_in']))
        k = int(res['k'])
        res['band_selection_effect'] = {
            'downlink_bands_full': B,
            'downlink_bands_selected': k,
            'downlink_reduction_pct': float(100.0 * (1.0 - k / max(B, 1))),
            'model_input_full': int(full['n_bands_in']),
            'model_input_selected': int(sel['n_bands_in']),
            'model_input_reduction_pct': float(
                100.0 * (1.0 - sel['n_bands_in'] / max(full['n_bands_in'], 1))),
            'OA_full': full['OA_mean'], 'OA_selected': sel['OA_mean'],
            'OA_gap_pp': float(sel['OA_mean'] - full['OA_mean']),
            'params_full': int(full['n_params']), 'params_selected': int(sel['n_params']),
        }
    pca = res['summary'].get('pca%d' % res['k'])
    if pca and sel:
        # Equal-width control: both arms feed a k-channel cube to the SAME network
        # architecture, so the only difference is how those k channels were obtained.
        # sel<k> needs k bands acquired; pca<k> needs all B acquired and an on-board PCA.
        res['selection_vs_pca'] = {
            'OA_pca': pca['OA_mean'], 'OA_selected': sel['OA_mean'],
            'gap_pp': float(sel['OA_mean'] - pca['OA_mean']),
            'bands_acquired_pca': int(res.get('n_bands_original', 0)),
            'bands_acquired_selected': int(res['k']),
        }


def _write_md(out_dir: str, res: dict) -> None:
    lines = ['# T10 deep baseline -- HybridSN on %s' % res['dataset'], '',
             '- bands from **%s** (k=%d), identical splits as the main tables'
             % (res['method'], res['k']),
             '- reference: %s' % res['reference'], '']
    lines += ['| config | model input bands | 3-D kernel depths | spectral dims | params | '
              'train (s) | OA (mean+/-std) | AA | Kappa |',
              '|---|---|---|---|---|---|---|---|---|']
    for cfg, s in sorted(res['summary'].items()):
        lines.append('| %s | %d | %s | %s | %s | %.1f | %.2f +/- %.2f | %.2f | %.4f |'
                     % (cfg, s['n_bands_in'], s['kernel_depths'], s['spectral_dims'],
                        '{:,}'.format(s['n_params']), s['train_s_mean'],
                        s['OA_mean'], s['OA_std'], s['AA_mean'], s['Kappa_mean']))
    be = res.get('band_selection_effect')
    if be:
        lines += ['', '## Effect of the selected bands on a modern CNN', '',
                  '- **downlink** band reduction: **%.1f%%** (%d -> %d bands) '
                  '-- the sensor transmits k of B; PCA is applied on-board afterwards '
                  'and saves no bandwidth, so B is the correct denominator'
                  % (be['downlink_reduction_pct'], be['downlink_bands_full'],
                     be['downlink_bands_selected']),
                  '- **model input** reduction: %.1f%% (%d -> %d bands fed to the CNN)'
                  % (be['model_input_reduction_pct'], be['model_input_full'],
                     be['model_input_selected']),
                  '- OA: %.2f%% (all bands) -> %.2f%% (selected), gap **%+.2f pp**'
                  % (be['OA_full'], be['OA_selected'], be['OA_gap_pp']),
                  '- parameters: %s -> %s'
                  % ('{:,}'.format(be['params_full']), '{:,}'.format(be['params_selected'])),
                  '',
                  '> The 3-D spectral branch collapses to depth 1 at k=%d: band selection '
                  'has already performed the spectral compression that branch exists for.'
                  % res['k']]
    sv = res.get('selection_vs_pca')
    if sv:
        lines += ['', '## Band selection vs on-board PCA (equal CNN input width)', '',
                  'Both arms feed a **%d-channel** cube to the identical network; the only '
                  'difference is how those channels were obtained.' % res['k'], '',
                  '| arm | bands the sensor must acquire | on-board PCA | OA |',
                  '|---|---|---|---|',
                  '| `pca%d` | %d (all) | yes | %.2f%% |'
                  % (res['k'], sv['bands_acquired_pca'], sv['OA_pca']),
                  '| `sel%d` | **%d** | no | **%.2f%%** |'
                  % (res['k'], sv['bands_acquired_selected'], sv['OA_selected']),
                  '',
                  'Gap **%+.2f pp** (selected - PCA) at %d/%d of the acquisition cost.'
                  % (sv['gap_pp'], sv['bands_acquired_selected'], sv['bands_acquired_pca']),
                  '',
                  '> This isolates band selection from dimensionality reduction: any gap '
                  'is attributable to *which* bands are kept, not to the reduced width.']
    with open(os.path.join(out_dir, 't10_deep.md'), 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(lines) + '\n')


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('cmd', choices=['run'])
    ap.add_argument('--dataset', required=True)
    ap.add_argument('--runs', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--bands-method', default='SAPSO')
    ap.add_argument('--k', type=int, default=4)
    ap.add_argument('--epochs', type=int, default=100)
    ap.add_argument('--batch', type=int, default=256)
    ap.add_argument('--lr', type=float, default=1e-3)
    ap.add_argument('--patch', type=int, default=11)
    ap.add_argument('--pca', type=int, default=30)
    ap.add_argument('--split-mode', choices=['random', 'block', 'row'], default='random',
                    help="'random' = the per-pixel split used by the main tables (optimistic "
                         "for patch models); 'block'/'row' = spatially disjoint, the honest "
                         "read for any neighbourhood-based classifier.")
    ap.add_argument('--resume', action='store_true',
                    help='reuse finished arms from an earlier run of the same --out directory')
    ap.add_argument('--pca-fit-train', action='store_true',
                    help="add a 'pca<k>tr' arm: all bands PCA-reduced to k components with the "
                         "basis fitted on the TRAINING pixels only. Contrasted with 'pca<k>' "
                         "(basis fitted on every pixel) it isolates representation quality from "
                         "the advantage of having already seen the test blocks.")
    ap.add_argument('--skip-full', action='store_true',
                    help="drop the 'full' arm (30-channel input, band-independent and the " 
                         "slowest arm by ~4x). Use when the full-branch reference already " 
                         "exists in an earlier run.")
    ap.add_argument('--pca-control', action='store_true',
                    help="add a 'pca<k>' arm: all bands PCA-reduced to k components, "
                         "i.e. the same k-dimensional CNN input as sel<k> but with the "
                         "full-band acquisition cost. Isolates band selection from PCA.")
    ap.add_argument('--val-frac', type=float, default=0.1)
    ap.add_argument('--max-seeds', type=int, default=1)
    ap.add_argument('--seeds', default=None)
    ap.add_argument('--device', default='auto', choices=['auto', 'cuda', 'cpu'])
    args = ap.parse_args(argv)
    if args.cmd == 'run':
        run(args)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
