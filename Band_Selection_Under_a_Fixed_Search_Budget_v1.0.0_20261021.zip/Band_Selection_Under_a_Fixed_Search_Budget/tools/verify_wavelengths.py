# -*- coding: utf-8 -*-
"""
t43_verify_wavelengths.py
-------------------------
用真实数据校验 t42 生成的"波段索引 -> 中心波长"映射是否自洽。

校验点：
 A. Indian Pines 前 103 个波段（两解一致区）：
    通道31=696.50 nm 紧跟通道32=686.91 nm（光谱仪 A/B 交叠，波长回跳）。
    植被在 686 nm(红) 反射低、696 nm(红边) 反射高 -> 均值光谱应出现
    "低-高-低"的锯齿，位置必须落在索引 29/30/31。
 B. 被剔除的水体吸收带位置：
    映射 A 剔除通道 104-108(1362.64-1402.44 nm) 与 150-163(1819.08-1933.27 nm)，
    恰好是 1.38 um 与 1.88 um 水汽吸收带 -> 保留数据中不应出现深吸收谷。
 C. 计数自洽性：剔除"通道号"得 200 波段；剔除"AVIRIS Data Band 号"只得 201 波段
    （数据带 161 是空带不占通道），故只能按通道号剔除。
"""
import json
import os

import numpy as np
import scipy.io as sio

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

ip = json.load(open(os.path.join(ROOT, "data", "meta", "indian_pines_wavelengths_200.json"),
                    encoding="utf-8"))
wl = np.array([b["wavelength_nm"] for b in ip["bands"]])
ch = np.array([b["channel_of_220"] for b in ip["bands"]])

cube = sio.loadmat(os.path.join(ROOT, "data", "raw", "Indian_pines_corrected.mat"))["indian_pines_corrected"]
gt = sio.loadmat(os.path.join(ROOT, "data", "raw", "Indian_pines_gt.mat"))["indian_pines_gt"]
assert cube.shape[2] == 200, cube.shape
print("cube:", cube.shape, " bands in mapping:", len(wl))

# 植被大类（Corn-no till=2, Soybean-mintill=11, Woods=14）均值光谱
mask = np.isin(gt, [2, 11, 14])
veg = cube[mask].mean(axis=0)          # 200
print("vegetation pixels:", int(mask.sum()))

# --- A. 红边 /
print("\n[A] 光谱仪 A/B 交叠处的波长回跳（通道31=696.50 -> 通道32=686.91）")
for i in range(27, 34):
    print("   idx %3d  ch%3d  %8.2f nm   mean=%8.1f" % (i + 1, ch[i], wl[i], veg[i]))
# 索引 31(=通道31, 696.50 nm) 应明显高于索引 30(686.53) 与索引 32(686.91)
j_up, j_dn = veg[30] - veg[29], veg[30] - veg[31]
ok_a = j_up > 0 and j_dn > 0 and abs(veg[31] - veg[29]) < 0.3 * min(j_up, j_dn)
print("   +%.1f / %.1f  -> 锯齿(低-高-低)成立: %s" % (j_up, j_dn, ok_a))

# --- B. 水体吸收带是否被干净剔除
def gap_positions(w):
    d = np.diff(w)
    return [(i + 1, round(w[i], 2), round(w[i + 1], 2), round(d[i], 2))
            for i in np.argsort(-np.abs(d))[:6]]
print("\n[B] 保留波段中最大的 6 个波长跳跃（应恰为被剔除的水汽吸收带两侧）")
for g in sorted(gap_positions(wl)):
    print("   after idx %3d : %8.2f -> %8.2f nm (jump %6.2f)" % g)

# 检查 1.38 / 1.88 um 区内是否还残留深谷（相对邻带的下降幅度）
def dip(idx):
    return (veg[idx - 1] + veg[idx + 1]) / 2 - veg[idx]
cand = [i for i in range(1, 199) if 1330 < wl[i] < 1450 or 1800 < wl[i] < 1960]
worst = sorted(cand, key=lambda i: -dip(i))[:5]
print("\n[B2] 水汽区（1330-1450 / 1800-1960 nm）内残留最深的单带凹陷：")
for i in worst:
    print("   idx %3d  %8.2f nm  dip=%7.1f (邻带均值-本带)" % (i + 1, wl[i], dip(i)))

# --- C. 计数自洽性
print("\n[C] 计数自洽性：按通道号剔除 -> %d 波段；按 Data-Band 号剔除 -> %d 波段"
      % (220 - (5 + 14 + 1), 220 - (5 + 13 + 1)))
print("    实际 cube 波段数 = %d  => 只能按通道号剔除" % cube.shape[2])
