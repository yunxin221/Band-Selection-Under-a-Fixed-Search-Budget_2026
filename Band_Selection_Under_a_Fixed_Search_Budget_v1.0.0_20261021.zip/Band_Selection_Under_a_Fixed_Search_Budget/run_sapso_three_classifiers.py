# -*- coding: utf-8 -*-
"""Focused run: SAPSO k = 4 selected bands under protocol A (dim = k + F),
evaluated with all three classifiers.

Why this exists
---------------
``batch7_8_run.py crosstable`` reports KNN only, and its protocol-B variant
keeps the full spectral stack (dim B + F). The manuscript needs the *compact*
row -- selected bands only plus the spatial features computed on those bands --
for all three classifiers, so the "4 channels in, full accuracy out" claim can
be read straight off the table. This script computes exactly that row.
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = HERE
sys.path.insert(0, HERE)

import batch7_8_run as B  # noqa: E402
from hsbs import evaluate, spatial as hssp  # noqa: E402

CLFS = ['knn5', 'svm_rbf', 'rf']
JOBS = [
    ('WHU-Hi-LongKou', 'configs/longkou.json', 'output/runs/longkou_5cls', 'SAPSO'),
    ('Indian Pines', 'configs/indian_pines.json', 'output/runs/indian_pines', 'SAPSO'),
]


def agg(vals):
    v = np.asarray(vals, dtype=np.float64)
    return {'OA_mean': float(v.mean()),
            'OA_std': float(v.std(ddof=1)) if v.size > 1 else 0.0,
            'n': int(v.size)}


def main():
    spec = hssp.SpatialSpec.from_dict(B.DEFAULT_SPATIAL[0])
    out = {'operator': spec.operator, 'protocol': 'A', 'method': 'SAPSO', 'k': 4,
           'datasets': {}}
    for name, cfg, runs, method in JOBS:
        ds, splits, _scfg, _o = B.load_context(os.path.join(HERE, cfg))
        bands_map = B._read_selection_bands(os.path.join(ROOT, runs, 'selection.jsonl'), k=4)
        seeds_bands = sorted(bands_map.get(method, []))
        if not seeds_bands:
            print('[skip] %s: no %s k=4 rows' % (name, method))
            continue
        acc_spectral = {c: [] for c in CLFS}
        acc_aug = {c: [] for c in CLFS}
        dim = None
        for seed, bands in seeds_bands:
            tr = B._train(splits, seed)
            te = B._test(splits, seed)
            for c in CLFS:
                e0 = evaluate.evaluate_subset(ds, tr, te, list(bands), evaluate.CLASSIFIERS[c])
                acc_spectral[c].append(float(e0['OA']))
            aug, F, idx, _tag = B._augment_selected(ds, spec, bands, protocol='A')
            dim = len(idx)
            for c in CLFS:
                eb = evaluate.evaluate_subset(aug, tr, te, idx, evaluate.CLASSIFIERS[c])
                acc_aug[c].append(float(eb['OA']))
            print('  %s seed %d: knn %.2f -> %.2f' % (name, seed, acc_spectral['knn5'][-1],
                                                      acc_aug['knn5'][-1]), flush=True)
        out['datasets'][name] = {
            'n_bands_spectral': int(ds.n_bands),
            'feature_dim': int(dim),
            'F': int(F),
            'spectral_only': {c: agg(acc_spectral[c]) for c in CLFS},
            'plus_EMP': {c: agg(acc_aug[c]) for c in CLFS},
        }
    dst = os.path.join(ROOT, 'output/runs/sapso3_protocolA.json')
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    with open(dst, 'w', encoding='utf-8') as fh:
        json.dump(out, fh, indent=2, ensure_ascii=False)
    print('[done] -> %s' % dst)


if __name__ == '__main__':
    main()
