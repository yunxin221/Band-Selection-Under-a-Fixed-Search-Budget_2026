"""HybridSN baseline for the "modern spatial-spectral baseline" half of M-P2-1.

Why HybridSN and not SSRN / A2S2K / 3D-CNN
------------------------------------------
* 3D-CNN (2016) is the weakest reference point and the heaviest.
* SSRN is stronger but noticeably more code for no extra argumentative value.
* A2S2K needs superpixel segmentation, which is a large implementation surface
  for a baseline whose only job is to anchor the comparison.
HybridSN (Roy et al., IEEE GRSL 2020) is a 3-D -> 2-D hierarchy of roughly 5 M
parameters, is about 100 lines, trains in minutes on a 16 GB laptop GPU, and is
the most widely reproduced modern baseline in this literature -- which matters,
because a baseline a reviewer cannot recognise is a baseline a reviewer rejects.

Spectral-depth adaptation
-------------------------
The stock model assumes ~30 PCA bands and uses 3-D kernels of depth 7/5/3. With
k = 4 selected bands a depth-7 kernel is impossible, so the kernel depths are
clamped with ``min`` and the resulting spectral dimension collapses to 1. That
is not a workaround to hide: it is the honest finding that **band selection has
already performed the spectral compression the 3-D branch exists for**, which is
exactly the point the "generalisation of band selection" subsection makes.

Patch extraction is lazy (the cube is padded once and each patch is sliced in
``__getitem__``). Materialising all patches would need >1 GB for the LongKou
test split at 90,624 pixels.
"""
from __future__ import annotations

import time
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

__all__ = ['HybridSN', 'PatchDataset', 'train_model', 'evaluate_model',
           'count_parameters', 'REFERENCE']

REFERENCE = ('Roy, S.K.; Krishna, G.; Dubey, S.R.; Chaudhuri, B.B. HybridSN: '
             'Exploring 3-D-2-D CNN Feature Hierarchy for Hyperspectral Image '
             'Classification. IEEE GRSL 17(2), 2020, 277-281.')


def _lazy_torch():
    try:
        import torch
        import torch.nn as nn
        return torch, nn
    except ImportError as exc:  # pragma: no cover
        raise SystemExit('HybridSN needs torch; install torch==2.14.1+cu126 first '
                         '(see T12). Original error: %s' % exc)


# --------------------------------------------------------------------- model
class HybridSN:
    """Thin wrapper so callers never import torch until they actually train."""

    def __init__(self, n_bands: int, n_classes: int, patch: int = 11):
        torch, nn = _lazy_torch()
        self.torch, self.nn = torch, nn
        self.n_bands = int(n_bands)
        self.n_classes = int(n_classes)
        self.patch = int(patch)
        self.net = _HybridSNNet(torch, nn, self.n_bands, self.n_classes, self.patch)

    def to(self, device: str):
        self.net = self.net.to(device)
        return self

    def parameters(self):
        return self.net.parameters()

    def state_dict(self):
        return self.net.state_dict()

    def train(self, mode: bool = True):
        self.net.train(mode)
        return self

    def eval(self):
        self.net.eval()
        return self

    def __call__(self, x):
        return self.net(x)

    @property
    def arch(self) -> Dict[str, object]:
        torch, _ = self.torch, self.nn
        kd1 = min(7, self.n_bands)
        d1 = self.n_bands - kd1 + 1
        kd2 = min(5, d1)
        d2 = d1 - kd2 + 1
        kd3 = min(3, d2)
        d3 = d2 - kd3 + 1
        return {'n_bands': self.n_bands, 'patch': self.patch,
                'kernel_depths': [kd1, kd2, kd3],
                'spectral_dims': [d1, d2, d3],
                'n_params': count_parameters(self)}


def _HybridSNNet(torch, nn, n_bands: int, n_classes: int, patch: int):
    kd1 = min(7, n_bands)
    d1 = n_bands - kd1 + 1
    kd2 = min(5, d1)
    d2 = d1 - kd2 + 1
    kd3 = min(3, d2)
    d3 = d2 - kd3 + 1
    if d3 < 1:
        raise ValueError('n_bands=%d too small for the 3-D stack' % n_bands)
    s = patch - 6          # three 3x3 spatial convolutions, no padding
    s2 = s - 2             # the 2-D convolution
    if s2 < 1:
        raise ValueError('patch=%d too small; need >= 9' % patch)

    class _Net(nn.Module):
        def __init__(self):
            super().__init__()
            self.conv1 = nn.Conv3d(1, 8, (kd1, 3, 3))
            self.conv2 = nn.Conv3d(8, 16, (kd2, 3, 3))
            self.conv3 = nn.Conv3d(16, 32, (kd3, 3, 3))
            self.bn1 = nn.BatchNorm3d(8)
            self.bn2 = nn.BatchNorm3d(16)
            self.bn3 = nn.BatchNorm3d(32)
            self.conv2d = nn.Conv2d(32 * d3, 64, (3, 3))
            self.bn2d = nn.BatchNorm2d(64)
            self.fc1 = nn.Linear(64 * s2 * s2, 256)
            self.fc2 = nn.Linear(256, 128)
            self.fc3 = nn.Linear(128, n_classes)
            self.drop = nn.Dropout(0.4)
            self._flat = 32 * d3

        def forward(self, x):
            x = torch.nn.functional.relu(self.bn1(self.conv1(x)))
            x = torch.nn.functional.relu(self.bn2(self.conv2(x)))
            x = torch.nn.functional.relu(self.bn3(self.conv3(x)))
            x = x.view(-1, self._flat, x.shape[3], x.shape[4])
            x = torch.nn.functional.relu(self.bn2d(self.conv2d(x)))
            x = x.reshape(x.shape[0], -1)
            x = torch.nn.functional.relu(self.fc1(self.drop(x)))
            x = torch.nn.functional.relu(self.fc2(self.drop(x)))
            return self.fc3(x)

    return _Net()


def count_parameters(model: 'HybridSN') -> int:
    return int(sum(p.numel() for p in model.net.parameters() if p.requires_grad))


# --------------------------------------------------------------------- data
class PatchDataset:
    """Lazy patch sampler: the padded cube is stored once, patches are sliced on demand.

    ``positions`` are flat indices into ``H * W``; labels are 0-based class ids.
    """

    def __init__(self, cube: np.ndarray, positions: Sequence[int],
                 labels: Sequence[int], patch: int):
        torch, _ = _lazy_torch()
        self.torch = torch
        p = int(patch)
        if p % 2 == 0:
            raise ValueError('patch must be odd, got %d' % p)
        pad = p // 2
        self.p = p
        self.pad = pad
        self.H, self.W = int(cube.shape[0]), int(cube.shape[1])
        self.cube = np.pad(np.asarray(cube, dtype=np.float32),
                           ((pad, pad), (pad, pad), (0, 0)), mode='reflect')
        self.pos = np.asarray(positions, dtype=np.int64)
        self.y = np.asarray(labels, dtype=np.int64)

    def __len__(self) -> int:
        return int(self.pos.size)

    def __getitem__(self, i: int):
        r, c = divmod(int(self.pos[i]), self.W)
        # the padded cube is offset by `pad`, so r/c index straight into it
        pr, pc = r + self.pad, c + self.pad
        patch = self.cube[pr - self.pad: pr + self.pad + 1,
                          pc - self.pad: pc + self.pad + 1, :]
        x = self.torch.from_numpy(np.ascontiguousarray(patch)).permute(2, 0, 1).unsqueeze(0)
        return x, int(self.y[i])


def _collate(batch):
    torch, _ = _lazy_torch()
    xs = torch.stack([b[0] for b in batch])
    ys = torch.tensor([b[1] for b in batch], dtype=torch.long)
    return xs, ys


# --------------------------------------------------------------------- train / eval
def train_model(model: 'HybridSN', dataset: PatchDataset, *,
                epochs: int = 100, batch_size: int = 256, lr: float = 1e-3,
                weight_decay: float = 1e-4, device: str = 'cuda',
                seed: int = 0, val_frac: float = 0.1,
                verbose: bool = True) -> Dict[str, object]:
    """Train HybridSN; returns the history plus wall-clock cost."""
    torch, nn = _lazy_torch()
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)

    n = len(dataset)
    idx = rng.permutation(n)
    n_val = int(round(n * float(val_frac)))
    val_idx, tr_idx = idx[:n_val], idx[n_val:]

    model.to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    crit = nn.CrossEntropyLoss()
    sched = torch.optim.lr_scheduler.StepLR(opt, step_size=30, gamma=0.5)

    history: List[Dict[str, float]] = []
    t0 = time.perf_counter()
    best_val = -1.0
    best_state = None
    for ep in range(1, int(epochs) + 1):
        model.train()
        perm = rng.permutation(tr_idx)
        running, seen = 0.0, 0
        for i in range(0, perm.size, batch_size):
            bidx = perm[i:i + batch_size]
            xs, ys = _collate([dataset[j] for j in bidx])
            xs, ys = xs.to(device), ys.to(device)
            opt.zero_grad()
            loss = crit(model(xs), ys)
            loss.backward()
            opt.step()
            running += float(loss.item()) * ys.size(0)
            seen += ys.size(0)
        sched.step()

        model.eval()
        correct, tot = 0, 0
        with torch.no_grad():
            for i in range(0, val_idx.size, batch_size):
                bidx = val_idx[i:i + batch_size]
                xs, ys = _collate([dataset[j] for j in bidx])
                xs, ys = xs.to(device), ys.to(device)
                pred = model(xs).argmax(dim=1)
                correct += int((pred == ys).sum())
                tot += ys.size(0)
        val_acc = correct / max(tot, 1)
        if val_acc > best_val:
            best_val = val_acc
            best_state = {k: v.detach().cpu().clone()
                          for k, v in model.state_dict().items()}
        history.append({'epoch': ep, 'train_loss': running / max(seen, 1),
                        'val_acc': float(val_acc)})
        if verbose and (ep % 10 == 0 or ep == 1):
            print('    epoch %3d  loss %.4f  val %.2f%%' % (ep, running / max(seen, 1),
                                                            val_acc * 100), flush=True)
    train_s = time.perf_counter() - t0
    if best_state is not None:
        model.net.load_state_dict(best_state)
    return {'history': history, 'train_s': float(train_s),
            'best_val_acc': float(best_val), 'n_train': int(tr_idx.size),
            'n_val': int(val_idx.size), 'epochs': int(epochs),
            'device': device, 'batch_size': int(batch_size)}


def evaluate_model(model: 'HybridSN', dataset: PatchDataset, *,
                   batch_size: int = 512, device: str = 'cuda') -> Dict[str, object]:
    """Predict the whole dataset and return metrics plus inference timing."""
    torch, _ = _lazy_torch()
    from . import evaluate as hs_eval

    model.eval()
    model.to(device)
    preds: List[np.ndarray] = []
    t0 = time.perf_counter()
    with torch.no_grad():
        for i in range(0, len(dataset), batch_size):
            bidx = list(range(i, min(i + batch_size, len(dataset))))
            xs, _ = _collate([dataset[j] for j in bidx])
            out = model(xs.to(device))
            preds.append(out.argmax(dim=1).cpu().numpy())
    infer_s = time.perf_counter() - t0
    y_pred = np.concatenate(preds) if preds else np.zeros(0, dtype=np.int64)
    y_true = np.asarray(dataset.y, dtype=np.int64)
    # metrics expect 1-based class labels; HybridSN trains on 0-based ids
    met = hs_eval.classification_metrics(y_true + 1, y_pred + 1)
    met.update({'infer_s': float(infer_s), 'n_predicted': int(y_pred.size),
                'throughput_px_per_s': float(y_pred.size / infer_s) if infer_s > 0 else float('nan')})
    return met
