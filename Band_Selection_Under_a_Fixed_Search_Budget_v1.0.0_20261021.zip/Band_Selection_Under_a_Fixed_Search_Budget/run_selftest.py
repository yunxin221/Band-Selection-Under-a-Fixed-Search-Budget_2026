"""End-to-end self-test on synthetic data.

Runs without pytest:  python run_selftest.py

The point is to prove the whole chain works before the real cube arrives:
load -> split -> objective -> six optimisers -> classification -> statistics ->
tables and figures. Everything asserted here is a property that must also hold
on real data.
"""
from __future__ import annotations

import os
import shutil
import sys
import tempfile
import traceback

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from hsbs import criteria, data, evaluate, optim, report, split as hsbs_split
from hsbs.runner import SelectionConfig, run_experiment

PASS, FAIL = [], []


def check(name, fn):
    try:
        fn()
        PASS.append(name)
        print('  PASS  %s' % name)
    except Exception as exc:                                   # noqa: BLE001
        FAIL.append((name, exc))
        print('  FAIL  %s -> %s: %s' % (name, type(exc).__name__, exc))
        traceback.print_exc(limit=3)


# --------------------------------------------------------------------- fixtures
DS = data.make_synthetic(height=40, width=40, n_bands=24, n_classes=4, seed=7,
                         noise=0.05, spatial_smooth=3)
LABELS = DS.labels()
SPLITS = hsbs_split.make_splits(LABELS, ratio=0.20, seeds=(1, 2), min_per_class=8)
SPEC = criteria.FitnessSpec(reduce='sum', normalize='none', name='JM-sum')
BIG = None


def t_dataset():
    assert DS.cube.shape == (40, 40, 24), DS.cube.shape
    assert DS.gt.shape == (40, 40)
    assert DS.n_bands == 24 and DS.n_pixels == 1600
    assert DS.classes == [1, 2, 3, 4], DS.classes
    assert DS.wavelengths.shape == (24,)
    assert DS.as_matrix().shape == (1600, 24)
    assert DS.labels().shape == (1600,)
    assert DS.subset([0, 5, 9]).shape == (1600, 3)
    assert DS.rgb().shape == (40, 40, 3)
    assert 0.0 <= DS.rgb().min() and DS.rgb().max() <= 1.0
    assert DS.band_indices_1based([0, 5]) == [1, 6]
    txt = data.describe(DS)
    assert 'synthetic' in txt.lower() or 'SYNTHETIC' in txt
    assert len(data.true_informative_bands(DS)) == 4


def t_dataset_guards():
    for bad in (lambda: data.HSDataset('x', np.zeros((5, 5, 3)), np.zeros((4, 5))),
                lambda: data.HSDataset('x', np.zeros((5, 5, 3)), np.zeros((5, 5)), wavelengths=np.zeros(4))):
        try:
            bad()
        except ValueError:
            pass
        else:
            raise AssertionError('expected ValueError')
    try:
        DS.subset([0, 999])
    except IndexError:
        pass
    else:
        raise AssertionError('expected IndexError for out-of-range band')


def t_loader_roundtrip():
    tmp = tempfile.mkdtemp(prefix='hsbs_')
    try:
        npy = os.path.join(tmp, 'cube.npy')
        gtp = os.path.join(tmp, 'gt.npy')
        np.save(npy, DS.cube)
        np.save(gtp, DS.gt)
        got = data.load_dataset(npy, gt_path=gtp)
        assert np.allclose(got.cube, DS.cube)
        assert np.array_equal(got.gt, DS.gt)
        npz = os.path.join(tmp, 'both.npz')
        np.savez_compressed(npz, cube=DS.cube, gt=DS.gt)
        got2 = data.load_dataset(npz)
        assert got2.cube.shape == DS.cube.shape
        mat = os.path.join(tmp, 'both.mat')
        from scipy.io import savemat
        savemat(mat, {'X': DS.cube, 'Y': DS.gt})
        got3 = data.load_dataset(mat)
        assert got3.cube.shape == DS.cube.shape and got3.gt.shape == DS.gt.shape
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t_scale_probe():
    assert abs(criteria.JM_CEILING - np.sqrt(2)) < 1e-12
    p = criteria.probe_scale(13.6169, 5)
    assert p['n_pairs'] == 10
    assert p['consistent_with'] == ['sum'], p
    assert 0.95 < p['target_over_ceiling_sum'] < 0.99
    p2 = criteria.probe_scale(1.2, 5)
    assert set(p2['consistent_with']) == {'mean', 'sum', 'max'}
    p3 = criteria.probe_scale(99.0, 5)
    assert p3['consistent_with'] == []
    assert 'reduce' in criteria.explain_scale(13.6169, 5)


def t_jm():
    rng = np.random.default_rng(0)
    a = rng.normal(0, 1, size=(200, 3))
    b = rng.normal(0, 1, size=(200, 3))
    same = criteria.jm_distance(a, b)
    assert 0.0 <= same < 0.35, same
    c = rng.normal(6, 1, size=(200, 3))
    far = criteria.jm_distance(a, c)
    assert far > 1.3, far
    assert far <= criteria.JM_CEILING + 1e-9
    assert criteria.jm_distance(a[:1], c[:1]) == 0.0
    bd = criteria.bhattacharyya_distance(a, c)
    assert bd > 0
    r = criteria.band_correlation(np.column_stack([a[:, 0], a[:, 0], rng.normal(size=200)]))
    assert abs(r[0, 1] - 1.0) < 1e-9 and r[0, 2] < 0.3
    red = criteria.redundancy_metrics(np.column_stack([a[:, 0], a[:, 0]]))
    assert abs(red['mean_abs_corr'] - 1.0) < 1e-9


def t_splits():
    assert len(SPLITS) == 2
    for s in SPLITS:
        assert np.intersect1d(s.train_idx, s.test_idx).size == 0
        assert s.train_idx.size + s.test_idx.size == int((LABELS != 0).sum())
        assert all(s.per_class[c] >= 8 for c in s.per_class)
        assert abs(s.train_idx.size / (s.train_idx.size + s.test_idx.size) - 0.2) < 0.03
    assert not np.array_equal(SPLITS[0].train_idx, SPLITS[1].train_idx)
    again = hsbs_split.make_splits(LABELS, ratio=0.20, seeds=(1, 2), min_per_class=8)
    assert np.array_equal(again[0].train_idx, SPLITS[0].train_idx)
    tmp = tempfile.mkdtemp(prefix='hsbs_')
    try:
        p = os.path.join(tmp, 'splits.npz')
        hsbs_split.save_splits(p, SPLITS, meta={'ratio': 0.2})
        back = hsbs_split.load_splits(p)
        assert np.array_equal(back[0].train_idx, SPLITS[0].train_idx)
        assert back[1].per_class == SPLITS[1].per_class
        assert 'splits' in hsbs_split.split_summary(back)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t_fitness():
    fit = criteria.build_fitness(DS, SPLITS[0].train_idx, SPEC)
    assert fit.n_pairs == 6, fit.n_pairs
    v1 = fit([0, 5, 10, 15])
    v2 = fit([15, 10, 5, 0])
    assert abs(v1 - v2) < 1e-12
    n_before = fit.nfe
    fit([0, 5, 10, 15])
    assert fit.nfe == n_before, 'cache failed to suppress a repeat evaluation'
    comp = fit.components([0, 5, 10, 15])
    assert comp['k'] == 4 and comp['bands_1based'] == [1, 6, 11, 16]
    assert comp['n_pairs'] == 6 and 0.0 <= comp['mean_abs_corr'] <= 1.0
    assert comp['jm_mean'] <= comp['jm_max'] + 1e-12
    strict = criteria.build_fitness(DS, SPLITS[0].train_idx,
                                    criteria.FitnessSpec(require_exact_k=4, name='strict'))
    assert strict([0, 5, 10]) == float('-inf')
    assert strict([0, 0, 5, 10]) == float('-inf')
    assert np.isfinite(strict([0, 5, 10, 15]))
    plain = criteria.build_fitness(DS, SPLITS[0].train_idx, criteria.FitnessSpec(reduce='mean', name='JM-mean'))
    assert plain([0, 5, 10, 15]) < v1
    z = criteria.build_fitness(DS, SPLITS[0].train_idx,
                               criteria.FitnessSpec(normalize='zscore', max_eval_per_class=15, name='JM-z'))
    assert np.isfinite(z([0, 5, 10, 15]))
    rp = criteria.build_fitness(DS, SPLITS[0].train_idx,
                                criteria.FitnessSpec(redundancy_penalty=0.5, name='JM-red'))
    assert rp([0, 5, 10, 15]) < v1


def t_optimisers_shape():
    ref = criteria.build_fitness(DS, SPLITS[0].train_idx, SPEC)
    for name in optim.list_methods():
        fit = criteria.build_fitness(DS, SPLITS[0].train_idx, SPEC)
        opt = optim.make_optimizer(name, fit, n_bands=DS.n_bands, k=4, nfe_budget=250,
                                   seed=3, pop_size=10)
        res = opt.run()
        assert res.k == 4, '%s picked %d bands' % (name, res.k)
        assert len(set(res.bands)) == 4
        assert all(0 <= b < DS.n_bands for b in res.bands)
        assert res.bands == sorted(res.bands)
        assert res.nfe <= 250 + 12, '%s used %d NFE > budget' % (name, res.nfe)
        assert np.isfinite(res.score) and res.score <= criteria.JM_CEILING * 6 + 1e-6
        assert len(res.history) > 0
        h = np.asarray(res.history)
        assert np.all(np.diff(h) >= -1e-9), '%s history is not monotone' % name
        assert abs(res.score - fit(res.bands)) < 1e-9
        assert isinstance(res.as_row()['bands_1based'], str)
    assert unfitness_check(ref)


def unfitness_check(ref):
    return ref([1, 2, 3, 4]) > 0


def t_optimisers_determinism():
    for name in optim.list_methods():
        got = []
        for _ in range(2):
            fit = criteria.build_fitness(DS, SPLITS[0].train_idx, SPEC)
            res = optim.make_optimizer(name, fit, n_bands=DS.n_bands, k=4, nfe_budget=200,
                                       seed=11, pop_size=10).run()
            got.append((tuple(res.bands), round(res.score, 9)))
        assert got[0] == got[1], '%s is not deterministic: %r vs %r' % (name, got[0], got[1])


def t_optimisers_beat_random():
    fit = criteria.build_fitness(DS, SPLITS[0].train_idx, SPEC)
    rng = np.random.default_rng(0)
    rand = []
    for _ in range(60):
        b = sorted(int(x) for x in rng.choice(DS.n_bands, size=4, replace=False))
        rand.append(fit(b))
    rand_mean = float(np.mean(rand))
    weak = 0
    for name in ('PSO', 'SAPSO', 'GA', 'SA', 'GWO', 'DE'):
        fit = criteria.build_fitness(DS, SPLITS[0].train_idx, SPEC)
        res = optim.make_optimizer(name, fit, n_bands=DS.n_bands, k=4, nfe_budget=400,
                                   seed=5, pop_size=12).run()
        assert res.score > rand_mean, '%s (%.4f) did not beat random (%.4f)' % (name, res.score, rand_mean)
        weak += 1
    assert weak == 6


def t_optimiser_k_none_and_k_all():
    fit = criteria.build_fitness(DS, SPLITS[0].train_idx, SPEC)
    res = optim.make_optimizer('PSO', fit, n_bands=DS.n_bands, k=None, nfe_budget=120, seed=1, pop_size=8).run()
    assert 1 <= res.k <= DS.n_bands
    fit = criteria.build_fitness(DS, SPLITS[0].train_idx, SPEC)
    res = optim.make_optimizer('SA', fit, n_bands=DS.n_bands, k=DS.n_bands, nfe_budget=60, seed=1).run()
    assert res.k == DS.n_bands
    try:
        optim.make_optimizer('NOPE', fit, n_bands=DS.n_bands, k=3)
    except KeyError:
        pass
    else:
        raise AssertionError('unknown method should raise KeyError')


def t_metrics():
    y = np.array([1, 1, 2, 2, 3, 3, 4, 4])
    assert abs(evaluate.classification_metrics(y, y)['OA'] - 100.0) < 1e-9
    assert abs(evaluate.classification_metrics(y, y)['Kappa'] - 1.0) < 1e-9
    m = evaluate.classification_metrics(y, np.array([1, 2, 2, 3, 3, 4, 4, 1]))
    assert 0 <= m['OA'] <= 100 and 0 <= m['AA'] <= 100
    assert m['Kappa'] < 1.0
    assert len(m['confusion']) == 4 and sum(sum(r) for r in m['confusion']) == 8
    rng = np.random.default_rng(0)
    rand_pred = rng.integers(1, 5, size=4000)
    rand_true = rng.integers(1, 5, size=4000)
    assert abs(evaluate.classification_metrics(rand_true, rand_pred)['Kappa']) < 0.1
    try:
        evaluate.classification_metrics(y, y[:-1])
    except ValueError:
        pass
    else:
        raise AssertionError('length mismatch should raise')


def t_evaluate_subset_can_find_signal():
    """A correct selector should beat a deliberately poor band choice."""
    spec = evaluate.CLASSIFIERS['knn5']
    fit = criteria.build_fitness(DS, SPLITS[0].train_idx, SPEC)
    res = optim.make_optimizer('SAPSO', fit, n_bands=DS.n_bands, k=4, nfe_budget=400,
                               seed=2, pop_size=12).run()
    good = evaluate.evaluate_subset(DS, SPLITS[0].train_idx, SPLITS[0].test_idx, res.bands, spec)
    bad_bands = list(range(0, 4))            # the first few consecutive bands are near-duplicates
    bad = evaluate.evaluate_subset(DS, SPLITS[0].train_idx, SPLITS[0].test_idx, bad_bands, spec)
    assert good['OA'] > 70.0, good['OA']
    assert good['OA'] >= bad['OA'] - 1e-9, 'selected %s (%.1f) vs adjacent %s (%.1f)' % (
        res.bands, good['OA'], bad_bands, bad['OA'])
    assert good['k'] == 4 and len(good['bands_1based']) == 4


def t_stats():
    rng = np.random.default_rng(0)
    a = rng.normal(90, 1, 10)
    b = rng.normal(88, 1, 10)
    t = evaluate.paired_test(a, b)
    assert t['t_test']['p_value'] < 0.05
    assert t['mean_diff'] > 0 and len(t['ci95_diff']) == 2
    assert t['ci95_diff'][0] <= t['mean_diff'] <= t['ci95_diff'][1]
    w = evaluate.wilcoxon_signed_rank(a, b)
    assert w['p_value'] == w['p_value']
    scores = {'A': list(rng.normal(92, 1, 10)), 'B': list(rng.normal(90, 1, 10)),
              'C': list(rng.normal(88, 1, 10)), 'D': list(rng.normal(86, 1, 10))}
    r = evaluate.average_ranks(scores)
    assert abs(sum(r.values()) - len(scores) * 2.5) < 1e-6
    assert r['A'] < r['D']
    f = evaluate.friedman_test(scores)
    assert f['p_value'] < 0.05 and f['n_methods'] == 4
    assert f['nemenyi_cd'] > 0
    assert evaluate.nemenyi_cd(4, 10) > 0
    assert evaluate.nemenyi_cd(99, 10) is None
    lo, hi = evaluate.bootstrap_ci(list(rng.normal(90, 2, 30)))
    assert lo < hi
    d = evaluate.describe_block(list(rng.normal(90, 2, 30)))
    assert d['min'] <= d['median'] <= d['max']


def t_tables_and_figures():
    tmp = tempfile.mkdtemp(prefix='hsbs_')
    try:
        t = report.three_line_table(['A', 'B'], [[1, 2], [3, 4]], caption='Cap')
        assert '| A | B |' in t['markdown'] and 'Cap' in t['markdown']
        assert '<thead>' in t['html'] and '<tbody>' in t['html'] and '<th>' in t['html']
        assert '\\toprule' in t['latex'] and '\\bottomrule' in t['latex']
        for ext in ('.md', '.csv', '.tex', '.html'):
            p = report.write_table(os.path.join(tmp, 'tab' + ext), ['A', 'B'], [[1, 2]], caption='c')
            assert os.path.getsize(p) > 0
        fig_dir = report.ensure_dir(os.path.join(tmp, 'fig'))
        p = report.plot_convergence({'PSO': [1, 2, 3, 3.5], 'GA': [1, 1.5, 2.9, 3.1]},
                                    os.path.join(fig_dir, 'conv'))
        assert os.path.getsize(p) > 1000 and p.endswith('.pdf')
        assert os.path.isfile(p.replace('.pdf', '.png'))
        p = report.plot_oa_vs_k({'PSO': [80, 88, 91]}, [2, 4, 6], os.path.join(fig_dir, 'oak'))
        assert os.path.getsize(p) > 1000
        p = report.plot_metric_boxplot({'PSO': [88, 89, 90], 'GA': [86, 87, 88]},
                                       os.path.join(fig_dir, 'box'))
        assert os.path.getsize(p) > 1000
        p = report.plot_runtime_vs_oa({'PSO': 12.0, 'GA': 9.0}, {'PSO': 90.1, 'GA': 89.4},
                                      os.path.join(fig_dir, 'rt'))
        assert os.path.getsize(p) > 1000
        gt = DS.gt
        pred = np.where(gt > 0, gt, 0)
        p = report.plot_classification_map(pred, gt, os.path.join(fig_dir, 'map'),
                                           panels={'pred': pred})
        assert os.path.getsize(p) > 1000
        cm = evaluate.classification_metrics(LABELS[LABELS > 0], LABELS[LABELS > 0])['confusion']
        p = report.plot_confusion(np.asarray(cm), [1, 2, 3, 4], os.path.join(fig_dir, 'cm'))
        assert os.path.getsize(p) > 1000
        p = report.plot_rank_cd({'A': 1.2, 'B': 2.4, 'C': 3.1, 'D': 3.3}, 1.5,
                                os.path.join(fig_dir, 'cd'))
        assert os.path.getsize(p) > 1000
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t_end_to_end():
    tmp = tempfile.mkdtemp(prefix='hsbs_')
    try:
        cfg = SelectionConfig(methods=['PSO', 'SAPSO', 'GA', 'SA', 'GWO', 'DE'],
                              k_main=4, k_sweep=[2, 6], nfe_budget=250, pop_size=10,
                              folds=[1, 2], classifiers=['knn5', 'rf'],
                              sweep_classifiers=['knn5'], fitness=SPEC,
                              reference_method='SAPSO')
        summ = run_experiment(DS, SPLITS, cfg, tmp, n_jobs=1, resume=True, verbose=False)
        assert summ['n_selection_rows'] == 6 * 3 * 2, summ['n_selection_rows']
        assert os.path.isfile(os.path.join(tmp, 'summary.json'))
        assert os.path.isfile(os.path.join(tmp, 'tables', 'table_band_selection.md'))
        assert os.path.isfile(os.path.join(tmp, 'tables', 'table_classification.md'))
        assert os.path.isfile(os.path.join(tmp, 'tables', 'table_significance.md'))
        assert os.path.isfile(os.path.join(tmp, 'tables', 'friedman.json'))
        for f in ('fig_convergence.pdf', 'fig_oa_boxplot.pdf', 'fig_runtime_vs_oa.pdf', 'fig_oa_vs_k.pdf'):
            p = os.path.join(tmp, 'figures', f)
            assert os.path.isfile(p) and os.path.getsize(p) > 1000, p
        assert len(summ['oa_by_method']) == 6
        assert all(0 < v <= 100 for v in summ['oa_by_method'].values())

        # resume must not recompute
        before = os.path.getsize(os.path.join(tmp, 'selection.jsonl'))
        summ2 = run_experiment(DS, SPLITS, cfg, tmp, n_jobs=1, resume=True, verbose=False)
        assert os.path.getsize(os.path.join(tmp, 'selection.jsonl')) == before
        assert summ2['n_selection_rows'] == summ['n_selection_rows']

        # parallel path
        tmp2 = tempfile.mkdtemp(prefix='hsbs_')
        try:
            cfg2 = SelectionConfig(methods=['PSO', 'GA'], k_main=4, nfe_budget=120,
                                   pop_size=8, folds=[1], classifiers=['knn5'], fitness=SPEC)
            s3 = run_experiment(DS, SPLITS, cfg2, tmp2, n_jobs=2, resume=True, verbose=False)
            assert s3['n_selection_rows'] == 2 * 1 * 2, s3['n_selection_rows']
        finally:
            shutil.rmtree(tmp2, ignore_errors=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t_config_roundtrip():
    cfg = SelectionConfig(methods=['SAPSO'], k_main=4, k_sweep=[2, 8], nfe_budget=500,
                          fitness=criteria.FitnessSpec(reduce='sum', redundancy_penalty=0.1, name='X'))
    d = cfg.as_dict()
    back = SelectionConfig.from_dict(d)
    assert back.methods == cfg.methods and back.k_sweep == cfg.k_sweep
    assert back.fitness.redundancy_penalty == 0.1 and back.fitness.name == 'X'
    assert d['fitness']['reduce'] == 'sum'


def main() -> int:
    print('hsbs self-test  (synthetic 40x40x24, 4 classes)')
    print('-' * 62)
    tests = [
        ('dataset construction', t_dataset),
        ('dataset guards', t_dataset_guards),
        ('loaders round-trip (.npy/.npz/.mat)', t_loader_roundtrip),
        ('JM scale probe (manuscript 13.6169)', t_scale_probe),
        ('JM / Bhattacharyya / correlation', t_jm),
        ('shared stratified splits', t_splits),
        ('fitness function and cache', t_fitness),
        ('optimiser output shape and budget', t_optimisers_shape),
        ('optimiser determinism', t_optimisers_determinism),
        ('optimisers beat random search', t_optimisers_beat_random),
        ('k = None and k = all bands', t_optimiser_k_none_and_k_all),
        ('classification metrics', t_metrics),
        ('selector finds informative bands', t_evaluate_subset_can_find_signal),
        ('statistical tests', t_stats),
        ('tables and figures', t_tables_and_figures),
        ('config round-trip', t_config_roundtrip),
        ('end-to-end grid + resume + parallel', t_end_to_end),
    ]
    for name, fn in tests:
        check(name, fn)
    print('-' * 62)
    print('%d passed, %d failed' % (len(PASS), len(FAIL)))
    if FAIL:
        print('\nfailures:')
        for n, e in FAIL:
            print('  - %s: %s' % (n, e))
        return 1
    print('all good -- the framework is ready for the real cube.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
