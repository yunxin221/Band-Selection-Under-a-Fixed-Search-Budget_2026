"""Experiment orchestration: grid execution, caching, resume, aggregation.

One command drives the whole comparison:

    python -m hsbs.runner --config configs/longkou.json

Results are appended to JSONL caches, so an interrupted run resumes without
recomputing anything. The aggregation step then emits the tables and figures
that go straight into the manuscript.
"""
from __future__ import annotations

import hashlib
import json
import os
import signal
import sys
import time
from dataclasses import dataclass, field, asdict
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

from . import criteria, data, evaluate, optim, report, selectors
from . import split as split_mod

__all__ = ['SelectionConfig', 'JsonlCache', 'run_experiment', 'dataset_fingerprint',
           'aggregate', 'DEFAULT_K_SWEEP', 'load_config', 'build_context', 'main']


DEFAULT_K_SWEEP = [2, 4, 6, 8, 10, 15, 20, 30]


# --------------------------------------------------------------------- cache
class JsonlCache:
    """Append-only JSONL store keyed by a composite key, with resume support."""

    def __init__(self, path: str) -> None:
        self.path = path
        self.rows: List[Dict[str, object]] = []
        self._keys = set()
        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        if os.path.isfile(path):
            with open(path, 'r', encoding='utf-8') as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    self.rows.append(rec)
                    self._keys.add(rec.get('_key'))

    def has(self, key: str) -> bool:
        return key in self._keys

    def add(self, key: str, row: Dict[str, object]) -> None:
        if 'error' in row:
            # never persist a failed job: a fixed method must be retried on resume
            # instead of being served the stale error from cache.
            return
        row = dict(row)
        row['_key'] = key
        self.rows.append(row)
        self._keys.add(key)
        with open(self.path, 'a', encoding='utf-8') as fh:
            fh.write(json.dumps(row, ensure_ascii=False, default=_jsonify) + '\n')

    def get(self, key: str) -> Optional[Dict[str, object]]:
        for r in self.rows:
            if r.get('_key') == key:
                return r
        return None

    def __len__(self) -> int:
        return len(self.rows)


def _params_digest(params) -> str:
    """Stable short hash of the per-method parameters (cache-key ingredient)."""
    if not params:
        return '-'
    return hashlib.sha1(json.dumps(params, sort_keys=True, default=str).encode('utf-8')).hexdigest()[:8]


def _jsonify(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    return str(o)


# --------------------------------------------------------------------- config
@dataclass
class SelectionConfig:
    methods: List[str] = field(default_factory=lambda: ['PSO', 'SAPSO', 'GA', 'SA', 'GWO', 'DE'])
    k_main: Optional[int] = 4
    k_sweep: List[int] = field(default_factory=list)
    nfe_budget: int = 3000
    pop_size: int = 30
    folds: List[int] = field(default_factory=lambda: [1])
    classifiers: List[str] = field(default_factory=lambda: ['knn5'])
    sweep_classifiers: List[str] = field(default_factory=list)
    cv_folds: int = 1
    ratio: float = 0.20
    fitness: criteria.FitnessSpec = field(default_factory=criteria.FitnessSpec)
    reference_method: str = 'SAPSO'
    method_params: Dict[str, Dict[str, object]] = field(default_factory=dict)
    method_fitness: Dict[str, Dict[str, object]] = field(default_factory=dict)
    """Per-method FitnessSpec overrides (subset of FitnessSpec fields). Lets one
    method (e.g. the contribution-(ii) JMRED redundancy-penalty variants) use a
    different objective than the run's shared baseline without forking the config."""

    def as_dict(self) -> Dict[str, object]:
        d = asdict(self)
        d['fitness'] = self.fitness.as_dict()
        return d

    @classmethod
    def from_dict(cls, d: Dict[str, object]) -> 'SelectionConfig':
        d = dict(d)
        fit = d.pop('fitness', None)
        cfg = cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})
        if fit:
            cfg.fitness = criteria.FitnessSpec(**{k: v for k, v in fit.items() if k in criteria.FitnessSpec.__dataclass_fields__})
        return cfg


# --------------------------------------------------------------------- fingerprint
def dataset_fingerprint(ds) -> str:
    h = hashlib.sha1()
    h.update(str(ds.cube.shape).encode())
    h.update(np.asarray(ds.gt, dtype=np.int32).tobytes())
    sub = ds.cube[:: max(1, ds.height // 8), :: max(1, ds.width // 8), :: max(1, ds.n_bands // 8)]
    h.update(np.asarray(sub, dtype=np.float32).tobytes())
    return h.hexdigest()[:12]


# --------------------------------------------------------------------- workers
def _task_select(payload: Dict[str, object]) -> Dict[str, object]:
    ds = payload['ds']
    method = payload['method']
    k = payload['k']
    seed = payload['seed']
    spec = payload['spec']
    try:
        fit = criteria.build_fitness(ds, payload['train_idx'], spec)
        opt_key = optim.ALIASES.get(method.upper(), method.upper())
        if opt_key in optim.REGISTRY:
            opt = optim.make_optimizer(opt_key, fit, n_bands=ds.n_bands, k=k,
                                       nfe_budget=payload['nfe'], seed=seed,
                                       pop_size=payload['pop_size'],
                                       **(payload.get('params') or {}))
            res = opt.run()
            comp = fit.components(res.bands)
            return {'method': method, 'k': k, 'seed': seed,
                    'bands_0based': res.bands, 'bands_1based': res.bands_1based,
                    'objective': res.score, 'nfe': res.nfe, 'runtime_s': res.runtime_s,
                    'history': _decimate(res.history),
                    'jm_mean': comp['jm_mean'], 'jm_max': comp['jm_max'], 'jm_min': comp['jm_min'],
                    'mean_abs_corr': comp['mean_abs_corr'], 'max_abs_corr': comp['max_abs_corr'],
                    'n_pairs': comp['n_pairs'], 'optim_extra': res.extra}
        # static (non-iterative) band selector: no JM optimisation, no NFE budget
        t0 = time.perf_counter()
        bands = selectors.select_bands(method, fit.matrix, fit.labels, k,
                                       seed=seed, **(payload.get('params') or {}))
        rt = float(time.perf_counter() - t0)
        comp = fit.components(bands)
        return {'method': method, 'k': k, 'seed': seed,
                'bands_0based': bands, 'bands_1based': [b + 1 for b in bands],
                'objective': comp['objective'], 'nfe': 0, 'runtime_s': rt,
                'history': [comp['objective']],
                'jm_mean': comp['jm_mean'], 'jm_max': comp['jm_max'], 'jm_min': comp['jm_min'],
                'mean_abs_corr': comp['mean_abs_corr'], 'max_abs_corr': comp['max_abs_corr'],
                'n_pairs': comp['n_pairs'], 'optim_extra': {}}
    except Exception as exc:  # record failure instead of aborting the whole run
        import traceback as _tb
        print('[select-error] %s seed=%s k=%s: %s: %s' % (method, seed, k, type(exc).__name__, exc),
              file=sys.stderr, flush=True)
        _tb.print_exc()
        return {'method': method, 'k': k, 'seed': seed, 'error': '%s: %s' % (type(exc).__name__, exc),
                'bands_0based': [], 'bands_1based': [], 'objective': float('nan'),
                'nfe': 0, 'runtime_s': 0.0, 'history': [], 'jm_mean': float('nan'),
                'jm_max': float('nan'), 'jm_min': float('nan'), 'mean_abs_corr': float('nan'),
                'max_abs_corr': float('nan'), 'n_pairs': 0, 'optim_extra': {}}


def _task_classify(payload: Dict[str, object]) -> Dict[str, object]:
    ds = payload['ds']
    spec = evaluate.CLASSIFIERS[payload['classifier']]
    out = evaluate.evaluate_subset(ds, payload['train_idx'], payload['test_idx'],
                                   payload['bands'], spec)
    out.update({'method': payload['method'], 'seed': payload['seed'],
                'k': int(payload['k']), 'classifier': payload['classifier'],
                'fold': int(payload.get('fold', 0))})
    out.pop('confusion', None)
    return out


def _decimate(hist: Sequence[float], max_points: int = 400) -> List[float]:
    y = np.asarray(hist, dtype=np.float64)
    if y.size <= max_points:
        return [float(v) for v in y]
    sel = np.unique(np.linspace(0, y.size - 1, max_points).astype(int))
    return [float(v) for v in y[sel]]


def _run_in_batches(worker, jobs: List[Dict[str, object]], cache: 'JsonlCache',
                    n_jobs: int, verbose: bool, phase: str, n_checkpoints: int = 30,
                    progress_cb=None) -> None:
    """Run `worker` over `jobs` in chunks, persisting each chunk to `cache` as it
    finishes.

    The original loop ran every job in one `Parallel(...)` call and only wrote
    results after *all* of them returned. A killed process therefore lost the
    whole phase. Chunking makes the run crash-resilient: if the process dies
    mid-run, only the in-flight chunk is lost, and a resumed run (JsonlCache
    reads the partial file back on init) skips the finished jobs.
    """
    from joblib import Parallel, delayed
    import os as _os
    n = len(jobs)
    if n == 0:
        return
    # Each chunk must be large enough to actually saturate the workers. When
    # n < n_checkpoints the naive ceil(n / n_checkpoints) collapses to 1, which
    # serialises the whole phase and lets a single slow task block everything.
    n_workers = n_jobs if (isinstance(n_jobs, int) and n_jobs > 0) else max(1, (_os.cpu_count() or 8))
    bs = max(n_workers, (n + n_checkpoints - 1) // n_checkpoints)
    done = 0
    for i in range(0, n, bs):
        batch = jobs[i:i + bs]
        if verbose:
            tag = ','.join(sorted({str(j.get('method')) for j in batch}))
            print('[%s] batch %d-%d (methods: %s)' % (phase, i, min(i + bs, n), tag), flush=True)
        out = Parallel(n_jobs=n_jobs, verbose=0)(
            delayed(worker)(j) for j in batch)
        for j, r in zip(batch, out):
            cache.add(j['key'], r)
            done += 1
        if progress_cb:
            try:
                progress_cb(phase, done, n)
            except Exception:
                pass
        if verbose:
            print('[%s] %d/%d jobs checkpointed' % (phase, done, n), flush=True)


# --------------------------------------------------------------------- runner
def run_experiment(ds, splits: Sequence, cfg: SelectionConfig, out_dir: str,
                   n_jobs: int = -1, resume: bool = True, verbose: bool = True,
                   do_classify: bool = True, progress_cb=None) -> Dict[str, object]:
    """Run the whole grid and write tables + figures under `out_dir`."""
    from joblib import Parallel, delayed

    os.makedirs(out_dir, exist_ok=True)
    fig_dir = report.ensure_dir(os.path.join(out_dir, 'figures'))
    tab_dir = report.ensure_dir(os.path.join(out_dir, 'tables'))

    fp = dataset_fingerprint(ds)
    sel_cache = JsonlCache(os.path.join(out_dir, 'selection.jsonl'))
    cls_cache = JsonlCache(os.path.join(out_dir, 'classification.jsonl'))

    plan: List[Tuple[int, Optional[int]]] = []
    if cfg.k_main:
        plan.append((cfg.k_main, None))
    for k in cfg.k_sweep:
        if k != cfg.k_main:
            plan.append((k, 'sweep'))

    split_of = {s.seed: s for s in splits}
    jobs = []
    for k, tag in plan:
        for m in cfg.methods:
            params = cfg.method_params.get(m) or {}
            fov = cfg.method_fitness.get(m)
            # A per-method fitness override forks the objective (e.g. the
            # contribution-(ii) redundancy-penalty term). Build a tailored copy
            # and bake it into the cache key so the three beta conditions never
            # share rows with the baseline (penalty-free) run.
            fit_spec = cfg.fitness
            if fov:
                fit_spec = cfg.fitness.clone_with(**fov)
            ptag = _params_digest(params)
            if fov:
                ptag = _params_digest({'_base': ptag, '_fit': fov})
            for s in splits:
                # NFE budget, population size and per-method parameters all change
                # the search, so they must be part of the cache key -- otherwise a
                # cheaper run silently reuses rows produced under a larger budget.
                key = _sel_key(fp, m, k, s.seed, cfg, ptag)
                if resume and sel_cache.has(key):
                    continue
                jobs.append({'key': key, 'ds': ds, 'method': m, 'k': k, 'seed': s.seed,
                             'train_idx': s.train_idx, 'spec': fit_spec,
                             'nfe': cfg.nfe_budget, 'pop_size': cfg.pop_size,
                             'params': cfg.method_params.get(m)})
    if verbose:
        print('[selection] %d jobs (%d already cached)' % (len(jobs), len(sel_cache)))
    if jobs:
        t0 = time.perf_counter()
        _run_in_batches(_task_select, jobs, sel_cache, n_jobs, verbose, 'selection',
                        progress_cb=progress_cb)
        if verbose:
            print('[selection] done in %.1f s' % (time.perf_counter() - t0))

    results = [r for r in sel_cache.rows if 'error' not in r]

    if do_classify:
        cv = max(1, int(getattr(cfg, 'cv_folds', 1)))
        cv_folds = make_cv_folds(ds.labels(), cv, [s.seed for s in splits]) if cv > 1 else None
        cjobs = []
        for r in results:
            k = int(r['k'])
            clfs = list(cfg.classifiers) + (list(cfg.sweep_classifiers) if k not in (cfg.k_main,) else [])
            ptag = _params_digest(cfg.method_params.get(r['method']) or {})
            for clf in dict.fromkeys(clfs):
                if cv_folds:
                    folds = cv_folds[int(r['seed'])]
                    for f, (tri, tei) in enumerate(folds):
                        key = _clf_key(fp, r['method'], k, r['seed'], clf, cfg, ptag, fold=f)
                        if resume and cls_cache.has(key):
                            continue
                        cjobs.append({'key': key, 'ds': ds, 'method': r['method'], 'seed': r['seed'],
                                      'fold': f, 'k': k, 'classifier': clf, 'bands': r['bands_0based'],
                                      'train_idx': tri, 'test_idx': tei})
                else:
                    key = _clf_key(fp, r['method'], k, r['seed'], clf, cfg, ptag, fold=None)
                    if resume and cls_cache.has(key):
                        continue
                    sp = split_of[int(r['seed'])]
                    cjobs.append({'key': key, 'ds': ds, 'method': r['method'], 'seed': r['seed'],
                                  'k': k, 'classifier': clf, 'bands': r['bands_0based'],
                                  'train_idx': sp.train_idx, 'test_idx': sp.test_idx})
        if verbose:
            print('[classification] %d jobs (%d already cached)' % (len(cjobs), len(cls_cache)))
        if cjobs:
            t0 = time.perf_counter()
            _run_in_batches(_task_classify, cjobs, cls_cache, n_jobs, verbose, 'classification',
                            progress_cb=progress_cb)
            if verbose:
                print('[classification] done in %.1f s' % (time.perf_counter() - t0))

    summary = aggregate(ds, results, list(cls_cache.rows), cfg, tab_dir, fig_dir, verbose=verbose)
    summary['dataset'] = ds.name
    summary['fingerprint'] = fp
    summary['config'] = cfg.as_dict()
    with open(os.path.join(out_dir, 'summary.json'), 'w', encoding='utf-8') as fh:
        json.dump(summary, fh, ensure_ascii=False, indent=2, default=_jsonify)
    return summary


# --------------------------------------------------------------------- aggregation
def aggregate(ds, selection: List[Dict[str, object]], classification: List[Dict[str, object]],
              cfg: SelectionConfig, tab_dir: str, fig_dir: str, verbose: bool = True) -> Dict[str, object]:
    """Build tables and figures from cached rows."""
    by_method: Dict[str, List[Dict[str, object]]] = {}
    for r in selection:
        if 'error' in r:
            continue
        if int(r['k']) != (cfg.k_main or -1):
            continue
        by_method.setdefault(r['method'], []).append(r)

    headers = ['Method', 'Selected bands (1-based)', 'Objective (mean +/- std)',
               'JM mean', 'Mean |r|', 'Runtime (s)', 'NFE']
    rows = []
    for m in cfg.methods:
        recs = sorted(by_method.get(m, []), key=lambda r: r['seed'])
        if not recs:
            continue
        obj = np.array([float(r['objective']) for r in recs])
        jm = np.array([float(r['jm_mean']) for r in recs])
        red = np.array([float(r['mean_abs_corr']) for r in recs])
        rt = np.array([float(r['runtime_s']) for r in recs])
        bands = sorted(recs[0]['bands_1based'])
        rows.append([m, ' '.join(str(b) for b in bands),
                     '%.4f +/- %.4f' % (obj.mean(), obj.std(ddof=1) if obj.size > 1 else 0.0),
                     '%.4f' % jm.mean(), '%.4f' % red.mean(), '%.1f' % rt.mean(),
                     int(np.mean([int(r['nfe']) for r in recs]))])
    report.write_table(os.path.join(tab_dir, 'table_band_selection.md'), headers, rows,
                       caption='Table A. Band-selection layer, k = %s.' % cfg.k_main)

    # ---- classification layer
    clf_rows = []
    per_clf: Dict[str, Dict[str, List[float]]] = {}
    main_clf = cfg.classifiers[0] if cfg.classifiers else 'knn5'
    csel = [r for r in classification if int(r['k']) == (cfg.k_main or -1) and r['classifier'] == main_clf]
    cby: Dict[str, List[Dict[str, object]]] = {}
    for r in csel:
        cby.setdefault(r['method'], []).append(r)
    for m in cfg.methods:
        recs = sorted(cby.get(m, []), key=lambda r: r['seed'])
        if not recs:
            continue
        oa = np.array([float(r['OA']) for r in recs])
        aa = np.array([float(r['AA']) for r in recs])
        kap = np.array([float(r['Kappa']) for r in recs])
        f1 = np.array([float(r.get('macro_F1', 0.0)) for r in recs])
        per_clf[m] = oa.tolist()
        clf_rows.append([m, '%.2f +/- %.2f' % (oa.mean(), oa.std(ddof=1) if oa.size > 1 else 0.0),
                         '%.2f +/- %.2f' % (aa.mean(), aa.std(ddof=1) if aa.size > 1 else 0.0),
                         '%.4f +/- %.4f' % (kap.mean(), kap.std(ddof=1) if kap.size > 1 else 0.0),
                         '%.2f' % f1.mean(), len(recs)])
    cv = max(1, int(getattr(cfg, 'cv_folds', 1)))
    n_seeds = len({int(r['seed']) for r in csel}) if csel else 0
    eval_desc = ('%d seeds x %d-fold CV' % (n_seeds, cv)) if cv > 1 else ('%d seeds' % n_seeds)
    report.write_table(os.path.join(tab_dir, 'table_classification.md'),
                       ['Method', 'OA (%)', 'AA (%)', 'Kappa', 'macro F1 (%)', 'n'],
                       clf_rows, caption='Table B. Classification layer with %s, k = %s (mean +/- std over %s).'
                       % (main_clf, cfg.k_main, eval_desc))

    # ---- significance vs the reference method
    sig_rows = []
    ref = cfg.reference_method
    if ref in per_clf and len(per_clf[ref]) >= 2:
        for m in per_clf:
            if m == ref:
                continue
            t = evaluate.paired_test(per_clf[m], per_clf[ref])
            p = t['t_test']['p_value']
            sig_rows.append([m, '%.2f' % t['mean_a'], '%.2f' % t['mean_b'],
                             '%+.2f' % t['mean_diff'],
                             '%.4f' % p if p == p else 'n/a',
                             'yes' if (p == p and p < 0.05) else 'no',
                             '%.4f' % t['wilcoxon']['p_value'] if t['wilcoxon']['p_value'] == t['wilcoxon']['p_value'] else 'n/a',
                             '[%+.2f, %+.2f]' % tuple(t['ci95_diff']) if 'ci95_diff' in t else 'n/a'])
        report.write_table(os.path.join(tab_dir, 'table_significance.md'),
                           ['Method', 'OA mean', '%s mean' % ref, 'Diff', 'p (paired t)',
                            'p < 0.05', 'p (Wilcoxon)', '95%% CI of diff'], sig_rows,
                           caption='Table C. Paired comparison against %s over the shared seeds.' % ref)
        fried = evaluate.friedman_test(per_clf)
        with open(os.path.join(tab_dir, 'friedman.json'), 'w', encoding='utf-8') as fh:
            json.dump(fried, fh, ensure_ascii=False, indent=2, default=_jsonify)

    # ---- figures
    histories = {}
    for m, recs in by_method.items():
        if recs:
            histories[m] = recs[0]['history']
    if histories:
        report.plot_convergence(histories, os.path.join(fig_dir, 'fig_convergence'))
    if per_clf:
        report.plot_metric_boxplot(per_clf, os.path.join(fig_dir, 'fig_oa_boxplot'),
                                   ylabel='OA (%)')
    rt = {m: float(np.mean([float(r['runtime_s']) for r in recs])) for m, recs in by_method.items() if recs}
    oa_mean = {m: float(np.mean(v)) for m, v in per_clf.items()}
    if rt and oa_mean:
        common = {m: rt[m] for m in rt if m in oa_mean}
        report.plot_runtime_vs_oa(common, oa_mean, os.path.join(fig_dir, 'fig_runtime_vs_oa'))

    # ---- k sweep
    sweep_k = sorted({int(r['k']) for r in selection})
    if len(sweep_k) > 1 and classification:
        curves: Dict[str, List[float]] = {}
        for m in cfg.methods:
            ys = []
            ok = True
            for k in sweep_k:
                vals = [float(r['OA']) for r in classification
                        if r['method'] == m and int(r['k']) == k and r['classifier'] == main_clf]
                if not vals:
                    ok = False
                    break
                ys.append(float(np.mean(vals)))
            if ok:
                curves[m] = ys
        if curves:
            report.plot_oa_vs_k(curves, sweep_k, os.path.join(fig_dir, 'fig_oa_vs_k'))

    summary = {
        'n_selection_rows': len(selection),
        'n_classification_rows': len(classification),
        'methods': cfg.methods,
        'k_main': cfg.k_main,
        'k_sweep': sweep_k,
        'oa_by_method': oa_mean,
        'runtime_by_method': rt,
        'band_selection_table': rows,
        'classification_table': clf_rows,
    }
    if verbose:
        print('[aggregate] tables -> %s' % tab_dir)
        print('[aggregate] figures -> %s' % fig_dir)
    return summary


# --------------------------------------------------------------------- config file entry
def _project_root(cfg_path: str) -> str:
    """Locate the project root that `data/raw/` lives under.

    Configs sit in <root>/code/configs/, so the default is three levels up. If
    the layout ever changes we walk upwards and take the first ancestor that
    actually contains data/raw or code/hsbs.
    """
    here = os.path.dirname(os.path.abspath(cfg_path))
    for _ in range(4):
        if os.path.isdir(os.path.join(here, 'data', 'raw')) or os.path.isdir(os.path.join(here, 'code', 'hsbs')):
            return here
        parent = os.path.dirname(here)
        if parent == here:
            break
        here = parent
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(cfg_path))))


def _resolve(p: Optional[str], root: str) -> Optional[str]:
    if not p:
        return p
    if os.path.isabs(p):
        return p
    return os.path.normpath(os.path.join(root, p))


def _parse_seeds(spec) -> Optional[List[int]]:
    """Accept a list, or '1-10', or '1,2,5'."""
    if spec is None:
        return None
    if isinstance(spec, (list, tuple)):
        return [int(s) for s in spec]
    out: List[int] = []
    for tok in str(spec).split(','):
        tok = tok.strip()
        if not tok:
            continue
        if '-' in tok:
            a, b = tok.split('-', 1)
            out.extend(range(int(a), int(b) + 1))
        else:
            out.append(int(tok))
    return out or None


def _method_known(m: str) -> bool:
    key = optim.ALIASES.get(m.upper(), m.upper())
    return key in optim.REGISTRY or m.upper() in selectors.REGISTRY


def _sel_key(fp: str, m: str, k: int, seed: int, cfg, ptag: str) -> str:
    """Cache key for a selection job. Static selectors are NFE-independent (they
    do not consume the NFE budget), so we omit nfe/pop and tag them STATIC."""
    if m.upper() in selectors.REGISTRY:
        return '%s|%s|k%d|seed%d|%s|STATIC|%s' % (fp, m, k, seed, cfg.fitness.name, ptag)
    return '%s|%s|k%d|seed%d|%s|nfe%d|pop%d|%s' % (
        fp, m, k, seed, cfg.fitness.name, cfg.nfe_budget, cfg.pop_size, ptag)


def _clf_key(fp: str, m: str, k: int, seed: int, clf: str, cfg, ptag: str,
             fold: Optional[int]) -> str:
    """Cache key for a classification job. Static selectors are NFE-independent."""
    if m.upper() in selectors.REGISTRY:
        if fold is None:
            return '%s|%s|k%d|seed%d|%s|%s|STATIC|%s' % (fp, m, k, seed, clf, cfg.fitness.name, ptag)
        return '%s|%s|k%d|seed%d|fold%d|%s|%s|STATIC|%s' % (fp, m, k, seed, fold, clf, cfg.fitness.name, ptag)
    if fold is None:
        return '%s|%s|k%d|seed%d|%s|%s|nfe%d|pop%d|%s' % (
            fp, m, k, seed, clf, cfg.fitness.name, cfg.nfe_budget, cfg.pop_size, ptag)
    return '%s|%s|k%d|seed%d|fold%d|%s|%s|nfe%d|pop%d|%s' % (
        fp, m, k, seed, fold, clf, cfg.fitness.name, cfg.nfe_budget, cfg.pop_size, ptag)


def make_cv_folds(labels: np.ndarray, n_splits: int, seeds: Sequence[int]) -> Dict[int, List[Tuple[np.ndarray, np.ndarray]]]:
    """Stratified k-fold train/test index pairs per seed, over the full labelled set.

    Used by the classification layer when `cv_folds > 1` so that tiny classes
    (e.g. Indian Pines Oats / Grass-pasture-mowed) get a stable AA/Kappa estimate
    instead of a single noisy 20% split. Band selection itself still uses the
    single `--split` partition; only the classifier evaluation is cross-validated.
    """
    from sklearn.model_selection import StratifiedKFold
    labels = np.asarray(labels).ravel()
    idx = np.flatnonzero(labels != 0)
    y = labels[idx]
    out: Dict[int, List[Tuple[np.ndarray, np.ndarray]]] = {}
    for seed in seeds:
        skf = StratifiedKFold(n_splits=max(2, int(n_splits)), shuffle=True, random_state=int(seed))
        folds = []
        for tr_l, te_l in skf.split(idx, y):
            folds.append((idx[tr_l], idx[te_l]))
        out[int(seed)] = folds
    return out


def load_config(path: str) -> Dict[str, object]:
    with open(path, 'r', encoding='utf-8') as fh:
        cfg = json.load(fh)
    cfg['_path'] = os.path.abspath(path)
    return cfg


def build_context(cfg: Dict[str, object], *, out_dir: Optional[str] = None,
                  seeds=None, methods: Optional[str] = None,
                  k_main: Optional[int] = None, nfe: Optional[int] = None,
                  fresh: bool = False, verbose: bool = True):
    """Turn a config dict into (dataset, splits, SelectionConfig, out_dir, n_jobs)."""
    root = _project_root(str(cfg['_path']))
    d = dict(cfg.get('dataset') or {})

    ds = data.load_dataset(_resolve(d['path'], root),
                           gt_path=_resolve(d.get('gt_path'), root),
                           name=cfg.get('name'),
                           cube_key=d.get('cube_key'),
                           gt_key=d.get('gt_key'),
                           class_names={int(k): v for k, v in (d.get('class_names') or {}).items()},
                           wavelengths=d.get('wavelengths'))

    keep = d.get('keep_classes')
    if keep:
        keep = [int(c) for c in keep]
        ds.gt = np.where(np.isin(ds.gt, keep), ds.gt, 0).astype(np.int32)
        ds.class_names = {c: ds.class_names.get(c, 'class %d' % c) for c in keep}

    # ---- splits: generated once and cached, so every method sees the same partition
    sp = dict(cfg.get('split') or {})
    seed_list = _parse_seeds(seeds) or [int(s) for s in sp.get('seeds', [1])]
    ratio = float(sp.get('ratio', 0.2))
    cache = _resolve(sp.get('cache'), root)
    if cache:
        # incorporate the class subset into the cache identity so switching
        # keep_classes never silently reuses a split computed for a different subset
        keep_tag = 'all' if not keep else 'c' + '-'.join(str(c) for c in keep)
        cache = cache[:-4] + '_' + keep_tag + '.npz' if cache.endswith('.npz') else cache + '_' + keep_tag
    splits = None
    if cache and not fresh and os.path.isfile(cache):
        try:
            cand = split_mod.load_splits(cache)
            expected_classes = set(keep) if keep else set(ds.class_names.keys())
            cls_ok = all(set(s.per_class.keys()) == expected_classes for s in cand)
            if [s.seed for s in cand] == seed_list and abs(cand[0].ratio - ratio) < 1e-9 and cls_ok:
                splits = cand
            elif verbose:
                print('[split] cache %s does not match seeds/ratio/classes -- regenerating' % cache)
        except Exception as exc:                                    # pragma: no cover
            if verbose:
                print('[split] cache unreadable (%s) -- regenerating' % exc)
    if splits is None:
        splits = split_mod.make_splits(ds.labels(), ratio=ratio, seeds=seed_list,
                                       min_per_class=int(sp.get('min_per_class', 5)),
                                       max_per_class=sp.get('max_per_class'),
                                       verbose=verbose)
        if cache:
            os.makedirs(os.path.dirname(cache) or '.', exist_ok=True)
            split_mod.save_splits(cache, splits, meta={'dataset': ds.name})

    # ---- selection config
    merged = dict(cfg.get('selection') or {})
    merged.update(dict(cfg.get('classification') or {}))
    scfg = SelectionConfig.from_dict(merged)
    _cv = int((cfg.get('classification') or {}).get('cv_folds', 1) or 1)
    scfg.cv_folds = max(1, _cv)
    if methods:
        scfg.methods = [m.strip() for m in str(methods).split(',') if m.strip()]
    if k_main:
        scfg.k_main = int(k_main)
    if nfe:
        scfg.nfe_budget = int(nfe)
    scfg.folds = list(seed_list)
    unknown = [m for m in scfg.methods if not _method_known(m)]
    if unknown:
        raise SystemExit('unknown method(s) %s; available: %s'
                         % (', '.join(unknown), ', '.join(optim.list_methods())))

    out = out_dir or _resolve((cfg.get('output') or {}).get('dir'), root) or './runs'
    out = os.path.abspath(out)
    n_jobs = int((cfg.get('runtime') or {}).get('n_jobs', -1))
    return ds, splits, scfg, out, n_jobs


def _job_plan(scfg: SelectionConfig, n_seeds: int, do_classify: bool) -> Tuple[int, int]:
    ks = ([scfg.k_main] if scfg.k_main else []) + [k for k in scfg.k_sweep if k != scfg.k_main]
    n_sel = len(ks) * len(scfg.methods) * n_seeds
    n_clf = 0
    if do_classify:
        n_clf_per = max(1, len(dict.fromkeys(list(scfg.classifiers) + list(scfg.sweep_classifiers))))
        n_clf = n_sel * n_clf_per * max(1, int(scfg.cv_folds))
    return n_sel, n_clf


def main(argv: Optional[Sequence[str]] = None) -> int:
    import argparse

    ap = argparse.ArgumentParser(
        prog='python -m hsbs.runner',
        description='Run a full band-selection comparison from a JSON config.',
        epilog='example:\n'
               '  python -m hsbs.runner --config configs/longkou.json\n'
               '  python -m hsbs.runner --config configs/longkou.json --seeds 1-3 --methods PSO,SAPSO,MPSO --nfe 600\n'
               '  python -m hsbs.runner --config configs/indian_pines.json --dry-run\n')
    ap.add_argument('--config', required=True, help='path to a JSON config under code/configs/')
    ap.add_argument('--out', default=None, help='override output directory')
    ap.add_argument('--n-jobs', type=int, default=None, help='parallel workers (default: config runtime.n_jobs)')
    ap.add_argument('--seeds', default=None, help="override seeds, e.g. '1-10' or '1,2,5'")
    ap.add_argument('--methods', default=None, help='override method list, comma separated')
    ap.add_argument('--k-main', type=int, default=None, help='override k_main')
    ap.add_argument('--nfe', type=int, default=None, help='override the NFE budget (smoke tests)')
    ap.add_argument('--no-classify', action='store_true', help='run the selection layer only')
    ap.add_argument('--fresh', action='store_true', help='ignore existing caches and splits')
    ap.add_argument('--dry-run', action='store_true', help='print the plan and exit')
    ap.add_argument('--quiet', action='store_true')
    a = ap.parse_args(argv)

    cfg = load_config(a.config)
    ds, splits, scfg, out_dir, n_jobs = build_context(
        cfg, out_dir=a.out, seeds=a.seeds, methods=a.methods,
        k_main=a.k_main, nfe=a.nfe, fresh=a.fresh, verbose=not a.quiet)
    if a.n_jobs is not None:
        n_jobs = int(a.n_jobs)

    verbose = not a.quiet
    if verbose:
        print('config      : %s' % cfg['_path'])
        print('dataset     : %s  %s  bands=%d  classes=%s'
              % (ds.name, ds.cube.shape, ds.n_bands, ds.classes))
        warn = (cfg.get('dataset') or {}).get('warning')
        if warn:
            print('  WARNING   : %s' % warn)
        print(split_mod.split_summary(splits))
        print('methods     : %s' % ', '.join(scfg.methods))
        print('k_main      : %s   k_sweep: %s' % (scfg.k_main, scfg.k_sweep))
        print('budget      : NFE=%d, pop=%d, fitness=%s' % (scfg.nfe_budget, scfg.pop_size, scfg.fitness.name))
        print('classifiers : %s' % ', '.join(scfg.classifiers))
        print('output      : %s' % out_dir)

    n_sel, n_clf = _job_plan(scfg, len(splits), not a.no_classify)
    if verbose:
        print('plan        : %d selection jobs, %d classification jobs' % (n_sel, n_clf))
    if a.dry_run:
        return 0

    t0 = time.perf_counter()
    summary = run_experiment(ds, splits, scfg, out_dir, n_jobs=n_jobs,
                             resume=not a.fresh, verbose=verbose,
                             do_classify=not a.no_classify)
    if verbose:
        print('[done] %.1f s -> %s' % (time.perf_counter() - t0, out_dir))
        for m, oa in sorted(summary.get('oa_by_method', {}).items()):
            print('   %-10s OA %.2f%%   runtime %.1f s'
                  % (m, oa, summary.get('runtime_by_method', {}).get(m, float('nan'))))
    return 0


if __name__ == '__main__':                                          # pragma: no cover
    raise SystemExit(main())
