"""Batch 7 & 8 experiment driver (spatial-spectral models + robustness).

This single entry point prepares and runs every *new* experiment the revision
checklist asks for in batches 7-8, reusing the audited band-selection results
already in ``output/runs`` where possible so the dominant selection budget is
never paid twice.

Subcommands
-----------
  ablation   M-P0-1 + M-P0-2 : spectral-only full-band vs full-band + EM/SRF/RV
             spatial features -> attribute the 97.96% to the spatial-spectral
             joint features (band selection buys compactness, not accuracy).
  crosstable M-P0-2          : cross-selection-method spatial pipeline + Table 4
             with mean +/- std and an Indian-Pines column.
  disjoint   M-P1-6          : spatially disjoint (block/row) split vs random
             split -> quantify the spatial-leakage optimism bias.
  sensitivityM-P1-8         : eta/lambda sweep for the EM/EPF operators.
  jmrepro    M-P1-5          : JM saturation disclosure + SAPSO reproducibility rate.
  all        run every subcommand above that applies to the given dataset.

Usage
-----
  python batch7_8_run.py ablation  --dataset configs/longkou.json
  python batch7_8_run.py crosstable --dataset configs/longkou.json --runs output/runs/longkou_5cls
  python batch7_8_run.py disjoint  --dataset configs/longkou.json
  python batch7_8_run.py sensitivity --dataset configs/longkou.json
  python batch7_8_run.py jmrepro   --runs output/runs/longkou_5cls
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = HERE
sys.path.insert(0, HERE)

import numpy as np  # noqa: E402

from hsbs import data as hsdata, evaluate, spatial as hssp  # noqa: E402
from hsbs import split as split_mod  # noqa: E402
from hsbs import runner as hsrun  # noqa: E402


# --------------------------------------------------------------------- context
def load_context(config_path: str, seeds=None):
    """Build the dataset + shared random splits from an existing config."""
    cfg = hsrun.load_config(config_path)
    ds, splits, scfg, out, n_jobs = hsrun.build_context(
        cfg, seeds=seeds, verbose=False)
    return ds, splits, scfg, out


def _augment_dataset(ds, spec: hssp.SpatialSpec):
    feats = hssp.extract_features(ds.cube, spec)
    aug_cube = np.ascontiguousarray(
        np.concatenate([ds.cube, feats], axis=-1), dtype=np.float32)
    aug = hsdata.HSDataset(name=ds.name + '+' + spec.operator,
                           cube=aug_cube, gt=ds.gt,
                           class_names=ds.class_names, meta=ds.meta)
    return aug, feats.shape[-1]


def _augment_selected(ds, spec: hssp.SpatialSpec, bands, protocol: str = 'B'):
    """Spatial features computed on the SELECTED sub-cube; returns (aug, F, idx).

    Why this exists
    ---------------
    ``run_crosstable`` previously evaluated ``list(range(B)) + list(bands)``
    against an augmented cube laid out as ``[0..B-1] = spectral``,
    ``[B..B+F-1] = spatial``. Because ``bands`` always lies in ``[0, B-1]``, that
    indexed a *duplicate of the spectral bands* -- the spatial block (index >= B)
    was never touched, so the "+spatial" column silently reported full-band
    spectral accuracy. Measured on Indian Pines: the reported "+spatial" 71.10%
    matched spectral-only-full-band 71.00%, while the true joint feature reaches
    85.76% -- a 14.7 pp understatement of the spatial-spectral gain.

    Both protocols compute the operator on the selected sub-cube, which is what
    makes band selection pay off downstream:

      A  X = [selected spectral bands] + [spatial of selected bands]  (dim k+F)
      B  X = [all spectral bands]      + [spatial of selected bands]  (dim B+F)
    """
    sub = ds.cube[:, :, list(bands)]
    feats = hssp.extract_features(sub, spec)
    F = int(feats.shape[-1])
    if protocol == 'A':
        cube = np.concatenate([sub, feats], axis=-1)
        idx = list(range(len(bands))) + list(range(len(bands), len(bands) + F))
        tag = 'sel%d+%s' % (len(bands), spec.operator)
    else:
        cube = np.concatenate([ds.cube, feats], axis=-1)
        idx = list(range(ds.n_bands)) + list(range(ds.n_bands, ds.n_bands + F))
        tag = 'full%d+%s' % (ds.n_bands, spec.operator)
    aug = hsdata.HSDataset(name='%s+%s(sel)' % (ds.name, spec.operator),
                           cube=np.ascontiguousarray(cube, dtype=np.float32),
                           gt=ds.gt, class_names=ds.class_names, meta=ds.meta)
    return aug, F, idx, tag


def _eval_variant(ds, splits, bands, classifiers, label, out_dir, tag):
    """Evaluate one band subset under all classifiers x seeds; return aggregates."""
    per_seed = {c.key: [] for c in classifiers}
    rows = []
    for s in splits:
        for spec in classifiers:
            out = evaluate.evaluate_subset(ds, s.train_idx, s.test_idx, bands, spec)
            per_seed[spec.key].append(float(out['OA']))
            rec = {'seed': s.seed, 'classifier': spec.key,
                   'OA': out['OA'], 'AA': out['AA'], 'Kappa': out['Kappa']}
            rows.append(rec)
    agg = {}
    for c in classifiers:
        v = np.array(per_seed[c.key], dtype=np.float64)
        agg[c.key] = {'OA_mean': float(v.mean()), 'OA_std': float(v.std(ddof=1)) if v.size > 1 else 0.0,
                      'n': int(v.size)}
    return {'label': label, 'tag': tag, 'bands': [int(b) + 1 for b in bands],
            'n_bands': len(bands), 'per_classifier': agg, 'rows': rows}


# --------------------------------------------------------------------- ablation (M-P0-1 / M-P0-2)
def run_ablation(config_path: str, spatial_specs, classifiers_keys, out_dir: str, seeds=None) -> dict:
    ds, splits, _scfg, _out = load_context(config_path, seeds=seeds)
    classifiers = [evaluate.CLASSIFIERS[k] for k in classifiers_keys]
    B = ds.n_bands
    results = {'dataset': ds.name, 'n_bands_spectral': B, 'variants': []}

    # baseline: spectral-only full band
    spec0 = ds.classes
    base = _eval_variant(ds, splits, list(range(B)), classifiers,
                         'SPECTRAL-ONLY full band', 'spectral_full', out_dir)
    results['variants'].append({'variant': 'spectral_only', **base})

    for sp in spatial_specs:
        spec = hssp.SpatialSpec.from_dict(sp)
        aug, F = _augment_dataset(ds, spec)
        full = _eval_variant(aug, splits, list(range(B + F)), classifiers,
                             'FULLBAND + %s (eta=%s, lam=%s, n_pc=%d)'
                             % (spec.operator, spec.eta, spec.lam, spec.n_pc),
                             'full_%s' % spec.operator, out_dir)
        results['variants'].append({
            'variant': 'fullband_plus_%s' % spec.operator,
            'operator': spec.operator, 'eta': spec.eta, 'lam': spec.lam,
            'n_pc': spec.n_pc, 'F': int(F),
            'feature_detail': hssp.OPERATOR_REFS.get(spec.operator, ''),
            **full,
        })
        print('  [%s] %s: OA(knn5) %.2f%%  (+spatial vs spectral %.2f pp)'
              % (spec.operator, ds.name,
                 full['per_classifier']['knn5']['OA_mean'],
                 full['per_classifier']['knn5']['OA_mean']
                 - base['per_classifier']['knn5']['OA_mean']), flush=True)

    # honest attribution statement values
    knn = results['variants'][0]['per_classifier']['knn5']['OA_mean']
    results['attribution'] = {
        'claim': 'band selection buys compactness; spatial-spectral joint '
                 'features are responsible for accuracy',
        'spectral_full_knn5_OA': knn,
    }
    _dump(out_dir, 'ablation_summary.json', results)
    _write_ablation_md(out_dir, results)
    return results


def _write_ablation_md(out_dir, results):
    lines = ['# Batch7 Ablation -- spatial-spectral attribution (%s)' % results['dataset'],
             '', '| Variant | k | OA knn5 (mean+/-std) | AA | Kappa |',
             '|---|---|---|---|---|']
    for v in results['variants']:
        k = v['per_classifier']['knn5']
        aa = v.get('rows', [{}])
        aa_m = float(np.mean([r['AA'] for r in aa])) if aa else float('nan')
        kap = float(np.mean([r['Kappa'] for r in aa])) if aa else float('nan')
        lines.append('| %s | %d | %.2f +/- %.2f | %.2f | %.4f |'
                     % (v['label'], v['n_bands'], k['OA_mean'], k['OA_std'], aa_m, kap))
    lines += ['', '## Attribution', '- ' + results['attribution']['claim'],
              '- spectral-only full-band OA (knn5) = %.2f%%'
              % results['attribution']['spectral_full_knn5_OA']]
    with open(os.path.join(out_dir, 'ablation_table.md'), 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(lines) + '\n')


# --------------------------------------------------------------------- cross-selection spatial pipeline + Table4 (M-P0-2)
def run_crosstable(config_path: str, spatial_spec, classifiers_keys, runs_dir: str, out_dir: str, seeds=None, protocol: str = 'B') -> dict:
    """Re-evaluate each existing selection method's bands under the spatial
    pipeline, so Table 4 gains mean+/-std and (for Indian Pines) a second scene.
    Reuses the already-paid selection results in ``runs_dir``.

    ``protocol`` selects how the spatial block is concatenated -- see
    ``_augment_selected``. Default 'B' keeps the full spectral stack and
    appends spatial features of the selected bands; 'A' is the fully compact
    variant whose feature dimension is k + F.
    """
    ds, splits, _scfg, _out = load_context(config_path, seeds=seeds)
    classifiers = [evaluate.CLASSIFIERS[k] for k in classifiers_keys]
    spec = hssp.SpatialSpec.from_dict(spatial_spec)

    sel_jsonl = os.path.join(runs_dir, 'selection.jsonl')
    methods_bands = _read_selection_bands(sel_jsonl, k=4)
    results = {'dataset': ds.name, 'operator': spec.operator, 'protocol': protocol,
               'methods': [], 'note': 'reuses %s selection bands (no re-run); '
                                      'spatial features computed on the selected sub-cube' % sel_jsonl}
    for method, seeds_bands in methods_bands.items():
        spec_only_oa, full_oa = [], []
        for seed, bands in seeds_bands:
            # spectral-only classification on the selected bands
            e0 = evaluate.evaluate_subset(ds, _train(splits, seed), _test(splits, seed), bands,
                                          evaluate.CLASSIFIERS['knn5'])
            spec_only_oa.append(float(e0['OA']))
            # selected bands carried into the spatial pipeline (FIXED indexing)
            aug_s, F, idx, _tag = _augment_selected(ds, spec, bands, protocol=protocol)
            eb = evaluate.evaluate_subset(aug_s, _train(splits, seed), _test(splits, seed),
                                          idx,
                                          evaluate.CLASSIFIERS['knn5'])
            full_oa.append(float(eb['OA']))
        results['methods'].append({
            'method': method,
            'OA_spectral_only_mean': float(np.mean(spec_only_oa)),
            'OA_spectral_only_std': float(np.std(spec_only_oa, ddof=1)) if len(spec_only_oa) > 1 else 0.0,
            'OA_plus_spatial_mean': float(np.mean(full_oa)),
            'OA_plus_spatial_std': float(np.std(full_oa, ddof=1)) if len(full_oa) > 1 else 0.0,
            'n_seeds': len(spec_only_oa),
        })
        print('  %-10s spectral %.2f+/-%.2f | +spatial %.2f+/-%.2f'
              % (method, results['methods'][-1]['OA_spectral_only_mean'],
                 results['methods'][-1]['OA_spectral_only_std'],
                 results['methods'][-1]['OA_plus_spatial_mean'],
                 results['methods'][-1]['OA_plus_spatial_std']), flush=True)
    _dump(out_dir, 'crosstable_summary.json', results)
    return results


def _read_selection_bands(jsonl_path, k=4):
    methods = {}
    if not os.path.isfile(jsonl_path):
        return methods
    with open(jsonl_path, 'r', encoding='utf-8') as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except json.JSONDecodeError:
                continue
            if 'error' in r or int(r.get('k', -1)) != k:
                continue
            methods.setdefault(r['method'], []).append((int(r['seed']), list(r['bands_0based'])))
    return methods


def _train(splits, seed):
    for s in splits:
        if s.seed == seed:
            return s.train_idx
    return splits[0].train_idx


def _test(splits, seed):
    for s in splits:
        if s.seed == seed:
            return s.test_idx
    return splits[0].test_idx


# --------------------------------------------------------------------- disjoint split (M-P1-6)
def run_disjoint(config_path: str, spatial_spec, classifiers_keys, out_dir: str, seeds=None) -> dict:
    ds, random_splits, _scfg, _out = load_context(config_path, seeds=seeds)
    classifiers = [evaluate.CLASSIFIERS[k] for k in classifiers_keys]
    spec = hssp.SpatialSpec.from_dict(spatial_spec)
    aug, F = _augment_dataset(ds, spec)
    B = ds.n_bands
    seeds = [s.seed for s in random_splits]

    results = {'dataset': ds.name, 'operator': spec.operator, 'modes': []}
    for mode in ('block', 'row'):
        dj = split_mod.make_disjoint_splits(ds.labels(), H=ds.height, W=ds.width,
                                            ratio=0.2, seeds=seeds,
                                            n_blocks=3, mode=mode)
        entry = {'mode': mode, 'n_blocks': 3, 'variants': {}}
        # spectral-only (no leakage expected) vs fullband+spatial (leakage probe)
        spec_only = _eval_variant(ds, dj, list(range(B)), classifiers,
                                  'spectral-only', 'sp', out_dir)
        full = _eval_variant(aug, dj, list(range(B + F)), classifiers,
                             'fullband+%s' % spec.operator, 'full', out_dir)
        entry['variants'] = {
            'spectral_only_knn5': spec_only['per_classifier']['knn5'],
            'fullband_plus_knn5': full['per_classifier']['knn5'],
        }
        entry['leakage_bias_pp'] = (full['per_classifier']['knn5']['OA_mean']
                                    - spec_only['per_classifier']['knn5']['OA_mean'])
        results['modes'].append(entry)
        print('  [%s] spectral %.2f | +spatial %.2f | bias %.2f pp'
              % (mode, entry['variants']['spectral_only_knn5']['OA_mean'],
                 entry['variants']['fullband_plus_knn5']['OA_mean'],
                 entry['leakage_bias_pp']), flush=True)
    _dump(out_dir, 'disjoint_summary.json', results)
    return results


# --------------------------------------------------------------------- sensitivity (M-P1-8)
def run_sensitivity(config_path: str, classifiers_keys, out_dir: str, seeds=None) -> dict:
    ds, splits, _scfg, _out = load_context(config_path, seeds=seeds)
    classifiers = [evaluate.CLASSIFIERS[k] for k in classifiers_keys]
    B = ds.n_bands
    results = {'dataset': ds.name, 'sweep': []}
    # EM radii sweep (eta) and EPF lambda sweep (lam); n_pc fixed for EM, window for EPF
    eta_grid = [3, 5, 7, 9]
    lam_grid = [0.001, 0.01, 0.1]
    for eta in eta_grid:
        sp = hssp.SpatialSpec(operator='morph', eta=[eta], lam=0.01, n_pc=4)
        aug, F = _augment_dataset(ds, sp)
        v = _eval_variant(aug, splits, list(range(B + F)), classifiers,
                          'EM eta=%d' % eta, 'x', out_dir)
        results['sweep'].append({'operator': 'morph', 'param': 'eta', 'value': eta,
                                 'F': int(F),
                                 'OA_knn5': v['per_classifier']['knn5']['OA_mean'],
                                 'OA_svm': v['per_classifier']['svm_rbf']['OA_mean'],
                                 'OA_rf': v['per_classifier']['rf']['OA_mean']})
        print('  EM eta=%d -> knn5 %.2f%%' % (eta, v['per_classifier']['knn5']['OA_mean']), flush=True)
    for lam in lam_grid:
        sp = hssp.SpatialSpec(operator='epf', eta=[5], lam=lam, n_pc=4)
        aug, F = _augment_dataset(ds, sp)
        v = _eval_variant(aug, splits, list(range(B + F)), classifiers,
                          'EPF lam=%g' % lam, 'x', out_dir)
        results['sweep'].append({'operator': 'epf', 'param': 'lam', 'value': lam,
                                 'F': int(F),
                                 'OA_knn5': v['per_classifier']['knn5']['OA_mean'],
                                 'OA_svm': v['per_classifier']['svm_rbf']['OA_mean'],
                                 'OA_rf': v['per_classifier']['rf']['OA_mean']})
        print('  EPF lam=%g -> knn5 %.2f%%' % (lam, v['per_classifier']['knn5']['OA_mean']), flush=True)
    _dump(out_dir, 'sensitivity_summary.json', results)
    return results


# --------------------------------------------------------------------- JM saturation + reproducibility (M-P1-5)
def analyze_jm_repro(selection_jsonl: str) -> dict:
    JM_CEIL = 14.1421  # theoretical Jeffries-Matusita ceiling
    rows = []
    with open(selection_jsonl, 'r', encoding='utf-8') as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except json.JSONDecodeError:
                continue
            if 'error' in r:
                continue
            rows.append(r)
    out = {'source': selection_jsonl, 'jm_ceiling': JM_CEIL, 'methods': []}
    by_method = {}
    for r in rows:
        by_method.setdefault(r['method'], []).append(r)
    for method, recs in by_method.items():
        jm = np.array([float(r.get('jm_mean', float('nan'))) for r in recs])
        saturated = float((jm >= 0.95 * JM_CEIL).mean()) if jm.size else float('nan')
        # reproducibility: distinct band subsets across seeds
        subsets = [tuple(sorted(r.get('bands_0based', []))) for r in recs]
        if subsets and all(subsets):
            from collections import Counter
            cnt = Counter(subsets)
            top = cnt.most_common(1)[0]
            repro = top[1] / len(subsets)
            distinct = len(cnt)
        else:
            repro, distinct = float('nan'), -1
        out['methods'].append({
            'method': method, 'n_seeds': len(recs),
            'jm_mean': float(jm.mean()) if jm.size else float('nan'),
            'jm_saturated_frac': saturated,
            'distinct_band_subsets': distinct,
            'reproducibility_rate': repro,
        })
        print('  %-10s JM=%.4f sat=%.2f repro=%.2f (%d/%d)'
              % (method, out['methods'][-1]['jm_mean'], saturated, repro,
                 (top[1] if 'top' in dir() else 0), len(subsets)), flush=True)
    _dump(os.path.dirname(selection_jsonl), 'jmrepro_summary.json', out)
    return out


# --------------------------------------------------------------------- helpers
def _dump(out_dir, name, obj):
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, name), 'w', encoding='utf-8') as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2, default=str)


DEFAULT_SPATIAL = [
    {'operator': 'morph', 'eta': [3, 5, 7], 'lam': 0.01, 'n_pc': 4},
    {'operator': 'epf', 'eta': [5], 'lam': 0.01, 'n_pc': 4},
    {'operator': 'gabor', 'eta': [5], 'lam': 6.0, 'n_pc': 1},
]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog='python batch7_8_run.py',
                                 description='Batch7/8 experiment driver.')
    ap.add_argument('cmd', choices=['ablation', 'crosstable', 'disjoint', 'sensitivity', 'jmrepro', 'all'])
    ap.add_argument('--dataset', default='configs/longkou.json')
    ap.add_argument('--runs', default='output/runs/longkou_5cls')
    ap.add_argument('--out', default=None)
    ap.add_argument('--seeds', default=None, help="'1-2' or '1,2,5' to limit seeds for a smoke test")
    ap.add_argument('--classifiers', default='knn5,svm_rbf,rf')
    ap.add_argument('--protocol', default='B', choices=['A', 'B'],
                    help="crosstable feature layout: A = [selected spectral] + "
                         "[spatial of selected] (dim k+F, compact); "
                         "B = [all spectral] + [spatial of selected] (dim B+F)")
    ap.add_argument('--spatial', default=None, help='path to a spatial-spec JSON list')
    a = ap.parse_args(argv)

    clfs = [c.strip() for c in a.classifiers.split(',') if c.strip()]
    spatial_specs = DEFAULT_SPATIAL
    if a.spatial and os.path.isfile(a.spatial):
        with open(a.spatial, 'r', encoding='utf-8') as fh:
            spatial_specs = json.load(fh)

    t0 = time.perf_counter()
    # dataset/training configs live under code/configs/; output runs live under
    # <project>/output/runs/. Resolve each against the correct root.
    cfg_path = os.path.join(HERE, a.dataset) if not os.path.isabs(a.dataset) else a.dataset
    runs_dir = os.path.join(ROOT, a.runs) if not os.path.isabs(a.runs) else a.runs
    seeds = a.seeds

    if a.cmd in ('ablation', 'all'):
        out = os.path.join(ROOT, a.out or 'output/runs/batch7_ablation')
        print('[ablation] %s -> %s' % (a.dataset, out), flush=True)
        run_ablation(cfg_path, spatial_specs, clfs, out, seeds=seeds)
    if a.cmd in ('crosstable', 'all'):
        out = os.path.join(ROOT, a.out or 'output/runs/batch7_crosstable')
        print('[crosstable] %s (from %s) -> %s' % (a.dataset, runs_dir, out), flush=True)
        run_crosstable(cfg_path, spatial_specs[0], clfs, runs_dir, out, seeds=seeds,
                       protocol=a.protocol)
    if a.cmd in ('disjoint', 'all'):
        out = os.path.join(ROOT, a.out or 'output/runs/batch8_disjoint')
        print('[disjoint] %s -> %s' % (a.dataset, out), flush=True)
        run_disjoint(cfg_path, spatial_specs[0], clfs, out, seeds=seeds)
    if a.cmd in ('sensitivity', 'all'):
        out = os.path.join(ROOT, a.out or 'output/runs/batch8_sensitivity')
        print('[sensitivity] %s -> %s' % (a.dataset, out), flush=True)
        run_sensitivity(cfg_path, clfs, out, seeds=seeds)
    if a.cmd in ('jmrepro', 'all'):
        out = os.path.join(ROOT, a.out or os.path.dirname(runs_dir))
        print('[jmrepro] %s' % runs_dir, flush=True)
        analyze_jm_repro(os.path.join(runs_dir, 'selection.jsonl'))
    print('[done] %.1f s' % (time.perf_counter() - t0), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
