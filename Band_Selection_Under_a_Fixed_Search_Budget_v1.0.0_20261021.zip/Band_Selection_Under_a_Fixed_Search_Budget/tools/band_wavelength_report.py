# -*- coding: utf-8 -*-
"""
t44_band_wavelength_report.py
-----------------------------
把各方法（默认 SAPSO）在各 k、各 seed 上选出的波段索引换算为中心波长，
供论文"可解释性 / 选中波段物理含义"部分直接引用。

输入: data/meta/longkou_wavelengths_270.json
      data/meta/indian_pines_wavelengths_200.json
      output/runs/longkou_5cls/selection.jsonl   (LongKou 5 类主实验)
      output/runs/indian_pines/selection.jsonl   (Indian Pines 主实验)
输出: data/meta/selected_bands_wavelengths.csv
      output/选中波段波长对照.md
"""
import collections
import csv
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
META = os.path.join(ROOT, "data", "meta")

lk = {i + 1: v for i, v in enumerate(
    json.load(open(os.path.join(META, "longkou_wavelengths_270.json"), encoding="utf-8"))["wavelengths_nm"])}
ip = {b["band_index_1based"]: b["wavelength_nm"]
      for b in json.load(open(os.path.join(META, "indian_pines_wavelengths_200.json"),
                          encoding="utf-8"))["bands"]}

SETS = [
    ("WHU-Hi-LongKou", "output/runs/longkou_5cls/selection.jsonl", lk, 270),
    ("Indian Pines", "output/runs/indian_pines/selection.jsonl", ip, 200),
]
METHOD = "SAPSO"

rows = []
report = []
for name, rel, wmap, nb in SETS:
    path = os.path.join(ROOT, rel)
    if not os.path.exists(path):
        print("MISSING", path)
        continue
    recs = [json.loads(l) for l in open(path, encoding="utf-8")]
    recs = [r for r in recs if r["method"] == METHOD]
    by_k = collections.defaultdict(list)
    for r in recs:
        by_k[r["k"]].append(r)
    report.append("\n## %s（%d 波段，%s 选出，10 seeds）\n\n" % (name, nb, METHOD))
    report.append("| k | 出现次数最高的波段（波段号→中心波长 nm，按 10 seeds 频次） |\n")
    report.append("|---|---|\n")
    for k in sorted(by_k):
        cnt = collections.Counter()
        for r in by_k[k]:
            for b in r["bands_1based"]:
                cnt[b] += 1
        top = sorted(cnt.items(), key=lambda x: (-x[1], x[0]))[:8]
        txt = "、".join("%d→%.2f nm(%d/10)" % (b, wmap[b], c) for b, c in top)
        report.append("| %d | %s |\n" % (k, txt))
        for r in by_k[k]:
            rows.append({
                "dataset": name, "method": METHOD, "k": k, "seed": r["seed"],
                "bands_1based": ";".join(str(b) for b in sorted(r["bands_1based"])),
                "wavelengths_nm": ";".join("%.2f" % wmap[b] for b in sorted(r["bands_1based"])),
                "objective": r.get("objective"),
            })

csv_path = os.path.join(META, "selected_bands_wavelengths.csv")
with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
    w = csv.DictWriter(f, fieldnames=["dataset", "method", "k", "seed", "bands_1based",
                                      "wavelengths_nm", "objective"])
    w.writeheader()
    w.writerows(rows)

md_path = os.path.join(ROOT, "output", "选中波段波长对照.md")
with open(md_path, "w", encoding="utf-8") as f:
    f.write("# 选中波段 → 中心波长对照\n")
    f.write("波长来源见 `data/meta/longkou_wavelengths_270.json` 与 "
            "`data/meta/indian_pines_wavelengths_200.json`（均为官方来源，见文件内 source 字段）。\n")
    f.write("\n逐 seed 明细见 `data/meta/selected_bands_wavelengths.csv`（%d 行）。\n" % len(rows))
    f.write("".join(report))
print("csv:", csv_path, len(rows), "rows")
print("md :", md_path)
