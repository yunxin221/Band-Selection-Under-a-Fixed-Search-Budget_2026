"""Band-selection optimisers behind one harness.

Every method is a solver for the same problem: pick exactly `k` bands out of
`n_bands` so that a scalar objective (see hsbs.criteria) is maximised, under a
shared budget of *distinct* fitness evaluations (NFE). Sharing the objective
callable and the NFE budget is what makes the comparison in R1-2 meaningful.

Two families of encodings are used, deliberately:

* continuous relaxation with top-k repair -- PSO, SAPSO, MPSO, GWO, DE. A real-valued
  vector u in [0, 1]^B is mapped to a subset by keeping the k largest entries.
  This respects the fixed-k constraint by construction and keeps the classic
  update equations intact.
* set-based moves -- GA (population of exact-k subsets) and SA (swap moves
  between a selected and an unselected band). Also exactly-k by construction.

All methods are deterministic given their seed.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence, Type

import numpy as np

__all__ = ['OptimResult', 'Optimizer', 'PSO', 'SAPSO', 'MPSO', 'GA', 'SA', 'GWO', 'DE',
           'make_optimizer', 'list_methods', 'REGISTRY']

# ---------------------------------------------------------------- result
@dataclass
class OptimResult:
    method: str
    bands: List[int]            # 0-based band indices, ascending
    score: float
    nfe: int
    runtime_s: float
    seed: int
    k: int
    history: List[float] = field(default_factory=list)   # best-so-far per iteration
    extra: Dict[str, object] = field(default_factory=dict)

    @property
    def bands_1based(self) -> List[int]:
        return [b + 1 for b in self.bands]

    def as_row(self) -> Dict[str, object]:
        return {'method': self.method, 'seed': self.seed, 'k': self.k,
                'bands_1based': ' '.join(str(b) for b in self.bands_1based),
                'objective': self.score, 'nfe': self.nfe,
                'runtime_s': self.runtime_s}


# ---------------------------------------------------------------- helpers
def _topk_indices(u: np.ndarray, k: int) -> List[int]:
    """Indices of the k largest entries of u, ascending."""
    if k >= u.size:
        return list(range(u.size))
    idx = np.argpartition(-u, k - 1)[:k]
    return sorted(int(i) for i in idx)


# ---------------------------------------------------------------- base
class Optimizer:
    """Base class: subclasses implement `_search()`."""

    name = 'base'
    family = 'metaheuristic'

    def __init__(self, fitness, n_bands: int, k: Optional[int] = None,
                 nfe_budget: int = 3000, seed: int = 1, pop_size: int = 30,
                 max_iter: Optional[int] = None, **params) -> None:
        self.f = fitness
        self.n_bands = int(n_bands)
        # clamp: an exact-k larger than the band count is meaningless and would
        # make _topk_indices() return a short subset.
        self.k = min(int(k), self.n_bands) if k else None
        self.nfe_budget = int(nfe_budget)
        self.seed = int(seed)
        self.pop_size = max(int(pop_size), 4)
        self.params = dict(params)
        self.rng = np.random.default_rng(self.seed)
        self._start_nfe = getattr(fitness, 'nfe', 0)
        if max_iter is None:
            max_iter = max(1, self.nfe_budget // max(self.pop_size, 1))
        self.max_iter = int(max_iter)
        self._history: List[float] = []
        self._best_bits: Optional[List[int]] = None
        self._best_score = float('-inf')

    # ------------------------------------------------------------ plumbing
    @property
    def used_nfe(self) -> int:
        return getattr(self.f, 'nfe', 0) - self._start_nfe

    def remaining(self) -> int:
        return self.nfe_budget - self.used_nfe

    def exhausted(self) -> bool:
        return self.remaining() <= 0

    def evaluate(self, u: np.ndarray) -> float:
        return float(self.f(_topk_indices(u, self.k) if self.k else np.flatnonzero(u > 0.5).tolist()))

    def evaluate_set(self, bands: Sequence[int]) -> float:
        return float(self.f(list(bands)))

    def consider(self, bands: Sequence[int], score: float) -> bool:
        if score > self._best_score + 1e-12:
            self._best_score = score
            self._best_bits = sorted(int(b) for b in bands)
            return True
        return False

    def record(self) -> None:
        self._history.append(self._best_score)

    def _seed_population(self, n: int) -> np.ndarray:
        return self.rng.random((n, self.n_bands))

    def _finalise(self, t0: float, extra: Optional[Dict[str, object]] = None) -> OptimResult:
        if self._best_bits is None:                                  # pragma: no cover
            self._best_bits = _topk_indices(self.rng.random(self.n_bands), self.k or 1)
            self._best_score = self.evaluate_set(self._best_bits)
        return OptimResult(method=self.name, bands=self._best_bits, score=float(self._best_score),
                           nfe=self.used_nfe, runtime_s=time.perf_counter() - t0,
                           seed=self.seed, k=len(self._best_bits),
                           history=list(self._history), extra=dict(extra or {}))

    # ------------------------------------------------------------ entry
    def run(self) -> OptimResult:
        t0 = time.perf_counter()
        self._search()
        return self._finalise(t0, self.describe_params())

    def describe_params(self) -> Dict[str, object]:
        return dict(self.params)

    def _search(self) -> None:                                       # pragma: no cover
        raise NotImplementedError


# ---------------------------------------------------------------- PSO / SAPSO
class PSO(Optimizer):
    """Continuous PSO on [0, 1]^B with top-k repair; `anneal=True` turns it into SAPSO."""

    name = 'PSO'
    family = 'swarm'

    def __init__(self, *args, w0: float = 0.9, w1: float = 0.4, c1: float = 1.6, c2: float = 1.6,
                 anneal: bool = False, t0: float = 0.35, t1: float = 0.02, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.w0, self.w1, self.c1, self.c2 = float(w0), float(w1), float(c1), float(c2)
        self.anneal = bool(anneal)
        self.t0, self.t1 = float(t0), float(t1)

    def describe_params(self) -> Dict[str, object]:
        d = {'w': '%.2f->%.2f' % (self.w0, self.w1), 'c1': self.c1, 'c2': self.c2,
             'pop': self.pop_size, 'iter': self.max_iter, 'nfe_budget': self.nfe_budget}
        if self.anneal:
            d['SA'] = 'Metropolis on gbest, T %.3f->%.3f' % (self.t0, self.t1)
        return d

    def _search(self) -> None:
        n, B = self.pop_size, self.n_bands
        X = self._seed_population(n)
        V = (self.rng.random((n, B)) - 0.5) * 0.2
        size = self.k or max(1, B // 10)

        self._size = size
        bits = [_topk_indices(X[i], size) for i in range(n)]
        scores = np.array([self.evaluate_set(b) for b in bits], dtype=np.float64)
        pbest_X = X.copy()
        pbest_s = scores.copy()
        gi = int(np.argmax(scores))
        gbest_X = X[gi].copy()
        gbest_bits = list(bits[gi])
        self.consider(gbest_bits, float(scores[gi]))

        accepted, rejected = 0, 0
        for it in range(self.max_iter):
            if self.exhausted():
                break
            frac = it / max(self.max_iter - 1, 1)
            w = self.w0 + (self.w1 - self.w0) * frac
            T = self.t0 + (self.t1 - self.t0) * frac
            X_prev = X.copy()                       # "current solution" before the update
            scores_prev = scores.copy()
            r1 = self.rng.random((n, B))
            r2 = self.rng.random((n, B))
            V = w * V + self.c1 * r1 * (pbest_X - X) + self.c2 * r2 * (gbest_X[None, :] - X)
            V = V + self._extra_velocity(X, pbest_X, gbest_X, it)
            np.clip(V, -0.5, 0.5, out=V)
            X = np.clip(X + V, 0.0, 1.0)            # "new solution"

            evaluated = np.zeros(n, dtype=bool)
            for i in range(n):
                if self.exhausted():
                    break
                b = _topk_indices(X[i], size)
                s = self.evaluate_set(b)
                scores[i] = s                       # keep the swarm's own scores in sync
                evaluated[i] = True
                if s > pbest_s[i]:
                    pbest_s[i] = s
                    pbest_X[i] = X[i].copy()
                if s > self._best_score:
                    if self.anneal:
                        d = s - float(np.max(pbest_s))
                        if d > 0 or self.rng.random() < math.exp(d / max(T, 1e-9)):
                            gbest_X = X[i].copy()
                            gbest_bits = b
                            accepted += 1
                        else:
                            rejected += 1
                    else:
                        gbest_X = X[i].copy()
                        gbest_bits = b
                    self.consider(b, s)

            out = self._post_iteration(X, V, scores, X_prev, scores_prev, evaluated)
            if out is not None:
                X, V, scores = out
            self.record()

        self._sa_stats = {'accepted': accepted, 'rejected': rejected}
        self._best_bits = self._best_bits or gbest_bits

    def _extra_velocity(self, X, pbest_X, gbest_X, it: int):
        """Extra additive velocity term, evaluated before clipping.

        Standard PSO has none (returns 0). `IEPSO` overrides it with the
        local-global information sharing term of its Eq. (2).
        """
        return 0.0

    def _post_iteration(self, X, V, scores, X_prev, scores_prev, evaluated=None):
        """Hook at the end of each generation.

        Base PSO does nothing. `MPSO` overrides it to apply the elimination
        mechanism; `IEPSO` overrides it with the last-eliminated principle.
        ``evaluated`` marks the particles whose score was actually
        recomputed this generation (the NFE budget may run out mid-sweep; those
        particles must not be compared). Returning ``(X, V, scores)`` replaces
        the swarm state; returning ``None`` keeps it unchanged.
        """
        return None

    def run(self) -> OptimResult:
        t0 = time.perf_counter()
        self._search()
        extra = self.describe_params()
        if self.anneal:
            acc, rej = getattr(self, '_sa_stats', (0, 0))
            extra['sa_accepted'] = acc
            extra['sa_rejected'] = rej
        return self._finalise(t0, extra)


class SAPSO(PSO):
    """Simulated-annealing particle swarm -- the method under review."""

    name = 'SAPSO'

    def __init__(self, *args, **kwargs) -> None:
        kwargs['anneal'] = True
        super().__init__(*args, **kwargs)


# ---------------------------------------------------------------- MPSO
class MPSO(SAPSO):
    """SAPSO + elimination mechanism -- Zhang & Liu (2021), MPSO.

    "改进粒子群优化算法的高光谱波段选择", 光谱学与光谱分析 2021, 41(10): 3194-3199.
    DOI 10.3964/j.issn.1000-0593(2021)10-3194-06

    The paper's own wording (translation):

        "In the later stage of the iteration the range of new solutions is
        still concentrated in the adjacent region, which reduces the
        utilisation of new solutions. ... The degree of convergence between
        the new solution and the current solution in the population is taken
        as the criterion, with an empirical value of 100 x 10^-9. When the
        overall convergence degree of the new solution and the current
        solution is smaller than the preset value, the new solution is
        eliminated and new particles are added to the population."

    Two reading choices are exposed as parameters because the wording is
    ambiguous and the published paper does not give pseudocode:

    * ``elim_metric='fitness'`` (default) reads "numerical difference between
      the new solution and the current solution" as ``|f(x_new) - f(x_old)|``,
      consistent with Eq. (5) of that paper, which is written in terms of
      ``FXd`` and ``FXgd``.
      ``elim_metric='position'`` reads it as the per-particle position shift.
    * ``elim_scope='population'`` (default) follows "the *overall* convergence
      degree", i.e. one aggregate test per generation that re-seeds the whole
      swarm; ``elim_scope='particle'`` re-seeds only the stagnant particles.

    Either way the personal-best memory and the global best are preserved --
    only the current positions/velocities are replaced, which is what
    "adding new particles to the population" means operationally.
    """

    name = 'MPSO'

    def __init__(self, *args,
                 elim_threshold: float = 100e-9,
                 elim_metric: str = 'fitness',
                 elim_scope: str = 'population',
                 elim_agg: str = 'mean', **kwargs) -> None:
        kwargs['anneal'] = True
        super().__init__(*args, **kwargs)
        self.elim_threshold = float(elim_threshold)
        self.elim_metric = str(elim_metric).lower()
        self.elim_scope = str(elim_scope).lower()
        self.elim_agg = str(elim_agg).lower()
        if self.elim_metric not in ('fitness', 'position'):
            raise ValueError("elim_metric must be 'fitness' or 'position'")
        if self.elim_scope not in ('population', 'particle'):
            raise ValueError("elim_scope must be 'population' or 'particle'")
        if self.elim_agg not in ('mean', 'max'):
            raise ValueError("elim_agg must be 'mean' or 'max'")
        self._eliminations = 0      # particles replaced
        self._elim_events = 0       # generations in which elimination fired
        self._last_gap = float('nan')

    def describe_params(self) -> Dict[str, object]:
        d = super().describe_params()
        d['elim_threshold'] = self.elim_threshold
        d['elim_metric'] = self.elim_metric
        d['elim_scope'] = self.elim_scope
        d['elim_agg'] = self.elim_agg
        return d

    def _post_iteration(self, X, V, scores, X_prev, scores_prev, evaluated=None):
        if self.exhausted():
            return None
        d_all = np.abs(np.asarray(scores, dtype=np.float64)
                       - np.asarray(scores_prev, dtype=np.float64)) \
            if self.elim_metric == 'fitness' else None
        if d_all is None:
            d = np.abs(np.asarray(X, dtype=np.float64) - np.asarray(X_prev, dtype=np.float64))
            if d.ndim > 1:
                d = d.mean(axis=1)
        else:
            d = d_all
        d = np.asarray(d, dtype=np.float64)
        if evaluated is not None and d.shape == np.shape(evaluated):
            # particles whose new score was never computed carry a stale score;
            # comparing them would be meaningless.
            d = np.where(np.asarray(evaluated, dtype=bool), d, np.inf)
        if d.size == 0 or not np.any(np.isfinite(d)):
            return None
        fin = np.isfinite(d)
        if not fin.any():
            return None
        gap = float(d[fin].mean()) if self.elim_agg == 'mean' else float(d[fin].max())
        self._last_gap = gap
        if not (gap < self.elim_threshold):
            return None

        if self.elim_scope == 'particle':
            idx = np.flatnonzero(fin & (d < self.elim_threshold))
        else:
            idx = np.flatnonzero(fin)
        if idx.size == 0:
            return None

        size = getattr(self, '_size', None) or self.k or max(1, self.n_bands // 10)
        X = np.array(X, dtype=np.float64, copy=True)
        V = np.array(V, dtype=np.float64, copy=True)
        scores = np.array(scores, dtype=np.float64, copy=True)
        X[idx] = self.rng.random((idx.size, self.n_bands))
        V[idx] = (self.rng.random((idx.size, self.n_bands)) - 0.5) * 0.2
        for j, i in enumerate(idx):
            if self.exhausted():
                break
            b = _topk_indices(X[i], size)
            scores[i] = self.evaluate_set(b)
            self.consider(b, float(scores[i]))
        self._eliminations += int(idx.size)
        self._elim_events += 1
        return X, V, scores

    def run(self) -> OptimResult:
        res = super().run()
        res.extra['eliminations'] = self._eliminations
        res.extra['elim_events'] = self._elim_events
        res.extra['last_gap'] = self._last_gap
        return res


# ---------------------------------------------------------------- IEPSO
_TAN_0875 = math.tan(0.875)


class IEPSO(PSO):
    """Improved eliminate PSO -- Lv et al. (2018), the IEPSO baseline.

    Xueying Lv, Yitian Wang, Junyi Deng, Guanyu Zhang, Liu Zhang.
    "Improved Particle Swarm Optimization Algorithm Based on Last-Eliminated
    Principle and Enhanced Information Sharing".
    Computational Intelligence and Neuroscience, 2018, Article ID 5025672.
    DOI 10.1155/2018/5025672  (open access, PMCID PMC6305047, CC BY 4.0)

    This is the "IEPSO" entry of the comparison set used by Zhang & Liu (2021),
    i.e. Lv et al. is reference [14] of that paper. Reproduced here from the
    published formulas.

    Velocity update (Eq. 2, four terms):

        v_i(t+1) = w * v_i(t)
                 + C1 * R1 * (p_i(t) - x_i(t))      self-cognition
                 + C2 * R2 * (p_g(t) - x_i(t))      local information sharing
                 + C3 * R3 * (p_g(t) - p_i(t))      <-- new, Eq. 3, phi_3

    where p_i is the particle's personal-best position and p_g the global best
    position. The fourth term exchanges information between the *local* optimum
    and the *global* optimum, which is what the paper means by "enhanced
    information sharing".

    Parameter settings follow Table 6 of the paper: population 40, w = 0.9 -> 0.4
    linearly, C1 = C2 = 2, C3 = 2 -> 0. R1, R2, R3 are uniform (0, 1) as stated
    in Section 2.1; Table 6 fixes them at 0.5, which ``r_fixed=0.5`` reproduces.

    C3 schedule (``c3_mode``):
      * ``'linear'`` (default) -- Eq. (4) with k = 1, C3 = C3_start - (C3_start -
        C3_end) * t / tmax. This is the setting the paper actually adopts in
        Table 6 ("C3 = 2~0"); k = -1 would be the linearly *increasing* form.
      * ``'nonlinear'`` -- Eq. (5), C3 = C3_end + (C3_start - C3_end) *
        tan(0.875 * u^k) / tan(0.875) with u = 1 - t/tmax. ``c3_k=0.2`` is the
        convex form the paper reports as the best, ``c3_k=2`` the concave one.
        NOTE: Eq. (5) as printed omits the normalisation by tan(0.875), which
        makes C3(0) = 2 * tan(0.875) = 2.415 instead of the C3_start = 2 that
        the same sentence declares. We divide by tan(0.875) so that the curve
        actually starts at C3_start and ends at C3_end as described.
      * ``'constant'`` -- C3 = C3_start, the setting the paper says causes
        premature convergence (kept for completeness).

    Last-eliminated principle (Section 2.2 + Figure 1):

        "When the PSO satisfies the local convergence condition, the optimal
        value obtained at this time may be the local optimal value. Particle
        population diversity is maintained by using the particle fitness
        function as the evaluation criterion, thereby eliminating particles with
        poor fitness or high similarity. New particles are added ... within the
        predetermined range, and the particle swarm operations are reexecuted."

    Two implementation choices are exposed because the paper gives a flowchart
    but no pseudocode and no replacement ratio:
      * ``elim_criterion='fitness'`` (default) removes the worst-ranked
        particles ("the lattermost" in the flowchart); ``'similarity'`` removes
        the most crowded ones (smallest mean distance to the rest of the swarm),
        i.e. the "high similarity" branch.
      * ``elim_frac`` is the fraction of the swarm replaced per event.
      * ``greedy_accept=True`` reproduces the flowchart's "give up new
        particles" branch -- a re-seeded particle is kept only if it improves on
        its own previous score; by default it is kept unconditionally.

    The paper also eliminates particles that leave the search range, but our
    encoding clips positions to [0, 1]^B after every update, so that branch can
    never fire here; only the local-convergence branch is active.
    """

    name = 'IEPSO'
    family = 'swarm'

    def __init__(self, *args,
                 c1: float = 2.0, c2: float = 2.0,
                 c3_start: float = 2.0, c3_end: float = 0.0,
                 c3_mode: str = 'linear', c3_k: float = 0.2,
                 r_fixed: Optional[float] = None,
                 elim_frac: float = 0.2, elim_stall: int = 5,
                 elim_criterion: str = 'fitness',
                 greedy_accept: bool = False, **kwargs) -> None:
        kwargs['anneal'] = False
        super().__init__(*args, c1=c1, c2=c2, **kwargs)
        self.c3_start = float(c3_start)
        self.c3_end = float(c3_end)
        self.c3_mode = str(c3_mode).lower()
        self.c3_k = float(c3_k)
        if self.c3_mode not in ('linear', 'nonlinear', 'constant'):
            raise ValueError("c3_mode must be 'linear', 'nonlinear' or 'constant'")
        self.r_fixed = None if r_fixed is None else float(r_fixed)
        self.elim_frac = float(elim_frac)
        self.elim_stall = int(elim_stall)
        self.elim_criterion = str(elim_criterion).lower()
        if self.elim_criterion not in ('fitness', 'similarity'):
            raise ValueError("elim_criterion must be 'fitness' or 'similarity'")
        self.greedy_accept = bool(greedy_accept)
        self._stall = 0
        self._stag_best = float('-inf')
        self._eliminations = 0
        self._elim_events = 0
        self._last_c3 = float('nan')

    def describe_params(self) -> Dict[str, object]:
        d = super().describe_params()
        d['C3'] = '%g->%g (%s)' % (self.c3_start, self.c3_end, self.c3_mode)
        if self.c3_mode == 'nonlinear':
            d['C3_k'] = self.c3_k
        if self.r_fixed is not None:
            d['R_fixed'] = self.r_fixed
        d['elim_frac'] = self.elim_frac
        d['elim_stall'] = self.elim_stall
        d['elim_criterion'] = self.elim_criterion
        d['greedy_accept'] = self.greedy_accept
        return d

    # ------------------------------------------------------------ C3 schedule
    def c3_at(self, it: int) -> float:
        tfrac = it / max(self.max_iter - 1, 1)
        if self.c3_mode == 'constant':
            return self.c3_start
        if self.c3_mode == 'linear':
            # Eq. (4) with k = +1: linearly decreasing C3_start -> C3_end
            return self.c3_start - (self.c3_start - self.c3_end) * tfrac
        # Eq. (5), normalised so that C3(0) = C3_start and C3(tmax) = C3_end
        u = 1.0 - tfrac
        return self.c3_end + (self.c3_start - self.c3_end) * \
            math.tan(0.875 * (u ** self.c3_k)) / _TAN_0875

    def _r3(self, shape) -> np.ndarray:
        if self.r_fixed is not None:
            return np.full(shape, self.r_fixed, dtype=np.float64)
        return self.rng.random(shape)

    def _extra_velocity(self, X, pbest_X, gbest_X, it: int):
        c3 = self.c3_at(it)
        self._last_c3 = c3
        if c3 == 0.0:
            return 0.0
        # phi_3 = C3 * R3 * (p_g - p_i): local-optimum <-> global-optimum exchange
        return c3 * self._r3(np.shape(X)) * (np.asarray(gbest_X)[None, :] - np.asarray(pbest_X))

    # ------------------------------------------------------------ elimination
    def _post_iteration(self, X, V, scores, X_prev, scores_prev, evaluated=None):
        best = float(self._best_score)
        if best > self._stag_best + 1e-12:
            self._stag_best = best
            self._stall = 0
        else:
            self._stall += 1
        if self._stall < self.elim_stall or self.exhausted():
            return None
        self._stall = 0

        X = np.array(X, dtype=np.float64, copy=True)
        V = np.array(V, dtype=np.float64, copy=True)
        scores = np.array(scores, dtype=np.float64, copy=True)
        n = X.shape[0]
        ev = np.asarray(evaluated, dtype=bool) if evaluated is not None else np.ones(n, dtype=bool)
        cand = np.flatnonzero(ev)
        if cand.size == 0:
            return None

        m = int(round(self.elim_frac * n))
        m = max(1, min(m, int(cand.size)))

        if self.elim_criterion == 'similarity':
            # "high similarity": drop the most crowded particles, i.e. the ones
            # with the smallest mean distance to the rest of the swarm.
            D = np.sqrt(((X[cand][:, None, :] - X[cand][None, :, :]) ** 2).sum(axis=-1))
            rank = D.mean(axis=1)
            idx = cand[np.argsort(rank)[:m]]
        else:
            # "the lattermost": worst-ranked by fitness
            s = scores[cand]
            idx = cand[np.argsort(s)[:m]]

        size = getattr(self, '_size', None) or self.k or max(1, self.n_bands // 10)
        new_X = self.rng.random((idx.size, self.n_bands))
        new_V = (self.rng.random((idx.size, self.n_bands)) - 0.5) * 0.2
        for j, i in enumerate(idx):
            if self.exhausted():
                break
            old_X = X[i].copy()
            old_s = float(scores[i])
            X[i] = new_X[j]
            V[i] = new_V[j]
            b = _topk_indices(X[i], size)
            s_new = self.evaluate_set(b)
            self.consider(b, float(s_new))
            if self.greedy_accept and not (s_new > old_s):
                # flowchart branch "give up new particles"
                X[i] = old_X
                scores[i] = old_s
            else:
                scores[i] = s_new
                self._eliminations += 1
        self._elim_events += 1
        return X, V, scores

    def run(self) -> OptimResult:
        res = super().run()
        res.extra['eliminations'] = self._eliminations
        res.extra['elim_events'] = self._elim_events
        res.extra['last_c3'] = self._last_c3
        return res


# ---------------------------------------------------------------- DESAPSO
class DESAPSO(Optimizer):
    """DE + SAPSO hybrid -- Du & Zhou (2015), the DESAPSO baseline.

    杜松, 周健勇. 一种差分进化和模拟退火粒子群混合算法.
    计算机仿真, 2015, 32(12): 218-221.

    This is the algorithm cited as [25] in the manuscript and as [12] in
    Zhang & Liu (2021). The implementation follows the published steps in
    Section 3.2 and the parameter values given before Table 1 of the paper.

    Per-generation structure (population size N):

        1. DE operation on the current positions (DE/rand/1/bin):
               U_i = X_{r1} + F * (X_{r2} - X_{r3})
               trial_{i,j} = U_{i,j}      if rand_j <= CR or j == j_rand
                             X_{i,j}      otherwise
               X_i = trial_i  if f(trial_i) >= f(X_i) else X_i   (maximisation)
        2. Update pbest/gbest using the DE-refined positions.
        3. PSO velocity/position update (Eqs. 4-5 of the paper) with constant
           inertia weight w, acceleration factors c1 and c2:
               V_i = w V_i + c1 rand1 (pbest_i - X_i) + c2 rand2 (gbest - X_i)
               X_i_new = clip(X_i + V_i)
        4. Evaluate the new positions.
        5. Simulated-annealing acceptance on each particle:
               accept if f(X_i_new) > f(X_i)
               else accept with probability exp((f_new - f_old) / T)
        6. Update pbest/gbest using the accepted positions.
        7. Cool temperature T = T * lambda_sa.

    Published parameter values (from the Chinese paper):
        population N = 100      (here we inherit the global pop_size for a
                                 fair NFE budget; report this in the paper)
        c1 = 2.0, c2 = 2.1, w = 0.6 (constant)
        DE scale factor F = 0.4, crossover rate CR = 0.8
        SA initial temperature T0 = 1000, cooling factor lambda_sa = 0.5
        maximum iterations t_max = 800

    Because each generation consumes about 2N evaluations (N for DE trials + N
    for the PSO candidate positions), the NFE budget limits the actual number of
    generations under our protocol.
    """

    name = 'DESAPSO'
    family = 'hybrid'

    def __init__(self, *args,
                 w: float = 0.6, c1: float = 2.0, c2: float = 2.1,
                 F: float = 0.4, CR: float = 0.8,
                 T0: float = 1000.0, lambda_sa: float = 0.5,
                 **kwargs) -> None:
        # Each generation evaluates ~2*pop_size candidates, so cap max_iter
        # accordingly. The base default would be nfe//pop_size.
        if kwargs.get('max_iter') is None and 'nfe_budget' in kwargs and 'pop_size' in kwargs:
            nfe = int(kwargs['nfe_budget'])
            pop = max(int(kwargs['pop_size']), 1)
            kwargs['max_iter'] = max(1, nfe // (2 * pop))
        super().__init__(*args, **kwargs)
        self.w = float(w)
        self.c1 = float(c1)
        self.c2 = float(c2)
        self.F = float(F)
        self.CR = float(CR)
        self.T0 = float(T0)
        self.lambda_sa = float(lambda_sa)
        self.T = float(T0)
        self._sa_accepted = 0
        self._sa_rejected = 0

    def describe_params(self) -> Dict[str, object]:
        return {'w': self.w, 'c1': self.c1, 'c2': self.c2,
                'F': self.F, 'CR': self.CR,
                'T0': self.T0, 'lambda': self.lambda_sa,
                'pop': self.pop_size, 'iter': self.max_iter,
                'nfe_budget': self.nfe_budget}

    def _search(self) -> None:
        n, B = self.pop_size, self.n_bands
        size = self.k or max(1, B // 10)
        self._size = size

        # ---- initialise
        X = self._seed_population(n)
        V = (self.rng.random((n, B)) - 0.5) * 0.2
        bits = [_topk_indices(X[i], size) for i in range(n)]
        scores = np.array([self.evaluate_set(b) for b in bits], dtype=np.float64)
        pbest_X = X.copy()
        pbest_s = scores.copy()
        gi = int(np.argmax(scores))
        gbest_X = X[gi].copy()
        gbest_bits = list(bits[gi])
        self.consider(gbest_bits, float(scores[gi]))

        def update_best(X_arr, s_arr):
            nonlocal gbest_X, gbest_bits
            for i in range(n):
                if s_arr[i] > pbest_s[i]:
                    pbest_s[i] = s_arr[i]
                    pbest_X[i] = X_arr[i].copy()
                if s_arr[i] > self._best_score:
                    b = _topk_indices(X_arr[i], size)
                    gbest_X = X_arr[i].copy()
                    gbest_bits = b
                    self.consider(b, float(s_arr[i]))

        self.T = self.T0
        for it in range(self.max_iter):
            if self.exhausted():
                break

            # ---- Step 1: DE/rand/1/bin on the current swarm
            X_snap = X.copy()
            trial_scores = scores.copy()
            for i in range(n):
                if self.exhausted():
                    break
                # distinct random donors, different from i
                idx = np.arange(n)
                idx = idx[idx != i]
                r1, r2, r3 = self.rng.choice(idx, size=3, replace=False)
                mutant = X_snap[r1] + self.F * (X_snap[r2] - X_snap[r3])
                cross = self.rng.random(B) <= self.CR
                j_rand = self.rng.integers(B)
                cross[j_rand] = True
                trial = np.where(cross, mutant, X_snap[i])
                trial = np.clip(trial, 0.0, 1.0)
                b = _topk_indices(trial, size)
                s = self.evaluate_set(b)
                # greedy selection for maximisation (Eq. 3 reversed)
                if s >= scores[i]:
                    X[i] = trial
                    trial_scores[i] = s
                # else keep current X[i] and scores[i]
            scores = trial_scores

            # ---- Step 2: update pbest/gbest after DE
            update_best(X, scores)

            # ---- Step 3: PSO velocity/position update
            r1 = self.rng.random((n, B))
            r2 = self.rng.random((n, B))
            V = self.w * V + self.c1 * r1 * (pbest_X - X) + self.c2 * r2 * (gbest_X[None, :] - X)
            np.clip(V, -0.5, 0.5, out=V)
            X_new = np.clip(X + V, 0.0, 1.0)

            # ---- Step 4-5: evaluate new positions and SA-accept each particle
            X_old = X.copy()
            s_old = scores.copy()
            for i in range(n):
                if self.exhausted():
                    break
                b = _topk_indices(X_new[i], size)
                s_new = self.evaluate_set(b)
                delta = s_new - s_old[i]
                accept = (delta > 0) or (self.rng.random() < math.exp(delta / max(self.T, 1e-12)))
                if accept:
                    X[i] = X_new[i]
                    scores[i] = s_new
                    self._sa_accepted += 1
                else:
                    self._sa_rejected += 1
                    # keep X[i] and scores[i] as they were

            # ---- Step 6: update pbest/gbest after the SA acceptance
            update_best(X, scores)

            # ---- Step 7: record progress and cool temperature
            self.record()
            self.T *= self.lambda_sa

        self._best_bits = self._best_bits or gbest_bits

    def run(self) -> OptimResult:
        res = super().run()
        res.extra['sa_accepted'] = self._sa_accepted
        res.extra['sa_rejected'] = self._sa_rejected
        res.extra['final_T'] = self.T
        return res


# ---------------------------------------------------------------- GA
class GA(Optimizer):
    """Binary genetic algorithm over exact-k subsets (allele-frequency repair)."""

    name = 'GA'
    family = 'evolutionary'

    def __init__(self, *args, crossover: float = 0.9, mutation: float = 0.08,
                 tournament: int = 3, elitism: int = 2, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.pc, self.pm, self.tsize, self.n_elite = float(crossover), float(mutation), int(tournament), int(elitism)

    def describe_params(self) -> Dict[str, object]:
        return {'pop': self.pop_size, 'iter': self.max_iter, 'pc': self.pc, 'pm': self.pm,
                'tournament': self.tsize, 'elitism': self.n_elite, 'nfe_budget': self.nfe_budget}

    def _repair_by_frequency(self, bits: np.ndarray, freq: np.ndarray, size: int) -> np.ndarray:
        c = int(bits.sum())
        if c == size:
            return bits
        if c > size:
            ones = np.flatnonzero(bits == 1)
            order = ones[np.argsort(-freq[ones])]
            bits = bits.copy()
            bits[order[size:]] = 0
            return bits
        zeros = np.flatnonzero(bits == 0)
        order = zeros[np.argsort(-freq[zeros])]
        bits = bits.copy()
        bits[order[:size - c]] = 1
        return bits

    def _search(self) -> None:
        n, B = self.pop_size, self.n_bands
        size = self.k or max(1, B // 10)

        P = np.zeros((n, B), dtype=np.int8)
        for i in range(n):
            P[i, self.rng.choice(B, size=size, replace=False)] = 1
        S = np.array([self.evaluate_set(np.flatnonzero(P[i]).tolist()) for i in range(n)], dtype=np.float64)
        for i in range(n):
            self.consider(np.flatnonzero(P[i]).tolist(), float(S[i]))

        for it in range(self.max_iter):
            if self.exhausted():
                break
            freq = P.mean(axis=0)
            # ---- selection
            newP = np.empty_like(P)
            elite = np.argsort(-S)[:self.n_elite]
            newP[:self.n_elite] = P[elite]
            for j in range(self.n_elite, n):
                a = self.rng.integers(0, n, size=self.tsize)
                b = self.rng.integers(0, n, size=self.tsize)
                pa = P[a[np.argmax(S[a])]]
                pb = P[b[np.argmax(S[b])]]
                if self.rng.random() < self.pc:
                    mask = self.rng.random(B) < 0.5
                    if mask.all() or not mask.any():
                        mask = self.rng.random(B) < 0.5
                    child = np.where(mask, pa, pb)
                else:
                    child = pa.copy()
                mut = self.rng.random(B) < self.pm
                child = np.where(mut, 1 - child, child)
                newP[j] = self._repair_by_frequency(child, freq, size)
            P = newP
            S = np.array([self.evaluate_set(np.flatnonzero(P[i]).tolist()) for i in range(n)], dtype=np.float64)
            for i in range(n):
                self.consider(np.flatnonzero(P[i]).tolist(), float(S[i]))
            self.record()
        self._population_diversity = float(P.mean(axis=0).std())
        self._pd = self._population_diversity

    def run(self) -> OptimResult:
        t0 = time.perf_counter()
        self._search()
        extra = self.describe_params()
        extra['allele_freq_std'] = round(getattr(self, '_pd', 0.0), 4)
        return self._finalise(t0, extra)


# ---------------------------------------------------------------- SA
class SA(Optimizer):
    """Simulated annealing with swap moves over exact-k subsets."""

    name = 'SA'
    family = 'trajectory'

    def __init__(self, *args, t0: Optional[float] = None, t1: float = 1e-3,
                 alpha: Optional[float] = None, moves_per_temp: int = 1, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.t0 = t0
        self.t1 = float(t1)
        self.alpha = alpha
        self.moves_per_temp = int(moves_per_temp)

    def describe_params(self) -> Dict[str, object]:
        return {'T0': self.t0 if self.t0 else 'auto', 'T1': self.t1,
                'cooling': '%.4f' % self.alpha if self.alpha else 'auto (geometric)',
                'moves/temp': self.moves_per_temp, 'nfe_budget': self.nfe_budget}

    def _search(self) -> None:
        B = self.n_bands
        size = self.k or max(1, B // 10)
        size = min(size, B)

        # Degenerate case: a full-band "subset" admits no swap move at all.
        # Without this guard the loop below spins forever, because no candidate
        # is ever evaluated and therefore the NFE budget never decreases.
        if size >= B:
            cur = list(range(B))
            cur_s = self.evaluate_set(cur)
            self.consider(cur, cur_s)
            self.record()
            self._acc = (0, 0)
            self._degenerate = 'k == n_bands: no swap moves available'
            return

        cur = sorted(int(i) for i in self.rng.choice(B, size=size, replace=False))
        cur_s = self.evaluate_set(cur)
        self.consider(cur, cur_s)
        self._history.append(self._best_score)

        steps = max(1, self.nfe_budget)
        if self.alpha:
            t0 = self.t0 if self.t0 else 1.0
            T = float(t0)
        else:
            T = max(abs(cur_s) * 0.05, 1e-3)
        alpha = self.alpha if self.alpha else (self.t1 / max(T, 1e-12)) ** (1.0 / max(steps, 1))

        accepted = rejected = 0
        no_move = False
        guard = 0
        max_steps = max(1, 4 * self.nfe_budget)      # hard cap: never loop unbounded
        while not self.exhausted() and guard < max_steps:
            guard += 1
            nfe_before = self.used_nfe
            sel = np.zeros(B, dtype=bool)
            sel[cur] = True
            for _ in range(self.moves_per_temp):
                if self.exhausted():
                    break
                off = np.flatnonzero(~sel)
                on = np.flatnonzero(sel)
                if off.size == 0 or on.size == 0:
                    no_move = True
                    break
                out_b = int(on[self.rng.integers(on.size)])
                in_b = int(off[self.rng.integers(off.size)])
                cand = sorted([b for b in cur if b != out_b] + [in_b])
                cand_s = self.evaluate_set(cand)
                d = cand_s - cur_s
                if d >= 0 or self.rng.random() < math.exp(d / max(T, 1e-12)):
                    cur, cur_s = cand, cand_s
                    accepted += 1
                    self.consider(cand, cand_s)
                else:
                    rejected += 1
            if no_move:
                break
            T = max(T * alpha, 1e-12)
            self.record()
            if self.used_nfe == nfe_before:
                # every candidate this step was already cached -> no new ground
                # can be covered, so continuing would just repeat ourselves.
                self._stalled = 'no new candidate evaluated in a full temperature step'
                break
        self._acc = (accepted, rejected)

    def run(self) -> OptimResult:
        t0 = time.perf_counter()
        self._search()
        extra = self.describe_params()
        acc, rej = getattr(self, '_acc', (0, 0))
        extra['accepted'] = acc
        extra['rejected'] = rej
        if getattr(self, '_degenerate', None):
            extra['degenerate'] = self._degenerate
        if getattr(self, '_stalled', None):
            extra['early_stop'] = self._stalled
        if not self.alpha:
            extra['T0_used'] = 'auto (5% of initial objective)'
        return self._finalise(t0, extra)


# ---------------------------------------------------------------- GWO
class GWO(Optimizer):
    """Grey wolf optimiser on the same continuous relaxation."""

    name = 'GWO'
    family = 'swarm'

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)

    def describe_params(self) -> Dict[str, object]:
        return {'pop': self.pop_size, 'iter': self.max_iter, 'a': '2 -> 0 (linear)',
                'nfe_budget': self.nfe_budget}

    def _search(self) -> None:
        n, B = self.pop_size, self.n_bands
        size = self.k or max(1, B // 10)
        X = self._seed_population(n)
        S = np.array([self.evaluate_set(_topk_indices(X[i], size)) for i in range(n)], dtype=np.float64)
        for i in range(n):
            self.consider(_topk_indices(X[i], size), float(S[i]))

        order = np.argsort(-S)
        alpha_X, beta_X, delta_X = X[order[0]].copy(), X[order[1]].copy(), X[order[min(2, n - 1)]].copy()

        for it in range(self.max_iter):
            if self.exhausted():
                break
            a = 2.0 - 2.0 * it / max(self.max_iter - 1, 1)
            A = 2 * a * self.rng.random((n, B)) - a
            C = 2 * self.rng.random((n, B))
            X1 = alpha_X[None, :] - A * C * np.abs(C * alpha_X[None, :] - X)
            A = 2 * a * self.rng.random((n, B)) - a
            C = 2 * self.rng.random((n, B))
            X2 = beta_X[None, :] - A * C * np.abs(C * beta_X[None, :] - X)
            A = 2 * a * self.rng.random((n, B)) - a
            C = 2 * self.rng.random((n, B))
            X3 = delta_X[None, :] - A * C * np.abs(C * delta_X[None, :] - X)
            X = np.clip((X1 + X2 + X3) / 3.0, 0.0, 1.0)

            for i in range(n):
                if self.exhausted():
                    break
                b = _topk_indices(X[i], size)
                s = self.evaluate_set(b)
                self.consider(b, s)
            S = np.array([self.evaluate_set(_topk_indices(X[i], size)) for i in range(n)], dtype=np.float64)
            order = np.argsort(-S)
            alpha_X, beta_X, delta_X = X[order[0]].copy(), X[order[1]].copy(), X[order[min(2, n - 1)]].copy()
            self.record()


# ---------------------------------------------------------------- DE
class DE(Optimizer):
    """Differential evolution, DE/rand/1/bin, on the continuous relaxation."""

    name = 'DE'
    family = 'evolutionary'

    def __init__(self, *args, F: float = 0.5, CR: float = 0.9, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.F, self.CR = float(F), float(CR)

    def describe_params(self) -> Dict[str, object]:
        return {'pop': self.pop_size, 'iter': self.max_iter, 'F': self.F, 'CR': self.CR,
                'nfe_budget': self.nfe_budget}

    def _search(self) -> None:
        n, B = self.pop_size, self.n_bands
        size = self.k or max(1, B // 10)
        X = self._seed_population(n)
        S = np.array([self.evaluate_set(_topk_indices(X[i], size)) for i in range(n)], dtype=np.float64)
        for i in range(n):
            self.consider(_topk_indices(X[i], size), float(S[i]))

        for it in range(self.max_iter):
            if self.exhausted():
                break
            for i in range(n):
                if self.exhausted():
                    break
                pool = [j for j in range(n) if j != i]
                a, b, c = self.rng.choice(pool, size=3, replace=False)
                mutant = np.clip(X[a] + self.F * (X[b] - X[c]), 0.0, 1.0)
                mask = self.rng.random(B) < self.CR
                if not mask.any():
                    mask[self.rng.integers(B)] = True
                jrand = int(self.rng.integers(B))
                mask[jrand] = True
                trial = np.where(mask, mutant, X[i])
                tb = _topk_indices(trial, size)
                ts = self.evaluate_set(tb)
                if ts > S[i]:
                    X[i], S[i] = trial, ts
                    self.consider(tb, ts)
            self.record()


# ---------------------------------------------------------------- registry
REGISTRY: Dict[str, Type[Optimizer]] = {
    'PSO': PSO,
    'SAPSO': SAPSO,
    'MPSO': MPSO,
    'IEPSO': IEPSO,
    'DESAPSO': DESAPSO,
    'GA': GA,
    'SA': SA,
    'GWO': GWO,
    'DE': DE,
}

ALIASES = {
    'SPSO': 'PSO',          # the manuscript's "SPSO" is treated as standard PSO
    'PSO-SA': 'SAPSO',
    'MPSO-ZL': 'MPSO',      # Zhang & Liu (2021) elimination-mechanism variant
    'MPSO-0.4': 'MPSO',     # same variant, appendix threshold tau = 0.4
    'IEPSO-LV': 'IEPSO',    # Lv et al. (2018), the IEPSO of Zhang & Liu's set
    # ---- contribution (ii): JM objective + redundancy-penalty term ----
    # Each condition is the paper's SAPSO wrapped with a different redundancy
    # penalty beta (see criteria.FitnessSpec.redundancy_penalty); the three
    # conditions form Table F (new table) of the R1-2 design.
    'JMRED0': 'SAPSO',      # beta = 0.0   (pure JM, baseline)
    'JMRED3': 'SAPSO',      # beta = 0.3   (moderate penalty)
    'JMRED6': 'SAPSO',      # beta = 0.6   (strong penalty)
    'ABC': None,
}


def list_methods() -> List[str]:
    return list(REGISTRY)


def make_optimizer(method: str, fitness, n_bands: int, k: Optional[int] = None,
                   nfe_budget: int = 3000, seed: int = 1, pop_size: int = 30,
                   **params) -> Optimizer:
    key = ALIASES.get(method.upper(), method.upper())
    if key is None or key not in REGISTRY:
        raise KeyError('unknown method %r; available: %s' % (method, ', '.join(REGISTRY)))
    cls = REGISTRY[key]
    opt = cls(fitness, n_bands=n_bands, k=k, nfe_budget=nfe_budget, seed=seed,
              pop_size=pop_size, **params)
    opt.name = method if method.upper() != key else key
    return opt
