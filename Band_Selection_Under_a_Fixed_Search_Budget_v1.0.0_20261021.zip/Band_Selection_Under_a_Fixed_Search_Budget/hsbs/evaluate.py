"""Classifiers, classification metrics and statistical tests.

The metrics are split into two layers on purpose, because R1-2 explicitly asks
for both the selected band count and OA/Kappa to be reported:

* band-selection layer -- objective value, JM mean/max/min, redundancy, k, NFE, runtime
* classification layer -- OA, AA, Kappa, per-class accuracy, macro F1, confusion matrix
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

__all__ = [
    'ClassifierSpec', 'CLASSIFIERS', 'fit_predict', 'classification_metrics',
    'evaluate_subset', 'paired_test', 'paired_t_test', 'wilcoxon_signed_rank',
    'friedman_test', 'nemenyi_cd', 'average_ranks', 'bootstrap_ci',
    'NEMENYI_Q05',
]

# --------------------------------------------------------------------- classifiers
@dataclass
class ClassifierSpec:
    key: str
    label: str
    factory: object
    params: Dict[str, object] = field(default_factory=dict)
    note: str = ''

    def make(self):
        return self.factory(**self.params)

    def describe(self) -> str:
        bits = ', '.join('%s=%s' % (k, v) for k, v in sorted(self.params.items()))
        return '%s(%s)' % (self.label, bits)


def _knn(k: int = 5):
    from sklearn.neighbors import KNeighborsClassifier
    return KNeighborsClassifier(n_neighbors=k, n_jobs=1)


def _svm_rbf(C: float = 100.0, gamma: str = 'scale'):
    from sklearn.svm import SVC
    return SVC(C=C, kernel='rbf', gamma=gamma)


def _rf(n_estimators: int = 200, random_state: int = 0):
    from sklearn.ensemble import RandomForestClassifier
    return RandomForestClassifier(n_estimators=n_estimators, random_state=random_state, n_jobs=1)


CLASSIFIERS: Dict[str, ClassifierSpec] = {
    'knn5':   ClassifierSpec('knn5', 'KNN', _knn, {'k': 5}, 'primary classifier, matches the manuscript'),
    'knn1':   ClassifierSpec('knn1', '1-NN', _knn, {'k': 1}, 'sanity baseline'),
    'knn3':   ClassifierSpec('knn3', '3-NN', _knn, {'k': 3}, 'sensitivity check on k'),
    'svm_rbf': ClassifierSpec('svm_rbf', 'RBF-SVM', _svm_rbf, {'C': 100.0, 'gamma': 'scale'}, 'classifier-invariance check'),
    'rf':     ClassifierSpec('rf', 'RF', _rf, {'n_estimators': 200, 'random_state': 0}, 'classifier-invariance check'),
}


def fit_predict(spec: ClassifierSpec, Xtr: np.ndarray, ytr: np.ndarray,
                Xte: np.ndarray, standardize: bool = True) -> np.ndarray:
    """Fit a classifier on (Xtr, ytr) and predict Xte.

    `standardize` rescales bands to zero mean / unit variance, which matters
    when different bands have very different dynamic ranges. It is applied to
    train and test with the *train* statistics only.
    """
    Xtr = np.asarray(Xtr, dtype=np.float64)
    Xte = np.asarray(Xte, dtype=np.float64)
    if standardize:
        mu = Xtr.mean(axis=0, keepdims=True)
        sd = Xtr.std(axis=0, keepdims=True)
        sd[sd < 1e-12] = 1e-12
        Xtr = (Xtr - mu) / sd
        Xte = (Xte - mu) / sd
    clf = spec.make()
    clf.fit(Xtr, ytr)
    return np.asarray(clf.predict(Xte)).ravel()


# --------------------------------------------------------------------- metrics
def classification_metrics(y_true: np.ndarray, y_pred: np.ndarray,
                           labels: Optional[Sequence[int]] = None) -> Dict[str, object]:
    """OA / AA / Kappa / per-class accuracy / macro-F1 / confusion matrix."""
    y_true = np.asarray(y_true).ravel().astype(np.int64)
    y_pred = np.asarray(y_pred).ravel().astype(np.int64)
    if y_true.size != y_pred.size:
        raise ValueError('y_true and y_pred differ in length')
    if labels is None:
        labels = sorted(set(np.unique(y_true).tolist()) | set(np.unique(y_pred).tolist()))
    labels = [int(c) for c in labels]
    idx = {c: i for i, c in enumerate(labels)}
    n = len(labels)

    cm = np.zeros((n, n), dtype=np.int64)
    for t, p in zip(y_true, y_pred):
        if t in idx and p in idx:
            cm[idx[t], idx[p]] += 1

    total = int(cm.sum())
    oa = float(np.trace(cm) / total) if total else 0.0

    present = [i for i in range(n) if cm[i].sum() > 0]
    per_class = {}
    for i in range(n):
        denom = cm[i].sum()
        per_class[labels[i]] = float(cm[i, i] / denom) if denom else float('nan')
    aa = float(np.nanmean([per_class[labels[i]] for i in present])) if present else 0.0

    row = cm.sum(axis=1).astype(np.float64)
    col = cm.sum(axis=0).astype(np.float64)
    if total:
        pe = float((row * col).sum() / (total * total))
    else:
        pe = 0.0
    kappa = float((oa - pe) / (1.0 - pe)) if abs(1.0 - pe) > 1e-12 else 0.0

    f1s = []
    for i in present:
        tp = cm[i, i]
        fp = col[i] - tp
        fn = row[i] - tp
        prec = tp / (tp + fp) if (tp + fp) else 0.0
        rec = tp / (tp + fn) if (tp + fn) else 0.0
        f1s.append(2 * prec * rec / (prec + rec) if (prec + rec) else 0.0)

    return {'OA': oa * 100.0, 'AA': aa * 100.0, 'Kappa': kappa,
            'macro_F1': float(np.mean(f1s) * 100.0) if f1s else 0.0,
            'n_test': total, 'per_class_acc': per_class,
            'confusion': cm.tolist(), 'labels': labels}


def evaluate_subset(ds, train_idx: Sequence[int], test_idx: Sequence[int],
                    bands: Sequence[int], spec: ClassifierSpec,
                    standardize: bool = True) -> Dict[str, object]:
    """Full classification evaluation of one band subset under one split."""
    mat = ds.as_matrix()
    labels = ds.labels()
    tr = np.asarray(list(train_idx), dtype=np.int64)
    te = np.asarray(list(test_idx), dtype=np.int64)
    b = list(bands)
    Xtr, ytr = mat[tr][:, b], labels[tr]
    Xte, yte = mat[te][:, b], labels[te]
    pred = fit_predict(spec, Xtr, ytr, Xte, standardize=standardize)
    out = classification_metrics(yte, pred, labels=list(ds.classes))
    out['classifier'] = spec.key
    out['bands_1based'] = [int(x) + 1 for x in b]
    out['k'] = len(b)
    return out


# --------------------------------------------------------------------- statistics
def paired_t_test(a: Sequence[float], b: Sequence[float]) -> Dict[str, float]:
    from scipy import stats
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    if a.size != b.size or a.size < 2:
        return {'statistic': float('nan'), 'p_value': float('nan'), 'n': int(a.size)}
    t, p = stats.ttest_rel(a, b)
    return {'statistic': float(t), 'p_value': float(p), 'n': int(a.size),
            'mean_diff': float((a - b).mean())}


def paired_t_test_greater(a, b):
    from scipy import stats
    a = np.asarray(a, dtype=np.float64); b = np.asarray(b, dtype=np.float64)
    t, p = stats.ttest_rel(a, b)
    return {'statistic': float(t), 'p_one_sided': float(p / 2 if t > 0 else 1 - p / 2),
            'mean_diff': float((a - b).mean())}


def wilcoxon_signed_rank(a: Sequence[float], b: Sequence[float]) -> Dict[str, float]:
    from scipy import stats
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    d = a - b
    if a.size < 5 or np.allclose(d, 0):
        return {'statistic': float('nan'), 'p_value': float('nan'), 'n': int(a.size),
                'note': 'needs >=5 pairs with non-zero differences'}
    try:
        s, p = stats.wilcoxon(a, b, zero_method='wilcox', alternative='two-sided')
    except ValueError:
        return {'statistic': float('nan'), 'p_value': float('nan'), 'n': int(a.size), 'note': 'degenerate'}
    return {'statistic': float(s), 'p_value': float(p), 'n': int(a.size),
            'mean_diff': float(d.mean())}


def paired_test(a: Sequence[float], b: Sequence[float]) -> Dict[str, object]:
    """Both tests plus the confidence interval of the mean difference."""
    from scipy import stats
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    out = {'n_pairs': int(a.size), 'mean_a': float(a.mean()), 'mean_b': float(b.mean()),
           'mean_diff': float((a - b).mean())}
    out['t_test'] = paired_t_test(a, b)
    out['wilcoxon'] = wilcoxon_signed_rank(a, b)
    if a.size >= 2:
        se = (a - b).std(ddof=1) / np.sqrt(a.size)
        tcrit = float(stats.t.ppf(0.975, a.size - 1))
        out['ci95_diff'] = [float((a - b).mean() - tcrit * se), float((a - b).mean() + tcrit * se)]
    return out


def average_ranks(scores: Dict[str, Sequence[float]], higher_is_better: bool = True) -> Dict[str, float]:
    """Average rank per method across paired blocks (higher score -> rank 1)."""
    keys = list(scores)
    if not keys:
        return {}
    lens = {len(np.asarray(scores[k])) for k in keys}
    if len(lens) != 1:
        raise ValueError('all methods need the same number of paired blocks, got %r' % lens)
    n = lens.pop()
    sign = -1.0 if higher_is_better else 1.0
    ranks = {k: [] for k in keys}
    for i in range(n):
        vals = np.array([sign * np.asarray(scores[k])[i] for k in keys])
        order = np.argsort(vals, kind='mergesort')
        r = np.empty(len(keys))
        r[order] = np.arange(1, len(keys) + 1)
        # average ties
        for v in np.unique(vals):
            m = vals == v
            if m.sum() > 1:
                r[m] = r[m].mean()
        for j, k in enumerate(keys):
            ranks[k].append(float(r[j]))
    return {k: float(np.mean(v)) for k, v in ranks.items()}


# Nemenyi critical values q_0.05 divided by sqrt(2), from Demsar (2006) Table 5
NEMENYI_Q05 = {2: 1.960, 3: 2.343, 4: 2.569, 5: 2.728, 6: 2.850,
               7: 2.949, 8: 3.031, 9: 3.102, 10: 3.164, 11: 3.219,
               12: 3.268, 13: 3.313, 14: 3.354, 15: 3.391}


def friedman_test(scores: Dict[str, Sequence[float]]) -> Dict[str, object]:
    """Friedman test over paired blocks + Nemenyi critical difference."""
    from scipy import stats
    keys = sorted(scores)
    arr = np.array([np.asarray(scores[k], dtype=np.float64) for k in keys])
    if arr.ndim != 2 or arr.shape[0] < 3:
        return {'note': 'needs at least 3 methods', 'n_methods': arr.shape[0]}
    # Degenerate case: every method scores identically in every block, so all
    # ranks are tied. scipy then divides by zero and returns NaN -- report it
    # explicitly instead of emitting a NaN p-value into the results table.
    if arr.shape[1] == 0 or np.allclose(arr, arr[0], equal_nan=True):
        return {'note': 'all methods tie in every block; Friedman undefined',
                'statistic': 0.0, 'p_value': 1.0,
                'n_methods': int(arr.shape[0]), 'n_blocks': int(arr.shape[1]),
                'avg_ranks': average_ranks({k: scores[k] for k in keys}, higher_is_better=True),
                'nemenyi_cd': nemenyi_cd(int(arr.shape[0]), int(arr.shape[1]))}
    with np.errstate(invalid='ignore', divide='ignore'):
        stat, p = stats.friedmanchisquare(*[arr[i] for i in range(arr.shape[0])])
    stat = float(stat) if np.isfinite(stat) else 0.0
    p = float(p) if np.isfinite(p) else 1.0
    ranks = average_ranks({k: scores[k] for k in keys}, higher_is_better=True)
    return {'statistic': stat, 'p_value': p,
            'n_methods': int(arr.shape[0]), 'n_blocks': int(arr.shape[1]),
            'avg_ranks': ranks,
            'nemenyi_cd': nemenyi_cd(int(arr.shape[0]), int(arr.shape[1]))}


def nemenyi_cd(k: int, n: int, alpha: float = 0.05) -> Optional[float]:
    """Nemenyi critical difference for k methods over n paired blocks."""
    if k not in NEMENYI_Q05:
        return None
    q = NEMENYI_Q05[k]
    return float(q * np.sqrt(k * (k + 1) / (6.0 * n)))


def bootstrap_ci(values: Sequence[float], n_boot: int = 2000, alpha: float = 0.05,
                 seed: int = 0) -> Tuple[float, float]:
    v = np.asarray(values, dtype=np.float64)
    if v.size < 2:
        return (float(v.mean()) if v.size else float('nan'),) * 2
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, v.size, size=(n_boot, v.size))
    means = v[idx].mean(axis=1)
    return float(np.percentile(means, 100 * alpha / 2)), float(np.percentile(means, 100 * (1 - alpha / 2)))


def describe_block(a: Sequence[float]) -> Dict[str, float]:
    v = np.asarray(a, dtype=np.float64)
    lo, hi = bootstrap_ci(v)
    return {'mean': float(v.mean()), 'std': float(v.std(ddof=1)) if v.size > 1 else 0.0,
            'min': float(v.min()), 'max': float(v.max()), 'median': float(np.median(v)),
            'ci95': [lo, hi], 'n': int(v.size)}
