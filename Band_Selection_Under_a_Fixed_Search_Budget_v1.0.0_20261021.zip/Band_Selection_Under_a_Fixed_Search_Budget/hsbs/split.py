"""Shared stratified splits.

Every competing method must see the *same* pixel partition for a given seed,
otherwise the comparison is not paired and the statistical tests lose their
meaning. Splits are therefore generated once and stored, never per method.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, Iterable, List, Optional, Sequence

import numpy as np

__all__ = ['Split', 'make_splits', 'make_disjoint_splits',
           'save_splits', 'load_splits', 'split_summary']


@dataclass
class Split:
    seed: int
    train_idx: np.ndarray        # flat pixel indices into the (H*W) grid
    test_idx: np.ndarray
    ratio: float
    per_class: Dict[int, int]    # class -> number of training pixels

    def as_dict(self) -> Dict[str, object]:
        d = asdict(self)
        d['train_idx'] = self.train_idx
        d['test_idx'] = self.test_idx
        return d


def make_splits(labels: np.ndarray, ratio: float = 0.2, seeds: Sequence[int] = tuple(range(1, 11)),
                min_per_class: int = 5, max_per_class: Optional[int] = None,
                verbose: bool = False) -> List[Split]:
    """Per-class stratified split: `ratio` of each class trains, the rest tests.

    Parameters
    ----------
    labels : (H*W,) int array, 0 == unlabelled (always excluded)
    ratio : training fraction, e.g. 0.20 as in the manuscript
    seeds : the shared seed list (all methods reuse exactly these)
    min_per_class : raise if a class would fall below this many training pixels
    max_per_class : optionally cap the training pixels per class (speed switch)
    """
    labels = np.asarray(labels).ravel()
    classes = sorted(int(c) for c in np.unique(labels) if int(c) != 0)
    if not classes:
        raise ValueError('no labelled pixels')
    if not 0.0 < ratio < 1.0:
        raise ValueError('ratio must be in (0, 1)')

    per_class_idx = {c: np.flatnonzero(labels == c) for c in classes}
    for c in classes:
        if per_class_idx[c].size < 2:
            raise ValueError('class %d has only %d pixel(s)' % (c, per_class_idx[c].size))

    out: List[Split] = []
    for seed in seeds:
        rng = np.random.default_rng(int(seed))
        tr_parts, te_parts, counts = [], [], {}
        for c in classes:
            idx = per_class_idx[c]
            perm = rng.permutation(idx.size)
            n_tr = int(round(ratio * idx.size))
            n_tr = max(n_tr, 1)
            if n_tr >= idx.size:
                n_tr = idx.size - 1
            if n_tr < min_per_class and idx.size >= min_per_class + 1:
                n_tr = min_per_class
            if max_per_class is not None:
                n_tr = min(n_tr, int(max_per_class))
            tr = np.sort(idx[perm[:n_tr]])
            te = np.sort(idx[perm[n_tr:]])
            tr_parts.append(tr)
            te_parts.append(te)
            counts[c] = int(tr.size)
        train = np.sort(np.concatenate(tr_parts))
        test = np.sort(np.concatenate(te_parts))
        overlap = np.intersect1d(train, test)
        if overlap.size:
            raise AssertionError('train/test overlap of %d pixels' % overlap.size)
        if train.size + test.size != int((labels != 0).sum()):
            raise AssertionError('split does not cover every labelled pixel')
        if verbose:
            print('  seed %-4d train=%d test=%d' % (seed, train.size, test.size))
        out.append(Split(seed=int(seed), train_idx=train, test_idx=test, ratio=float(ratio), per_class=counts))
    return out


def save_splits(path: str, splits: Sequence[Split], meta: Optional[Dict[str, object]] = None) -> None:
    payload = {'n': len(splits)}
    for k, v in (meta or {}).items():
        payload['meta_%s' % k] = v
    for i, s in enumerate(splits):
        payload['seed_%d' % i] = s.seed
        payload['ratio_%d' % i] = s.ratio
        payload['train_%d' % i] = s.train_idx
        payload['test_%d' % i] = s.test_idx
        payload['classes_%d' % i] = np.asarray(sorted(s.per_class), dtype=np.int32)
        payload['counts_%d' % i] = np.asarray([s.per_class[c] for c in sorted(s.per_class)], dtype=np.int32)
    np.savez_compressed(path, **payload)


def load_splits(path: str) -> List[Split]:
    z = np.load(path, allow_pickle=False)
    out = []
    for i in range(int(z['n'])):
        classes = z['classes_%d' % i].tolist()
        counts = z['counts_%d' % i].tolist()
        out.append(Split(seed=int(z['seed_%d' % i]), train_idx=z['train_%d' % i],
                         test_idx=z['test_%d' % i], ratio=float(z['ratio_%d' % i]),
                         per_class={int(c): int(n) for c, n in zip(classes, counts)}))
    return out


def make_disjoint_splits(labels: np.ndarray, ratio: float = 0.2, seeds: Sequence[int] = tuple(range(1, 11)),
                         n_blocks: int = 3, mode: str = 'block',
                         min_per_class: int = 5, verbose: bool = False,
                         H: Optional[int] = None, W: Optional[int] = None) -> List[Split]:
    """Spatially disjoint train/test partition (M-P1-6).

    The random per-class split used everywhere else lets a training pixel sit
    next to a test pixel, so the neighbourhood feature (window eta) leaks across
    the boundary and inflates OA -- the classic spatial-autocorrelation optimism
    bias. This function instead cuts the (H, W) grid into ``n_blocks`` x
    ``n_blocks`` spatial blocks (``mode='block'``) or into ``n_blocks`` horizontal
    strips (``mode='row'``), then assigns a fraction ``ratio`` of the blocks to
    training and the rest to testing. No labelled pixel in the test set shares a
    block with a training pixel, so the comparison against the random split is a
    fair read on the leakage magnitude.

    Only *labelled* pixels inside each selected block are used; unlabelled pixels
    are dropped and never appear in either index set.
    """
    labels = np.asarray(labels).ravel()
    if H is not None and W is not None:
        Hh, Ww = int(H), int(W)
        if Hh * Ww != labels.size:
            raise ValueError('make_disjoint_splits: H*W=%d does not match '
                             'labels.size=%d' % (Hh * Ww, labels.size))
    else:
        Hh = Ww = int(np.sqrt(labels.size))
        if Hh * Ww != labels.size:
            raise ValueError('make_disjoint_splits needs a square (H==W) label grid '
                             'or explicit H/W (got %d px, not a perfect square)'
                             % labels.size)
    classes = sorted(int(c) for c in np.unique(labels) if int(c) != 0)
    if not classes:
        raise ValueError('no labelled pixels')
    if not 0.0 < ratio < 1.0:
        raise ValueError('ratio must be in (0, 1)')

    # block id of every labelled pixel
    yy, xx = np.unravel_index(np.arange(labels.size), (Hh, Ww))
    if mode == 'row':
        block_id = (yy // max(1, Hh // n_blocks))
    else:  # block grid
        by = (yy // max(1, Hh // n_blocks))
        bx = (xx // max(1, Ww // n_blocks))
        block_id = by * n_blocks + bx
    block_id = block_id.astype(np.int64)

    unique_blocks = sorted(set(block_id[labels != 0].tolist()))
    n_train_blocks = max(1, int(round(ratio * len(unique_blocks))))

    out: List[Split] = []
    for seed in seeds:
        rng = np.random.default_rng(int(seed))
        perm = rng.permutation(unique_blocks)
        train_blocks = set(perm[:n_train_blocks].tolist())
        train_mask = np.isin(block_id, list(train_blocks)) & (labels != 0)
        test_mask = (~np.isin(block_id, list(train_blocks))) & (labels != 0)
        train = np.sort(np.flatnonzero(train_mask).astype(np.int64))
        test = np.sort(np.flatnonzero(test_mask).astype(np.int64))
        if train.size == 0 or test.size == 0:
            raise AssertionError('disjoint split left a side empty (seed=%s)' % seed)
        counts = {c: int(((labels[train] == c)).sum()) for c in classes}
        out.append(Split(seed=int(seed), train_idx=train, test_idx=test,
                        ratio=float(ratio), per_class=counts))
        if verbose:
            print('  seed %-4d (disjoint/%s) train=%d test=%d blocks %d/%d'
                  % (seed, mode, train.size, test.size,
                     n_train_blocks, len(unique_blocks)))
    return out


def split_summary(splits: Sequence[Split]) -> str:
    if not splits:
        return '(no splits)'
    first = splits[0]
    lines = ['splits      : %d' % len(splits),
             'seeds       : %s' % ', '.join(str(s.seed) for s in splits),
             'ratio       : %.3f' % first.ratio,
             'train/test  : %d / %d' % (first.train_idx.size, first.test_idx.size)]
    for c, n in sorted(first.per_class.items()):
        lines.append('   class %-3d train %6d' % (c, n))
    return '\n'.join(lines)
