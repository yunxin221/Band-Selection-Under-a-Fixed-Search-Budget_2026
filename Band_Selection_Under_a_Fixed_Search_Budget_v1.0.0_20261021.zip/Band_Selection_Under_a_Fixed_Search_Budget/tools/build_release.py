#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
build_release.py -- assemble the GitHub / Zenodo archive, named after the article.

Produces

    release/Band_Selection_Under_a_Fixed_Search_Budget_v1.0.0_<YYYYMMDD>.zip

whose single top-level directory is

    Band_Selection_Under_a_Fixed_Search_Budget/
      README.md  LICENSE  CITATION.cff  RELEASE_NOTES.md  requirements.txt
      hsbs/  configs/  tools/  results/  data/
      <entry-point scripts>

Design decisions encoded here
-----------------------------
* The workspace `data/` entry may be a Windows junction pointing outside the
  repository (used so experiments can read the 184 MB cubes without copying
  them).  A junction cannot be pushed to GitHub, so it is **never** copied;
  `data/` is materialised in the staging area from the derived, redistributable
  content only (wavelength tables, manifest, provenance, README).
* `output/` (run caches, hundreds of MB) and `.git/`, `__pycache__/`, `*.log`
  are excluded -- all of it is regenerable.
* `results/` is included: it is the small, derived evidence behind the tables.

Usage
-----
    python tools/build_release.py                  # build + zip
    python tools/build_release.py --no-zip         # stage only
    python tools/build_release.py --version 1.1.0
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import shutil
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE.parent
WS = PKG.parent.parent                       # E:/WorkBuddy/文章/mpdi
DEFAULT_STAGING = PKG.parent / "_staging"

ARTICLE_DIRNAME = "Band_Selection_Under_a_Fixed_Search_Budget"
ARTICLE_TITLE = ("Band Selection Under a Fixed Search Budget: A Reproducible "
                 "Spatial-Spectral Framework for On-Board Hyperspectral Classification")

# Top-level files copied verbatim.
TOP_FILES = [
    "README.md", "LICENSE", "CITATION.cff", "requirements.txt",
    ".gitignore", ".gitattributes",
]

# Top-level directories copied verbatim (data/ handled separately).
TOP_DIRS = ["hsbs", "configs", "tools", "results"]

# Entry-point scripts.  Anything not listed here and not in TOP_DIRS is treated
# as workspace scratch and dropped, so a stray helper file cannot leak into the
# archive.
ENTRY_SCRIPTS = [
    "aggregate_results.py",
    "batch7_8_run.py",
    "make_runtime_tables.py",
    "make_spatial_split_table.py",
    "merge.py",
    "prep_dataset.py",
    "progress.py",
    "run_hybridsn.py",
    "run_pipeline.py",
    "run_runtime_profile.py",
    "run_sapso_all_operators.py",
    "run_sapso_three_classifiers.py",
    "run_selftest.py",
]

EXCLUDE_NAMES = {".git", "__pycache__", "output", ".pytest_cache", ".venv"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".log", ".npz", ".bak"}
EXCLUDE_PREFIXES = ("_", ".")                # inside copied dirs; top-level handled explicitly

DATA_README = """# Data

## What is here

| Path | What it is |
|---|---|
| `meta/longkou_wavelengths_270.{csv,json}` | WHU-Hi-LongKou band-centre wavelengths (270 ch) |
| `meta/indian_pines_wavelengths_200.{csv,json}` | Indian Pines band-centre wavelengths (200 ch) |
| `meta/selected_bands_wavelengths.csv` | wavelengths of the bands the search actually selected |
| `meta/WHU-Hi-LongKou.hdr` | official ENVI header the LongKou wavelengths were read from |
| `meta/AVIRIS_1992_220ch_calibration.txt` | AVIRIS-1992 calibration the Indian Pines wavelengths were read from |
| `dataset_manifest.json` | scene shapes, class counts, per-scene fingerprints |

The wavelength tables are **not** shipped with either public dataset; they are
reconstructed here from official sensor documentation by `tools/extract_wavelengths.py`
and verified by `tools/verify_wavelengths.py`. They are therefore our derived
data and are released under the same MIT licence as the code.

## What is NOT here, and why

The two hyperspectral cubes (~184 MB) are third-party and are not redistributed:

* **WHU-Hi-LongKou** — RSIDEA group, Wuhan University,
  <http://rsidea.whu.edu.cn/resource_WHUHi_sharing.htm>
* **Indian Pines** — Purdue University Research Repository,
  <doi:10.4231/R7RX991C> (AVIRIS 1992)

Download them and place them at:

```
data/raw/WHU_Hi_LongKou.mat
data/raw/WHU_Hi_LongKou_gt.mat
data/raw/Indian_pines_corrected.mat
data/raw/Indian_pines_gt.mat
```

then run `python prep_dataset.py` to verify them.

`results/data_provenance.json` in the parent directory records the SHA-256 of the
exact four files every released number was computed from, so you can confirm you
hold the same bytes before comparing against `results/`.
"""

RELEASE_NOTES_TEMPLATE = """# Release notes

**Archive** — `{zip_name}`
**Article** — {title}
**Version** — v{version} · built {date}

## Contents

| Path | Contents |
|---|---|
| `hsbs/` | core library: criteria (JM, JMRED), optimisers, static selectors, spatial operators, classifiers, splits, HybridSN |
| `configs/` | 16 experiment configurations (JSON) — datasets, budget, k, seeds, spatial specs |
| `tools/` | wavelength traceability, result export, archive builder |
| `results/` | released evidence: selected bands, per-seed metrics, HybridSN five-arm runs, Friedman/Nemenyi, input SHA-256 |
| `data/` | derived wavelength tables + dataset manifest (**raw cubes not included**, see `data/README.md`) |
| `*.py` | 13 entry-point scripts, one per experiment group |

## What a reader can check without re-running anything

Every number in Tables 2, 3, A2 and 12, and the statistics of §4.5, are in
`results/`. `results/results_index.json` is the index.

## Known limits of this archive

1. **Raw cubes excluded** — third-party redistribution terms (see `data/README.md`).
   `results/data_provenance.json` carries their SHA-256 instead.
2. **GPU non-determinism** — HybridSN OA shifts by up to ~0.8 pp between runs on
   CUDA. All contrasts in the paper are paired within a seed.
3. **Budget cap ≠ budget spent** — the 3000-evaluation budget is a ceiling;
   realised counts (412–2986) are in `results/selection_*.csv`.
4. **Random-split rows of Table 12 use 5 seeds**, not 10: under a per-pixel split
   every arm exceeds 99.8 % OA, so additional seeds add no information. The `n`
   column of Table 12 states this.
5. **Timing is laptop-CPU timing** (Intel Core i9-12900H), not payload-processor
   timing. See Figure 10 and §4.10 of the paper.

## Before publishing

1. Replace `<OWNER>/<REPO>` in `CITATION.cff` with the real GitHub path.
2. Tag `v{version}` and enable the GitHub ↔ Zenodo integration.
3. Put the minted DOI in the manuscript's Data Availability Statement and in
   `CITATION.cff` under `identifiers:`.
"""


def collect(log: list):
    """Return [(abs_path, arcname)] for everything that goes into the archive.

    Files are read straight from the package; nothing is staged on disk, so the
    builder never deletes anything.
    """
    items: list = []

    for name in TOP_FILES:
        src = PKG / name
        if src.exists():
            items.append((src, f"{ARTICLE_DIRNAME}/{name}"))
            log.append(name)
        else:
            print(f"  [warn] missing {name}")

    for d in TOP_DIRS:
        src = PKG / d
        if not src.exists():
            print(f"  [warn] missing {d}/")
            continue
        if src.resolve() != src:
            print(f"  [warn] {d} is a link; materialising instead of following")
            continue
        n = 0
        for f in sorted(src.rglob("*")):
            if not f.is_file():
                continue
            rel = f.relative_to(src).as_posix()
            parts = rel.split("/")
            if any(p in EXCLUDE_NAMES or p.startswith(EXCLUDE_PREFIXES) for p in parts[:-1]):
                continue
            if parts[-1].startswith("_") or f.suffix in EXCLUDE_SUFFIXES:
                continue
            items.append((f, f"{ARTICLE_DIRNAME}/{d}/{rel}"))
            n += 1
        log.append(f"{d}/  ({n} files)")

    n_script = 0
    for s in ENTRY_SCRIPTS:
        src = PKG / s
        if src.exists():
            items.append((src, f"{ARTICLE_DIRNAME}/{s}"))
            n_script += 1
        else:
            print(f"  [warn] missing {s}")
    log.append(f"{n_script} entry-point scripts")

    # data/ is materialised rather than copied: see _materialise_data.
    src = PKG / "data"
    if src.resolve() != src:
        print("  [info] data/ is a junction in the workspace; materialising "
              "redistributable content only")
    for f in sorted((WS / "data" / "meta").glob("*")):
        if f.is_file():
            items.append((f, f"{ARTICLE_DIRNAME}/data/meta/{f.name}"))
    manifest = WS / "data" / "dataset_manifest.json"
    if manifest.exists():
        items.append((manifest, f"{ARTICLE_DIRNAME}/data/dataset_manifest.json"))
    # data/README.md is written from DATA_README below rather than copied, so
    # the archive always carries the canonical text even if the workspace copy
    # has drifted.
    log.append("data/  (derived wavelength tables + manifest; raw cubes excluded)")
    return items


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--version", default="1.0.0")
    ap.add_argument("--out", type=Path, default=None,
                    help="output .zip path (default: ../<article>_v<version>_<date>.zip)")
    args = ap.parse_args(argv)

    today = dt.date.today().strftime("%Y%m%d")
    zip_name = f"{ARTICLE_DIRNAME}_v{args.version}_{today}.zip"
    zip_path = args.out or (PKG.parent / zip_name)

    log: list = []
    print(f"Building {zip_name}")
    items = [it for it in collect(log) if it[0] is not None]

    notes = RELEASE_NOTES_TEMPLATE.format(
        zip_name=zip_path.name, title=ARTICLE_TITLE,
        version=args.version, date=dt.date.today().isoformat())
    build_info = json.dumps({
        "article": ARTICLE_TITLE,
        "archive": zip_path.name,
        "version": args.version,
        "built": dt.datetime.now().isoformat(timespec="seconds"),
        "python": sys.version.split()[0],
        "contents": log,
    }, indent=2, ensure_ascii=False)

    total = 0
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for src, arc in items:
            zf.write(src, arc)
            total += src.stat().st_size
        zf.writestr(f"{ARTICLE_DIRNAME}/RELEASE_NOTES.md", notes)
        zf.writestr(f"{ARTICLE_DIRNAME}/BUILD_INFO.json", build_info)
        zf.writestr(f"{ARTICLE_DIRNAME}/data/README.md", DATA_README)

    print("\nContents:")
    for line in log:
        print("  -", line)
    print(f"\n{len(items) + 3} entries, {total / 1e6:.2f} MB uncompressed")
    print(f"Archive -> {zip_path}  ({zip_path.stat().st_size / 1e6:.2f} MB)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
