"""Static (non-iterative) band selectors for R1-2 categories II-IV.

These methods do NOT optimise the shared JM objective and therefore have no
convergence curve. Each consumes the *training* pixel matrix ``X`` (same data
partition the optimisers see -- no test leakage) and, optionally, the training
labels, and returns exactly ``k`` band indices (0-based, ascending, unique),
deterministically given the seed. The classification layer in ``runner.py`` then
evaluates the selected bands under the identical protocol used for the
optimisers (same split, classifiers, seeds), which is the fair cross-paradigm
comparison the R1-2 design calls for.

Fidelity note: per the R1-2 kickoff decision (issue 2 = "C: no source code,
rebuild from the standard literature definitions"), these are reconstructed from
the published algorithm descriptions, not byte-exact to the authors' code. Every
class records its primary reference so the reconstruction is auditable.
"""
from __future__ import annotations

import hashlib
from typing import Dict, List, Optional, Sequence, Tuple, Type

import numpy as np

__all__ = ['StaticSelector', 'REGISTRY', 'list_static', 'select_bands']

# ----------------------------------------------------------------- cache
# Band-distance matrices only depend on (X, labels, seed); within one run the
# same training split is reused across k values, so we memoize per (name, seed).
_BAND_DIST_CACHE: Dict[Tuple[str, int, str, str], np.ndarray] = {}


def _fp(X: np.ndarray, labels: np.ndarray, seed: int) -> Tuple[str, str, int]:
    xb = np.ascontiguousarray(np.asarray(X, dtype=np.float32))[::max(1, X.shape[0] // 200)]
    lb = np.ascontiguousarray(np.asarray(labels).ravel())[::max(1, labels.size // 200)]
    hx = hashlib.sha1(xb.tobytes()).hexdigest()[:10]
    hl = hashlib.sha1(lb.tobytes()).hexdigest()[:6]
    return (hx, hl, int(seed))


# ----------------------------------------------------------------- helpers
def _corr_distance(X: np.ndarray) -> np.ndarray:
    """1 - |Pearson r| between bands (cheap, unsupervised)."""
    X = np.asarray(X, dtype=np.float64)
    Xc = X - X.mean(axis=0, keepdims=True)
    sd = Xc.std(axis=0)
    sd[sd < 1e-12] = 1e-12
    Z = Xc / sd
    R = (Z.T @ Z) / max(Z.shape[0] - 1, 1)
    R = np.abs(np.clip(R, -1.0, 1.0))
    return 1.0 - R


def _jm_band_matrix(X: np.ndarray, labels: np.ndarray, reg: float = 1e-6) -> np.ndarray:
    """B x B dissimilarity: mean over class pairs of the 2-D JM on (band i, band j).

    Optimised: per-class second moments are computed once, then each class pair is
    evaluated over *all* band pairs in a single vectorised pass (the original
    double Python loop over band pairs x class pairs was ~100x slower and made
    HCBS/ASPS intractable on large scenes like Indian Pines, 16 classes).
    """
    X = np.asarray(X, dtype=np.float64)
    labels = np.asarray(labels).ravel()
    classes = [int(c) for c in np.unique(labels) if c != 0]
    B = X.shape[1]

    mu = {}      # c -> (B,) mean per band
    cov = {}     # c -> (B,B) covariance
    for c in classes:
        Xc = X[labels == c]
        if Xc.shape[0] < 2:
            continue
        m = Xc.mean(axis=0)
        C = (Xc.T @ Xc) / Xc.shape[0] - np.outer(m, m)
        mu[c], cov[c] = m, C

    live = [c for c in classes if c in mu]
    D = np.zeros((B, B))
    if len(live) < 2:
        return D

    # scale-based ridge, matching criteria.bhattacharyya_distance's reg*scale*I
    vscale = max(1e-12, np.mean([np.trace(cov[c]) for c in live]) / B)
    floor = reg * vscale
    I, J = np.triu_indices(B, k=1)

    valid_pairs = 0
    for a in live:
        for b in live:
            if a >= b:
                continue
            ma, mb = mu[a], mu[b]
            Ca, Cb = cov[a], cov[b]
            diff = ma - mb                                  # (B,)
            di = diff[I]; dj = diff[J]
            va_i = np.diag(Ca)[I] + floor
            va_j = np.diag(Ca)[J] + floor
            vb_i = np.diag(Cb)[I] + floor
            vb_j = np.diag(Cb)[J] + floor
            ca = Ca[I, J]; cb = Cb[I, J]
            sm11 = 0.5 * (va_i + vb_i)
            sm22 = 0.5 * (va_j + vb_j)
            sm12 = 0.5 * (ca + cb)
            det_sm = sm11 * sm22 - sm12 * sm12
            det_ca = va_i * va_j - ca * ca
            det_cb = vb_i * vb_j - cb * cb
            safe = det_sm > 0
            dsm = np.where(safe, det_sm, 1e-12)
            term1 = 0.125 * (sm22 * di * di - 2.0 * sm12 * di * dj + sm11 * dj * dj) / dsm
            with np.errstate(divide='ignore', invalid='ignore'):
                term2 = 0.5 * (np.log(np.maximum(det_sm, 1e-12))
                               - 0.5 * (np.log(np.maximum(det_ca, 1e-12))
                                        + np.log(np.maximum(det_cb, 1e-12))))
            term2 = np.where(np.isfinite(term2), term2, 0.0)
            bhat = np.clip(term1 + term2, 0.0, None)
            jm = np.sqrt(2.0 * (1.0 - np.exp(-bhat)))
            D[I, J] += jm
            D[J, I] += jm
            valid_pairs += 1

    if valid_pairs:
        D /= valid_pairs
    return D


def _medoid(D: np.ndarray, idx: np.ndarray) -> int:
    """Band in ``idx`` with the smallest mean intra-group distance."""
    idx = np.asarray(idx, dtype=int)
    sub = D[np.ix_(idx, idx)]
    return int(idx[int(np.argmin(sub.mean(axis=1)))])


def _hierarchical_cut(D: np.ndarray, k: int) -> List[int]:
    """Average-linkage agglomerative clustering -> k medoid representatives."""
    from scipy.cluster.hierarchy import fcluster, linkage
    from scipy.spatial.distance import squareform
    B = D.shape[0]
    if k >= B:
        return list(range(B))
    Z = linkage(squareform(D, checks=False), method='average')
    lab = fcluster(Z, k, criterion='maxclust')
    out = [_medoid(D, np.where(lab == c)[0]) for c in np.unique(lab)]
    return sorted(int(x) for x in out)


def _recursive_partition(D: np.ndarray, cut_frac: float = 0.5) -> List[List[int]]:
    """Cut a dendrogram at ``cut_frac * max_cophenetic`` -> list of band groups."""
    from scipy.cluster.hierarchy import fcluster, linkage
    from scipy.spatial.distance import squareform
    Z = linkage(squareform(D, checks=False), method='average')
    thr = float(np.max(Z[:, 2])) * cut_frac
    lab = fcluster(Z, thr, criterion='distance')
    return [list(map(int, np.where(lab == c)[0])) for c in np.unique(lab)]


def _local_density(D: np.ndarray, eps: float = 0.3) -> np.ndarray:
    """Gaussian-affinity-based local density of each band in the similarity graph."""
    A = np.exp(-(D ** 2) / (2 * eps ** 2))
    np.fill_diagonal(A, 0.0)
    return A.sum(axis=1)


def _band_entropy(X: np.ndarray, bins: int = 32) -> np.ndarray:
    """Per-band normalised Shannon entropy of the (min-max scaled) values."""
    X = np.asarray(X, dtype=np.float64)
    lo, hi = X.min(axis=0, keepdims=True), X.max(axis=0, keepdims=True)
    span = hi - lo
    span[span < 1e-12] = 1.0
    Xs = (X - lo) / span
    ent = np.zeros(X.shape[1])
    for b in range(X.shape[1]):
        h, _ = np.histogram(Xs[:, b], bins=bins, range=(0.0, 1.0))
        p = h / h.sum() if h.sum() > 0 else np.zeros_like(h, dtype=float)
        p = p[p > 0]
        ent[b] = float(-(p * np.log(p)).sum()) if p.size else 0.0
    return ent


def _class_mean_matrix(X: np.ndarray, labels: np.ndarray) -> np.ndarray:
    """B x n_classes matrix of per-class mean radiance for each band."""
    X = np.asarray(X, dtype=np.float64)
    labels = np.asarray(labels).ravel()
    classes = [int(c) for c in np.unique(labels) if c != 0]
    out = np.empty((X.shape[1], len(classes)))
    for j, c in enumerate(classes):
        out[:, j] = X[labels == c].mean(axis=0)
    return out


def _eigengap_clusters(feats: np.ndarray, k_max: int = 20) -> int:
    """Number of clusters from the largest eigengap of the unnormalised Laplacian."""
    from sklearn.metrics.pairwise import rbf_kernel
    # sklearn's rbf_kernel only accepts a float/None gamma; replicate the
    # 'scale' heuristic (gamma = 1 / (n_features * X.var())) manually.
    gamma = 1.0 / (feats.shape[1] * float(feats.var()) + 1e-12)
    A = rbf_kernel(feats, gamma=gamma)
    A = np.clip(A, 0.0, 1.0)
    Dm = np.diag(A.sum(axis=1))
    L = Dm - A
    w = np.sort(np.linalg.eigvalsh(L))
    k_max = min(k_max, w.size - 1)
    gaps = w[1:k_max + 1] - w[:k_max]
    return int(np.argmax(gaps) + 1) if k_max >= 1 else 1


def _greedy_diverse(X: np.ndarray, k: int, corr_w: float = 1.0,
                    rng: Optional[np.random.Generator] = None) -> List[int]:
    """Greedy sparse-representation + correlation-minimisation selection.

    At each step add the band that (a) best reduces the least-squares
    reconstruction error of *all* bands from the current subset and (b) is least
    correlated with the already-selected bands.
    """
    X = np.asarray(X, dtype=np.float64)
    Xn = (X - X.mean(axis=0, keepdims=True)) / (X.std(axis=0, keepdims=True) + 1e-12)
    B = Xn.shape[1]
    R = np.abs(np.corrcoef(Xn, rowvar=False))
    np.fill_diagonal(R, 0.0)
    first = int(np.argmax(Xn.var(axis=0))) if rng is None else int(rng.integers(B))
    sel = [first]
    while len(sel) < k:
        best, best_score = None, -np.inf
        for b in range(B):
            if b in sel:
                continue
            cand = sel + [b]
            try:
                coef, *_ = np.linalg.lstsq(Xn[:, cand], Xn, rcond=None)
                recon = Xn[:, cand] @ coef
                err = float(np.mean((Xn - recon) ** 2))
            except np.linalg.LinAlgError:
                err = np.inf
            corr_pen = corr_w * float(np.max(R[b, sel])) if sel else 0.0
            score = -err - corr_pen
            if score > best_score:
                best_score, best = score, b
        sel.append(int(best))
    return sorted(sel)


def _kmeans_pick(X: np.ndarray, score: np.ndarray, k: int,
                 seed: int = 1) -> List[int]:
    """Cluster band feature vectors into k groups, pick highest-``score`` per group."""
    from sklearn.cluster import KMeans
    X = np.asarray(X, dtype=np.float64)
    B = X.shape[1]
    if k >= B:
        return list(range(B))
    feats = np.column_stack([
        X.mean(axis=0), X.std(axis=0),
        np.percentile(X, 25, axis=0), np.percentile(X, 75, axis=0),
    ])
    km = KMeans(n_clusters=k, n_init=10, random_state=seed).fit(feats)
    out = []
    for c in range(k):
        idx = np.where(km.labels_ == c)[0]
        out.append(int(idx[int(np.argmax(score[idx]))]))
    return sorted(out)


def _lazy_torch():
    try:
        import torch
        return torch
    except Exception as exc:  # pragma: no cover
        raise RuntimeError(
            'CNN-GA requires PyTorch. Install it (pip install torch, CPU build is '
            'enough) to enable this method.') from exc


# ----------------------------------------------------------------- base class
class StaticSelector:
    """Base class for one-shot band selectors.

    Subclasses implement :meth:`select`. ``adaptive_k`` marks methods whose
    natural band count is data-driven; we still cut them to the requested ``k``
    so the comparison table stays aligned at k=4 (R1-2 design, main rule).
    """

    name: str = 'base'
    family: str = 'static'
    uses_labels: bool = False
    adaptive_k: bool = False
    ignore_k: bool = False
    """When True the selector returns its own band set regardless of the
    requested ``k`` (e.g. Full-band returns all bands); the k==len contract in
    ``select_bands`` is relaxed for it."""
    reference: str = ''

    def __init__(self, X: np.ndarray, labels: np.ndarray, k: int, seed: int = 1,
                 **params) -> None:
        self.X = np.asarray(X, dtype=np.float64)
        self.labels = np.asarray(labels).ravel()
        self.k = int(k)
        self.seed = int(seed)
        self.params = params
        self.n_bands = self.X.shape[1]
        self.nat_k: Optional[int] = None  # exposed for reporting

    def select(self) -> List[int]:
        raise NotImplementedError

    def self_score(self, bands: Sequence[int]) -> float:
        """Optional method-specific quality scalar for the band-selection table."""
        return float('nan')


# ----------------------------------------------------------------- II. subspace partitioning
class HCBS(StaticSelector):
    """Hierarchical Clustering Band Selection (Martinez-Usó et al., IEEE TGRS 2007).

    Builds a band-band dissimilarity from the class-conditional JM distance,
    agglomerates with average linkage, and returns the k cluster medoids.
    """
    name = 'HCBS'
    uses_labels = True
    reference = 'Martínez-Usó et al., IEEE TGRS 2007, 45(12):4158-4171'

    def select(self) -> List[int]:
        key = ('HCBS',) + _fp(self.X, self.labels, self.seed)
        D = _BAND_DIST_CACHE.get(key)
        if D is None:
            D = _jm_band_matrix(self.X, self.labels)
            _BAND_DIST_CACHE[key] = D
        return _hierarchical_cut(D, self.k)


class ASPS(StaticSelector):
    """Adaptive Subspace Partition Strategy (Wang, Li & Li, IEEE JSTARS 2019).

    Recursively partitions the band set by correlation structure; one
    representative per resulting subspace. Cut to the requested k for alignment.
    """
    name = 'ASPS'
    uses_labels = True
    adaptive_k = True
    reference = 'Wang, Li & Li, IEEE JSTARS 2019, 12(12):4940-4950'

    def select(self) -> List[int]:
        key = ('ASPS',) + _fp(self.X, self.labels, self.seed)
        D = _BAND_DIST_CACHE.get(key)
        if D is None:
            D = _jm_band_matrix(self.X, self.labels)
            _BAND_DIST_CACHE[key] = D
        groups = _recursive_partition(D, cut_frac=float(self.params.get('cut_frac', 0.5)))
        self.nat_k = len(groups)
        reps = [_medoid(D, g) for g in groups]
        # if natural count != requested k, fall back to hierarchical cut (alignment)
        if len(reps) != self.k:
            return _hierarchical_cut(D, self.k)
        return sorted(int(r) for r in reps)


class FNGBS(StaticSelector):
    """Fast Neighborhood Grouping Band Selection (Wang, Li & Li, IEEE TGRS 2021).

    Scores bands by local density (Gaussian affinity graph) x (1 - entropy),
    groups them via k-means on band features, keeps the top-scoring band per group.
    """
    name = 'FNGBS'
    uses_labels = False
    reference = 'Wang, Li & Li, IEEE TGRS 2021, 59(6):5028-5039'

    def select(self) -> List[int]:
        D = _corr_distance(self.X)
        dens = _local_density(D, eps=float(self.params.get('eps', 0.3)))
        ent = _band_entropy(self.X)
        norm = ent / (ent.max() + 1e-9)
        score = dens * (1.0 - norm)
        return _kmeans_pick(self.X, score, self.k, seed=self.seed)


# ----------------------------------------------------------------- III. representation learning
class BDRLA(StaticSelector):
    """Block Diagonal Representation Learning band selection (Li et al., IEEE TGRS 2023).

    Treats each band as a point in class-mean space, groups bands by spectral
    clustering (block structure), returns one medoid per block. Cut to k.
    """
    name = 'BDRLA'
    uses_labels = True
    adaptive_k = True
    reference = 'Li, Liu, Fang & Li, IEEE TGRS 2023, 61:1-13'

    def select(self) -> List[int]:
        feats = _class_mean_matrix(self.X, self.labels)
        k_nat = _eigengap_clusters(feats, k_max=int(self.params.get('k_max', 20)))
        self.nat_k = k_nat
        from sklearn.cluster import SpectralClustering
        n = feats.shape[0]
        nn = min(10, n - 1)
        model = SpectralClustering(
            n_clusters=min(self.k, n), affinity='nearest_neighbors', n_neighbors=max(2, nn),
            random_state=self.seed, assign_labels='discretize', n_init=10)
        lab = model.fit_predict(feats)
        D = _corr_distance(self.X)
        out = [_medoid(D, np.where(lab == c)[0]) for c in np.unique(lab)]
        if len(out) != self.k:
            return _hierarchical_cut(D, self.k)
        return sorted(int(x) for x in out)


class SCDBS(StaticSelector):
    """Spectral Correlation-Based Diverse Band Selection (Ma et al., IEEE TGRS 2023).

    Greedy selection maximising reconstruction of all bands from the subset while
    minimising mutual correlation (sparse representation + correlation penalty).
    """
    name = 'SCDBS'
    uses_labels = False
    reference = 'Ma, Mei, Li, Ge & Du, IEEE TGRS 2023, 61:1-13'

    def select(self) -> List[int]:
        rng = np.random.default_rng(self.seed)
        return _greedy_diverse(self.X, self.k,
                               corr_w=float(self.params.get('corr_w', 1.0)), rng=rng)


# ----------------------------------------------------------------- IV. supervised neural
class SNNBS(StaticSelector):
    """Supervised band selection via single-layer network weights
    (Habermann, Frémont & Shiguemori, Int. J. Remote Sens. 2019).

    Trains a per-class ridge classifier on the full band set; band importance is
    the summed absolute weight across classes. Selects the top-k bands.
    """
    name = 'SNN-BS'
    uses_labels = True
    reference = 'Habermann, Frémont & Shiguemori, IJRS 2019, 40(10):3900-3926'

    def select(self) -> List[int]:
        from sklearn.linear_model import RidgeClassifier
        y = self.labels
        mask = y != 0
        Xb, yb = self.X[mask], y[mask]
        if Xb.shape[0] < 2 or len(np.unique(yb)) < 2:
            return list(range(self.k))
        imp = np.zeros(self.X.shape[1])
        for c in np.unique(yb):
            yt = (yb == c).astype(int)
            clf = RidgeClassifier(alpha=float(self.params.get('alpha', 1.0)))
            clf.fit(Xb, yt)
            imp += np.abs(clf.coef_[0])
        return sorted(int(b) for b in np.argsort(imp)[::-1][:self.k])


class CNNGA(StaticSelector):
    """CNN-embedded GA band selection (Esmaeili et al., IEEE JSTARS 2023).

    A GA evolves binary k-band masks; each mask's fitness is the OA of a small
    1-D CNN trained/evaluated on a hold-out of the (subsampled) training pixels.
    Requires torch. Params: n_pop, n_gen, epochs, mut, max_samples (default 3000).
    """
    name = 'CNN-GA'
    uses_labels = True
    reference = 'Esmaeili et al., IEEE JSTARS 2023, 16:1927-1950'

    def select(self) -> List[int]:
        torch = _lazy_torch()
        rng = np.random.default_rng(self.seed)
        B = self.n_bands
        k = self.k
        n_pop = int(self.params.get('n_pop', 30))
        n_gen = int(self.params.get('n_gen', 20))
        epochs = int(self.params.get('epochs', 8))

        y = self.labels
        mask = y != 0
        Xb, yb = self.X[mask], y[mask] - 1  # 0-based classes
        # Cap the fitness-evaluation pool: training a CNN on the full (often
        # 10^5+) pixel set for every GA individual is intractable. Subsampling to
        # `max_samples` (default 3000) is the standard practice in GA-CNN band
        # selection and keeps each fitness call cheap while preserving class ratios.
        max_samples = int(self.params.get('max_samples', 3000))
        if Xb.shape[0] > max_samples:
            idx_all = np.arange(Xb.shape[0])
            rng.shuffle(idx_all)
            idx_all = idx_all[:max_samples]
            Xb, yb = Xb[idx_all], yb[idx_all]
        Xb = (Xb - Xb.mean(0, keepdims=True)) / (Xb.std(0, keepdims=True) + 1e-12)
        n_cls = int(yb.max()) + 1

        # internal train/val split for fitness evaluation
        idx = np.arange(Xb.shape[0])
        rng.shuffle(idx)
        n_val = max(1, int(0.2 * len(idx)))
        tr, va = idx[n_val:], idx[:n_val]
        Xtr = torch.tensor(Xb[tr], dtype=torch.float32)
        ytr = torch.tensor(yb[tr].astype(np.int64), dtype=torch.long)
        Xva = torch.tensor(Xb[va], dtype=torch.float32)
        yva = torch.tensor(yb[va].astype(np.int64), dtype=torch.long)

        def make_cnn(bands_len: int):
            return torch.nn.Sequential(
                torch.nn.Conv1d(1, 16, kernel_size=3, padding=1),
                torch.nn.ReLU(),
                torch.nn.AdaptiveAvgPool1d(1),
                torch.nn.Flatten(),
                torch.nn.Linear(16, n_cls),
            )

        def fitness(mask_vec: np.ndarray) -> float:
            bands = np.where(mask_vec)[0]
            if bands.size != k:
                return -1.0
            net = make_cnn(len(bands))
            opt = torch.optim.Adam(net.parameters(), lr=1e-3)
            ce = torch.nn.CrossEntropyLoss()
            xt = Xtr[:, bands].unsqueeze(1)  # (N, 1, k): 1 channel, spectral length k
            xv = Xva[:, bands].unsqueeze(1)
            for _ in range(epochs):
                net.train()
                opt.zero_grad()
                loss = ce(net(xt), ytr)
                loss.backward()
                opt.step()
            net.eval()
            with torch.no_grad():
                pred = net(xv).argmax(1)
                oa = (pred == yva).float().mean().item()
            return oa

        # initial population: random k-subsets
        pop = np.zeros((n_pop, B), dtype=bool)
        for i in range(n_pop):
            sel = rng.choice(B, size=k, replace=False)
            pop[i, sel] = True

        best_vec, best_fit = pop[0].copy(), -1.0
        for gen in range(n_gen):
            fits = np.array([fitness(p) for p in pop])
            order = np.argsort(fits)[::-1]
            if fits[order[0]] > best_fit:
                best_fit, best_vec = fits[order[0]], pop[order[0]].copy()
            # elitism + tournament crossover + mutation
            newpop = np.zeros_like(pop)
            newpop[0] = best_vec
            for i in range(1, n_pop):
                a, b = rng.integers(n_pop), rng.integers(n_pop)
                pa, pb = pop[order[a]], pop[order[b]]
                child = pa & pb
                # repair to exactly k ones
                if child.sum() < k:
                    missing = np.where(~child)[0]
                    add = rng.choice(missing, size=k - int(child.sum()), replace=False)
                    child[add] = True
                elif child.sum() > k:
                    extra = np.where(child)[0]
                    rem = rng.choice(extra, size=int(child.sum()) - k, replace=False)
                    child[rem] = False
                if rng.random() < float(self.params.get('mut', 0.1)):
                    flip = rng.integers(B)
                    child[flip] = not child[flip]
                    if child.sum() != k:  # repair after flip
                        if child.sum() > k:
                            rem = np.where(child)[0]
                            child[rng.choice(rem)] = False
                        else:
                            add = np.where(~child)[0]
                            child[rng.choice(add)] = True
                newpop[i] = child
            pop = newpop
        return sorted(int(b) for b in np.where(best_vec)[0])


# ----------------------------------------------------------------- V. classic / baseline selectors (M-P1-7)
class SFS(StaticSelector):
    """Sequential Forward Selection by class-conditional JM (supervised).

    Starts from the single band with the largest summed pairwise JM, then greedily
    adds the band that maximises the JM summed over all pairs inside the growing
    subset. This is the classic *greedy* band-selection baseline the reviewers
    asked for ("比经典贪心强多少"), reconstructed from the standard SFS recipe.
    """

    name = 'SFS'
    uses_labels = True
    reference = 'Sequential Forward Selection, e.g. Serpico & Bruzzone, IEEE TGRS 2001'

    def select(self) -> List[int]:
        D = _jm_band_matrix(self.X, self.labels)
        B = D.shape[0]
        if B <= self.k:
            return list(range(B))
        rowsum = D.sum(axis=1)
        sel = [int(np.argmax(rowsum))]
        avail = set(range(B)) - set(sel)
        while len(sel) < self.k:
            best, best_score = None, -np.inf
            for b in avail:
                score = float(sum(D[b, s] for s in sel) + D[b, b])  # additive JM gain
                if score > best_score:
                    best_score, best = score, b
            sel.append(best)
            avail.discard(best)
        return sorted(sel)


class RANDOM(StaticSelector):
    """Purely random k-band baseline (unsupervised, spectral-only).

    Draws one random k-subset per seed. Averaging over the shared 10 seeds in the
    runner gives the method's OA distribution, which is exactly the *lower bound*
    the reviewers asked to compare against ("比谱-only强多少"). Deterministic
    given the seed, NFE-free.
    """

    name = 'RANDOM'
    uses_labels = False
    reference = 'random k-band baseline (this work, for M-P1-7)',

    def select(self) -> List[int]:
        B = self.n_bands
        if B <= self.k:
            return list(range(B))
        rng = np.random.default_rng(self.seed)
        sel = sorted(int(x) for x in rng.choice(B, size=self.k, replace=False))
        return sel


# ----------------------------------------------------------------- registry
REGISTRY: Dict[str, Type[StaticSelector]] = {
    'HCBS': HCBS, 'ASPS': ASPS, 'FNGBS': FNGBS, 'BDRLA': BDRLA,
    'SCDBS': SCDBS, 'SNN-BS': SNNBS, 'CNN-GA': CNNGA,
}


# ----------------------------------------------------------------- reference / control methods for R1-2 contribution (ii)
class FullBand(StaticSelector):
    """Upper-bound reference: classify on ALL ``n_bands`` bands (no selection).

    ``ignore_k`` is set so the pipeline can feed it the usual k=4 plan row while
    the selector still returns the full band set -- the classification layer then
    evaluates every band, which is exactly the "no down-sampling" ceiling the
    comparison tables need. Deterministic and NFE-free (STATIC cache key).
    """

    name = 'FULLBAND'
    uses_labels = False
    ignore_k = True
    reference = 'all bands (zero-cost upper-bound reference, R1-2)'

    def select(self) -> List[int]:
        return list(range(self.n_bands))


class SubspaceDiv(StaticSelector):
    """External subspace-division control for contribution (ii).

    Reconstructs the Ye et al. [39] style *external* constraint: partition the
    band set by the correlation-distance dendrogram into subspaces, then enforce a
    per-subspace dimension constraint by keeping one representative (medoid) per
    subspace. The natural subspace count is data-driven (adaptive_k); if it
    differs from the requested k we fall back to the hierarchical cut so the
    comparison table stays aligned at k=4. This is the *control* that contrasts
    the internal redundancy-penalty mechanism (JMRED) in the contribution-(ii)
    narrative.
    """

    name = 'SUBSPACEDIV'
    uses_labels = False
    adaptive_k = True
    reference = 'Ye et al. [39] external subspace-division constraint (reconstructed)'

    def select(self) -> List[int]:
        D = _corr_distance(self.X)
        groups = _recursive_partition(D, cut_frac=float(self.params.get('cut_frac', 0.5)))
        self.nat_k = len(groups)
        reps = [_medoid(D, g) for g in groups]
        if len(reps) != self.k:
            return _hierarchical_cut(D, self.k)
        return sorted(int(r) for r in reps)


REGISTRY['FULLBAND'] = FullBand
REGISTRY['SUBSPACEDIV'] = SubspaceDiv
REGISTRY['SFS'] = SFS
REGISTRY['RANDOM'] = RANDOM


def list_static() -> List[str]:
    return sorted(REGISTRY)


def select_bands(method: str, X: np.ndarray, labels: np.ndarray, k: int,
                 seed: int = 1, **params) -> List[int]:
    """Instantiate ``method`` and return its selected 0-based band indices."""
    key = method.upper()
    if key not in REGISTRY:
        raise KeyError('unknown static selector %r; available: %s' % (method, ', '.join(list_static())))
    sel = REGISTRY[key](X, labels, k, seed=seed, **params)
    bands = sel.select()
    # validate contract: exactly k, ascending, unique, in range
    bands = sorted(int(b) for b in bands)
    assert len(bands) == len(set(bands)), '%s returned duplicate bands' % method
    assert all(0 <= b < X.shape[1] for b in bands), '%s returned out-of-range band' % method
    if not getattr(sel, 'ignore_k', False):
        assert len(bands) == k, '%s returned %d bands, expected %d' % (method, len(bands), k)
    return bands
