"""Robust, resume-capable band-selection pipeline.

Why this exists
---------------
A single `python -m hsbs.runner --config X` call runs the whole grid as one
process. If the session is compressed mid-run the process is killed and we are
left guessing how far it got. This wrapper makes the run *provably* resumable
and observable:

  * Subtask split : one band-selection *method* per subtask. Every subtask
    appends into the SAME shared JsonlCache (selection.jsonl /
    classification.jsonl). The runner is fully resume-capable, so re-running a
    subtask only fills the rows that are still missing -- nothing is recomputed.

  * Verification  : after each subtask we count the rows written for that method
    directly from disk and compare against the planned job count. On mismatch
    the subtask is retried (resume fills the gap). This catches the silent
    failures that a plain run would hide.

  * Intermediate save : every batch is checkpointed by the runner, and this
    wrapper additionally persists `run_manifest.json` (per-method status) and
    `progress.json` (cumulative %) to disk on every step, so a kill leaves a
    complete, inspectable state.

  * Live progress : a callback streams progress to `progress.json` after every
    batch and emits a [PROGRESS] line each time completion crosses a 10%
    boundary, so the run is observable even mid-method.

Resuming
--------
Just re-run the identical command. The manifest is read back, already-`done`
methods are skipped, in-flight methods are re-run (resume skips their cached
rows), and progress continues from where it stopped. A compression kill is
therefore a non-event: re-launch and it finishes.

Usage
-----
  python run_pipeline.py --config configs/indian_pines.json \
      --out ../output/runs/indian_pines \
      --methods ASPS,FNGBS,HCBS,BDRLA,SCDBS,SNN-BS,CNN-GA
"""
from __future__ import annotations

import argparse
import copy
import json
import os
import sys
import time
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from hsbs import runner  # noqa: E402

# 压缩前自动落盘任务检查点（PROGRESS.md）：随每 10% 进度边界与每方法核验成功刷新，
# 使会话压缩前的最后一次状态必然已持久化，新会话可回读续跑、全程可复核。
try:
    from checkpoint import write_checkpoint
    _HAVE_CHECKPOINT = True
except Exception:  # checkpoint 缺失不应拖垮流水线
    _HAVE_CHECKPOINT = False
    def write_checkpoint():
        return None


def _checkpoint():
    if _HAVE_CHECKPOINT:
        try:
            write_checkpoint()
        except Exception:
            pass


__all__ = ['main']


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _expected_counts(scfg, n_seeds: int):
    """Planned selection/classification job counts for ONE method, mirroring the
    exact loop in hsbs.runner.run_experiment."""
    ks = ([scfg.k_main] if scfg.k_main else []) + [k for k in scfg.k_sweep if k != scfg.k_main]
    sel = len(ks) * n_seeds
    cv = max(1, int(getattr(scfg, 'cv_folds', 1)))
    clf = 0
    for k in ks:
        if k == scfg.k_main:
            n = len(scfg.classifiers)
        else:
            n = len(scfg.classifiers) + len(scfg.sweep_classifiers)
        clf += n
    cls = clf * n_seeds * cv
    return sel, cls


def _count(path: str, method: str) -> int:
    """Count successful (non-error) rows for `method` in a JSONL cache."""
    n = 0
    if not os.path.isfile(path):
        return 0
    with open(path, 'r', encoding='utf-8') as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except json.JSONDecodeError:
                continue  # tolerate a half-written trailing line after a kill
            if r.get('method') != method:
                continue
            if 'error' in r:
                continue
            n += 1
    return n


def _sub_scfg(scfg, method: str):
    sub = copy.deepcopy(scfg)
    sub.methods = [method]
    return sub


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog='python run_pipeline.py',
        description='Robust, resume-capable, per-method band-selection pipeline.')
    ap.add_argument('--config', required=True)
    ap.add_argument('--out', default=None, help='override output directory (use an absolute path)')
    ap.add_argument('--methods', default=None, help='comma list; default = all methods in config')
    ap.add_argument('--n-jobs', type=int, default=None)
    ap.add_argument('--k-main', type=int, default=None)
    ap.add_argument('--max-retries', type=int, default=2)
    ap.add_argument('--dry-run', action='store_true')
    ap.add_argument('--quiet', action='store_true')
    a = ap.parse_args(argv)

    raw_cfg = runner.load_config(a.config)
    ds, splits, scfg, out_dir, n_jobs = runner.build_context(
        raw_cfg, out_dir=a.out, methods=a.methods, k_main=a.k_main, verbose=not a.quiet)
    # run_experiment() also makedirs(out_dir), but we persist run_manifest.json /
    # progress.json BEFORE the first run_experiment call, so the dir must exist now.
    os.makedirs(out_dir, exist_ok=True)
    if a.n_jobs is not None:
        n_jobs = a.n_jobs

    # Execution list = what THIS process runs (filtered by --methods).
    # Tracking list  = the FULL canonical method set for this dataset (what the
    # experiment needs to be "complete"). build_context already filtered
    # scfg.methods by --methods, so the canonical list is read from raw_cfg.
    # progress.json / run_manifest.json always report the FULL set, so a
    # partial launch (e.g. only 3 methods) still shows the true overall % and
    # lets the watchdog/automation trust completion detection.
    run_methods = list(scfg.methods)
    all_methods = list(raw_cfg['selection']['methods'])
    n_seeds = len(splits)
    sel_path = os.path.join(out_dir, 'selection.jsonl')
    cls_path = os.path.join(out_dir, 'classification.jsonl')
    man_path = os.path.join(out_dir, 'run_manifest.json')
    prog_path = os.path.join(out_dir, 'progress.json')

    # Expected job counts are dataset-level (identical per method), so scfg is fine.
    exp = {m: dict(zip(('sel', 'cls'), _expected_counts(scfg, n_seeds))) for m in all_methods}
    total_jobs = sum(v['sel'] + v['cls'] for v in exp.values())

    # Re-derive per-method status directly from the on-disk cache so the manifest
    # is self-healing: it no longer depends on whatever a prior (possibly partial)
    # launch wrote. This is what makes the run auditable and lets the
    # watchdog/automation trust progress.json + run_manifest.json.
    mstatus = {}
    mver = {}
    for m in all_methods:
        s_act = _count(sel_path, m)
        c_act = _count(cls_path, m)
        mver[m] = {'sel': s_act, 'cls': c_act}
        mstatus[m] = 'done' if (s_act >= exp[m]['sel'] and c_act >= exp[m]['cls']) else 'pending'
    manifest = {'status': mstatus, 'verified': mver}

    def _verified_ok(m):
        return (mstatus.get(m) == 'done'
                and mver.get(m, {}).get('sel') == exp[m]['sel']
                and mver.get(m, {}).get('cls') == exp[m]['cls'])

    done_methods = [m for m in all_methods if _verified_ok(m)]
    completed_jobs = sum(exp[m]['sel'] + exp[m]['cls'] for m in done_methods)

    def write_manifest():
        manifest['config'] = os.path.abspath(a.config)
        manifest['out_dir'] = out_dir
        manifest['subtasks'] = all_methods
        manifest['expected'] = exp
        manifest['status'] = mstatus
        manifest['verified'] = mver
        manifest['updated_at'] = _now()
        if 'started_at' not in manifest:
            manifest['started_at'] = _now()
        with open(man_path, 'w', encoding='utf-8') as fh:
            json.dump(manifest, fh, ensure_ascii=False, indent=2)

    def write_progress(running=None, live=None):
        if live is None:
            live = completed_jobs
        pct = (live / total_jobs * 100.0) if total_jobs else 100.0
        prog = {'percent': round(pct, 1), 'completed_jobs': live,
                'total_jobs': total_jobs, 'done_methods': done_methods,
                'running_method': running, 'updated_at': _now()}
        with open(prog_path, 'w', encoding='utf-8') as fh:
            json.dump(prog, fh, ensure_ascii=False, indent=2)
        return pct

    # ---- live progress callback (streams after every batch) -----------------
    cb = {'cur': None, 'sel': 0, 'cls': 0, 'last_decile': int(completed_jobs / total_jobs * 10) if total_jobs else 10}

    def _on_batch(phase, done, total):
        m = cb['cur']
        if m is None:
            return
        if phase == 'selection':
            cb['sel'] = min(done, exp[m]['sel'])
        else:  # classification (and any other phase tag)
            cb['cls'] = min(done, exp[m]['cls'])
        live = completed_jobs + cb['sel'] + cb['cls']
        pct = (live / total_jobs * 100.0) if total_jobs else 100.0
        write_progress(running=m, live=live)
        d = int(pct // 10)
        while cb['last_decile'] < d:
            cb['last_decile'] += 1
            if cb['last_decile'] <= 10:
                print('[PROGRESS] %2d%%  (%d/%d methods, %d/%d jobs)'
                      % (cb['last_decile'] * 10, len(done_methods), len(all_methods), live, total_jobs),
                      flush=True)
                _checkpoint()  # 压缩前自动落盘检查点

    if a.dry_run:
        print('run_methods :', ', '.join(run_methods))
        for m in run_methods:
            print('  %-10s sel=%-4d cls=%-5d  %s'
                  % (m, exp[m]['sel'], exp[m]['cls'],
                     'skip(verified)' if _verified_ok(m) else 'run'))
        print('total_jobs =', total_jobs, ' n_seeds =', n_seeds)
        return 0

    print('[pipeline] config   = %s' % a.config, flush=True)
    print('[pipeline] out      = %s' % out_dir, flush=True)
    print('[pipeline] run_methods = %s' % ', '.join(run_methods), flush=True)
    print('[pipeline] tracking    = %d methods (full dataset, includes already-cached)' % len(all_methods), flush=True)
    print('[pipeline] total_jobs=%d  n_seeds=%d  n_jobs=%d' % (total_jobs, n_seeds, n_jobs), flush=True)
    write_manifest()
    write_progress(None)

    for m in run_methods:
        if _verified_ok(m):
            print('[skip] %s already verified (sel=%d cls=%d)'
                  % (m, exp[m]['sel'], exp[m]['cls']), flush=True)
            continue
        ok = False
        retries = 0
        while retries <= a.max_retries and not ok:
            mstatus[m] = 'running'
            cb['cur'] = m
            cb['sel'] = 0
            cb['cls'] = 0
            write_manifest()
            write_progress(m)
            print('[run] %s (attempt %d/%d)' % (m, retries + 1, a.max_retries + 1), flush=True)
            t0 = time.perf_counter()
            try:
                runner.run_experiment(ds, splits, _sub_scfg(scfg, m), out_dir,
                                      n_jobs=n_jobs, resume=True,
                                      verbose=not a.quiet, do_classify=True,
                                      progress_cb=_on_batch)
            except Exception as exc:  # never let one method abort the pipeline
                import traceback as _tb
                print('[run-error] %s: %s' % (m, exc), flush=True)
                _tb.print_exc()
            rt = time.perf_counter() - t0
            s_act = _count(sel_path, m)
            c_act = _count(cls_path, m)
            print('[verify] %s sel=%d/%d cls=%d/%d (%.1fs)'
                  % (m, s_act, exp[m]['sel'], c_act, exp[m]['cls'], rt), flush=True)
            if s_act >= exp[m]['sel'] and c_act >= exp[m]['cls']:
                ok = True
                mstatus[m] = 'done'
                mver[m] = {'sel': s_act, 'cls': c_act}
                if m not in done_methods:
                    done_methods.append(m)
                    completed_jobs += exp[m]['sel'] + exp[m]['cls']
                cb['sel'] = exp[m]['sel']
                cb['cls'] = exp[m]['cls']
                write_manifest()
                write_progress(None)
                _checkpoint()  # 方法核验成功即落盘一次检查点
            else:
                retries += 1
                mstatus[m] = 'verify_retry' if retries <= a.max_retries else 'error'
                write_manifest()
                print('[retry] %s missing rows; resuming (attempt %d)' % (m, retries + 1), flush=True)
        if not ok:
            print('[FAIL] %s incomplete after %d retries -- check run_pipeline.log' % (m, a.max_retries), flush=True)

    pct = write_progress(None)
    d = int(pct // 10)
    while cb['last_decile'] < d:
        cb['last_decile'] += 1
        if cb['last_decile'] <= 10:
            print('[PROGRESS] %2d%%' % (cb['last_decile'] * 10), flush=True)
    _checkpoint()  # 整轮结束再落盘一次
    n_done = len([m for m in all_methods if mstatus.get(m) == 'done'])
    n_err = len([m for m in all_methods if mstatus.get(m) == 'error'])
    print('[pipeline] DONE. %d/%d methods verified, errors=%d, percent=%.1f%%'
          % (n_done, len(all_methods), n_err, pct), flush=True)
    print('[pipeline] progress : %s' % prog_path, flush=True)
    print('[pipeline] manifest : %s' % man_path, flush=True)
    # Non-zero exit when the dataset is not fully verified: downstream automation
    # gates the aggregate/fill step on this, so a partial run must not silently
    # look like success.
    return 0 if (n_done == len(all_methods) and n_err == 0) else 1


if __name__ == '__main__':
    raise SystemExit(main())
