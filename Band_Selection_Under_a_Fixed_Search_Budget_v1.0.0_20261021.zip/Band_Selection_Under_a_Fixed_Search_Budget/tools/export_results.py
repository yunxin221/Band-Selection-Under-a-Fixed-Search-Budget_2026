#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
export_results.py -- turn the raw run caches into the small, citable result
files that ship with the release (results/).

The run caches under output/runs/ are large (hundreds of MB) and are NOT part
of the release.  What is released is the derived, machine-readable evidence for
every number in the paper:

    results/
      selection_<scene>.csv          per-method, per-seed selected bands + budget use
      classification_<scene>.csv     per-method, per-seed, per-classifier metrics
      hybridsn/<run>/...             HybridSN deep summaries (Table 12 source)
      statistics/                    Friedman / Nemenyi artefacts
      results_index.json             one-line description of every file above

Usage
-----
    python tools/export_results.py                 # uses the default paths
    python tools/export_results.py --runs <dir> --out <dir>

The script is read-only with respect to the run caches: it never writes back.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path

# Default workspace layout (mirrors README section 3 / 6).
HERE = Path(__file__).resolve().parent
PKG = HERE.parent
DEFAULT_RUNS = PKG.parent.parent / "output" / "runs"
DEFAULT_OUT = PKG / "results"

SCENES = {
    "longkou_5cls": "WHU-Hi-LongKou",
    "indian_pines": "Indian Pines",
}

# Columns kept in the released CSVs.  The run caches carry more (per-class
# vectors, full JM history); releasing those would ship megabytes of
# intermediate state that no reader needs.
SEL_COLS = [
    "scene", "method", "k", "seed", "bands_1based", "objective",
    "jm_mean", "mean_abs_corr", "max_abs_corr", "nfe", "runtime_s",
]
CLS_COLS = [
    "scene", "method", "k", "seed", "classifier",
    "OA", "AA", "Kappa", "macro_F1", "n_test",
]


def _read_jsonl(path: Path):
    with path.open(encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                # A cache interrupted mid-write leaves a truncated tail line.
                # Skip it: --resume regenerates the record on the next run.
                continue


def _write_csv(path: Path, cols, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


def export_selection(runs: Path, out: Path, index: list):
    for run_dir, scene in SCENES.items():
        src = runs / run_dir / "selection.jsonl"
        if not src.exists():
            print(f"  [skip] {src.name} not found under {run_dir}")
            continue
        rows = []
        for d in _read_jsonl(src):
            d = dict(d)
            d["scene"] = scene
            rows.append(d)
        rows.sort(key=lambda r: (r.get("method", ""), r.get("k", 0), r.get("seed", 0)))
        dst = out / f"selection_{scene.replace(' ', '_').replace('-', '_')}.csv"
        _write_csv(dst, SEL_COLS, rows)
        index.append({
            "file": dst.relative_to(out).as_posix(),
            "content": f"Selected band indices per method / seed on {scene}, with the "
                       f"objective value, mean inter-band |correlation| and the number "
                       f"of objective evaluations actually consumed (budget cap 3000).",
            "n_rows": len(rows),
        })
        print(f"  [ok] {dst.name}  ({len(rows)} rows)")


def export_classification(runs: Path, out: Path, index: list):
    for run_dir, scene in SCENES.items():
        src = runs / run_dir / "classification.jsonl"
        if not src.exists():
            print(f"  [skip] {src.name} not found under {run_dir}")
            continue
        rows = []
        for d in _read_jsonl(src):
            d = dict(d)
            d["scene"] = scene
            rows.append(d)
        rows.sort(key=lambda r: (r.get("method", ""), r.get("classifier", ""),
                                 r.get("k", 0), r.get("seed", 0)))
        dst = out / f"classification_{scene.replace(' ', '_').replace('-', '_')}.csv"
        _write_csv(dst, CLS_COLS, rows)
        index.append({
            "file": dst.relative_to(out).as_posix(),
            "content": f"OA / AA / Kappa / macro-F1 per method, classifier and seed on "
                       f"{scene}. Underlies Tables 2, 3 and A2.",
            "n_rows": len(rows),
        })
        print(f"  [ok] {dst.name}  ({len(rows)} rows)")


# Only the runs the manuscript was actually written from are released.  The
# workspace also contains smoke tests and 3-seed pilots, which are excluded:
# shipping them would let a reader cite a table against the wrong run.
RELEASED_HYBRIDSN_RUNS = {
    # Final five-arm runs (full / full-tr / sel4 / pca4 / pca4-tr), 10 seeds.
    "t94_m8c_longkou_block",
    "t94_m8c_indian_block",
    # Random-split counterparts, 5 seeds (OA saturates >99.8% under this split,
    # so additional seeds add no information -- see Table 12 caption).
    "t94_m8c_longkou_random",
    "t94_m8c_indian_random",
    # Leak-free control of Section 4.7 (fifth methodological point): the band
    # search is redone with the JM statistics restricted to the training blocks
    # of each split, and HybridSN is retrained on the resulting subsets.
    "t105_tb_hybridsn",
    # Pre-control three-arm runs kept for lineage: they are what the first
    # submission compared, before the PCA-fitting asymmetry was isolated.
    "t10_deep_longkou_disjoint10",
    "t10_deep_indian_disjoint10",
    "t10_deep_longkou_random10",
    "t10_deep_indian_random10",
}

# Directories that are never released, whatever they contain.
NEVER_RELEASED_PREFIXES = ("_smoke", "smoke", "_val", "_fixcheck", "t94_smoke")


def _is_released_hybridsn_run(name: str) -> bool:
    if name.startswith(NEVER_RELEASED_PREFIXES):
        return False
    return name in RELEASED_HYBRIDSN_RUNS


def export_hybridsn(runs: Path, out: Path, index: list):
    """Copy the HybridSN deep summaries (Table 12) verbatim.

    These are the primary evidence for Section 4.7: the five-arm comparison
    full / full-tr / sel4 / pca4 / pca4-tr under random and spatially disjoint
    splits.  They are copied rather than re-derived so that the released file
    is byte-identical to what the manuscript was written from.
    """
    dst_root = out / "hybridsn"
    n = 0
    for src in sorted(runs.glob("**/t10_deep_summary.json")):
        rel_parent = src.parent.name
        if not _is_released_hybridsn_run(rel_parent):
            print(f"  [skip] hybridsn/{rel_parent} (smoke or pilot run)")
            continue
        dst_dir = dst_root / rel_parent
        dst_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst_dir / src.name)
        try:
            d = json.loads(src.read_text(encoding="utf-8"))
            n_runs = len(d.get("runs", []))
        except Exception:
            n_runs = -1
        index.append({
            "file": (dst_dir / src.name).relative_to(out).as_posix(),
            "content": f"HybridSN five-arm run ({rel_parent}): per-seed OA / AA / Kappa "
                       f"for full, full-tr, sel4, pca4 and pca4-tr.",
            "n_runs": n_runs,
        })
        n += 1
        print(f"  [ok] hybridsn/{rel_parent}/t10_deep_summary.json  ({n_runs} arms)")
    if n == 0:
        print("  [skip] no t10_deep_summary.json found")


def export_trainblock_control(runs: Path, out: Path, index: list):
    """The leak-free band-selection control of Section 4.7.

    The main tables select bands from a 20% draw of labelled pixels taken over
    the whole scene, so under the spatially disjoint split that draw contains
    test pixels.  This run closes that: the search is redone with the JM
    statistics restricted to the training blocks, and HybridSN is retrained on
    the resulting subsets (run_trainblock_selection.py, run_hybridsn.py
    --bands-method SAPSO-TB).  Both the selected subsets and the paired
    statistics against the leaked run are released so the claim can be checked.
    """
    dst = out / "hybridsn" / "longkou_trainblock_control"
    dst.mkdir(parents=True, exist_ok=True)
    src_sel = runs / "longkou_tbselection" / "selection.jsonl"
    if src_sel.exists():
        shutil.copy2(src_sel, dst / "selection.jsonl")
        index.append({
            "file": (dst / "selection.jsonl").relative_to(out).as_posix(),
            "content": "Leak-free band selection on WHU-Hi-LongKou (SAPSO-TB, k=4): the "
                       "four bands chosen per seed when the JM statistics are restricted "
                       "to the training blocks of each disjoint split.",
            "n_runs": sum(1 for _ in src_sel.open(encoding="utf-8") if _.strip()),
        })
        print("  [ok] hybridsn/longkou_trainblock_control/selection.jsonl")
    else:
        print("  [skip] longkou_tbselection/selection.jsonl not found")
    src_sum = runs / "longkou_tbselection" / "tb_selection_summary.json"
    if src_sum.exists():
        shutil.copy2(src_sum, dst / "tb_selection_summary.json")
        index.append({
            "file": (dst / "tb_selection_summary.json").relative_to(out).as_posix(),
            "content": "Per-seed comparison of the leak-free subsets against the leaked "
                       "ones: number of seeds returning an identical four-band subset.",
        })
        print("  [ok] hybridsn/longkou_trainblock_control/tb_selection_summary.json")
    stats = runs / "t105_tb_hybridsn" / "t109_tb_stats.json"
    if stats.exists():
        d2 = dst.parent.parent / "statistics"
        d2.mkdir(parents=True, exist_ok=True)
        shutil.copy2(stats, d2 / "longkou_trainblock_sel4_vs_fulltr.json")
        index.append({
            "file": "statistics/longkou_trainblock_sel4_vs_fulltr.json",
            "content": "Paired statistics (ddof=1, Wilcoxon signed-rank) for the "
                       "leak-free control: sel4 - fulltr, sel4 - full and sel4 - pca4tr "
                       "on WHU-Hi-LongKou under the spatially disjoint split.",
        })
        print("  [ok] statistics/longkou_trainblock_sel4_vs_fulltr.json")


def export_statistics(runs: Path, out: Path, index: list):
    """Friedman / Nemenyi artefacts, plus the sensitivity to tie handling."""
    dst = out / "statistics"
    dst.mkdir(parents=True, exist_ok=True)
    for run_dir in ("longkou_5cls", "indian_pines"):
        for name in ("friedman.json", "table_significance.md"):
            src = runs / run_dir / "tables" / name
            if not src.exists():
                continue
            shutil.copy2(src, dst / f"{run_dir}_{name}")
            index.append({
                "file": f"statistics/{run_dir}_{name}",
                "content": f"Friedman test and Nemenyi critical difference for {run_dir} "
                           f"(Section 4.5).",
            })
            print(f"  [ok] statistics/{run_dir}_{name}")


def sha256_of(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            b = fh.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def export_data_provenance(runs: Path, out: Path, index: list):
    """Record what the run caches were computed from.

    The cubes themselves are not redistributable (see data/README.md), so the
    release carries their SHA-256 instead: a reader who downloads the same
    files can prove they hold the same bytes.
    """
    raw = PKG.parent.parent / "data" / "raw"
    if not raw.exists():
        print("  [skip] data/raw not present")
        return
    entries = []
    for p in sorted(raw.glob("*.mat")):
        entries.append({
            "file": p.name,
            "size_bytes": p.stat().st_size,
            "sha256": sha256_of(p),
        })
        print(f"  [ok] sha256 {p.name}")
    if not entries:
        return
    dst = out / "data_provenance.json"
    dst.write_text(json.dumps({
        "note": "SHA-256 of the third-party cubes the released results were computed "
                "from. The cubes are not redistributed here; see data/README.md for "
                "how to obtain them. Matching hashes establish that the released "
                "numbers and a reader's re-run refer to the same input bytes.",
        "files": entries,
    }, indent=2, ensure_ascii=False), encoding="utf-8")
    index.append({
        "file": "data_provenance.json",
        "content": "SHA-256 of the WHU-Hi-LongKou and Indian Pines cubes used to produce "
                   "every released number.",
        "n_files": len(entries),
    })


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--runs", type=Path, default=DEFAULT_RUNS,
                    help="directory holding the run caches (default: %(default)s)")
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT,
                    help="destination results/ directory (default: %(default)s)")
    args = ap.parse_args(argv)

    runs, out = args.runs, args.out
    if not runs.exists():
        print(f"error: run cache directory not found: {runs}", file=sys.stderr)
        return 2
    out.mkdir(parents=True, exist_ok=True)

    index: list = []
    print("Exporting released results ->", out)
    export_selection(runs, out, index)
    export_classification(runs, out, index)
    export_hybridsn(runs, out, index)
    export_trainblock_control(runs, out, index)
    export_statistics(runs, out, index)
    export_data_provenance(runs, out, index)

    (out / "results_index.json").write_text(
        json.dumps({
            "generated_by": "tools/export_results.py",
            "description": "Machine-readable evidence for every number reported in "
                           "'Band Selection Under a Fixed Search Budget'.",
            "files": index,
        }, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\nWrote {len(index)} result artefacts + results_index.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
