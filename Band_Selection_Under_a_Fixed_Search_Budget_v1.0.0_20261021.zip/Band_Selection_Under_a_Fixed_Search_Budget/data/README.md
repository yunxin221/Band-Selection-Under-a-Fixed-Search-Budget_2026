# Data

## What is here

| Path | What it is |
|---|---|
| `meta/longkou_wavelengths_270.{csv,json}` | WHU-Hi-LongKou band-centre wavelengths (270 ch) |
| `meta/indian_pines_wavelengths_200.{csv,json}` | Indian Pines band-centre wavelengths (200 ch) |
| `meta/selected_bands_wavelengths.csv` | wavelengths of the bands the search actually selected |
| `meta/WHU-Hi-LongKou.hdr` | official ENVI header the LongKou wavelengths were read from |
| `meta/AVIRIS_1992_220ch_calibration.txt` | AVIRIS-1992 calibration the Indian Pines wavelengths were read from |
| `dataset_manifest.json` | scene shapes, class counts, per-scene fingerprints |

The wavelength tables are **not** shipped with either public dataset; they are
reconstructed here from official sensor documentation by `tools/extract_wavelengths.py`
and verified by `tools/verify_wavelengths.py`. They are therefore our derived
data and are released under the same MIT licence as the code.

## What is NOT here, and why

The two hyperspectral cubes (~184 MB) are third-party and are not redistributed:

* **WHU-Hi-LongKou** — RSIDEA group, Wuhan University,
  <http://rsidea.whu.edu.cn/resource_WHUHi_sharing.htm>
* **Indian Pines** — Purdue University Research Repository,
  <doi:10.4231/R7RX991C> (AVIRIS 1992)

Download them and place them at:

```
data/raw/WHU_Hi_LongKou.mat
data/raw/WHU_Hi_LongKou_gt.mat
data/raw/Indian_pines_corrected.mat
data/raw/Indian_pines_gt.mat
```

then run `python prep_dataset.py` to verify them.

`results/data_provenance.json` in the parent directory records the SHA-256 of the
exact four files every released number was computed from, so you can confirm you
hold the same bytes before comparing against `results/`.
