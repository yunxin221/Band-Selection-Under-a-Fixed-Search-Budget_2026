# Release notes

**Archive** — `Band_Selection_Under_a_Fixed_Search_Budget_v1.0.0_20261021.zip`
**Article** — Band Selection Under a Fixed Search Budget: A Reproducible Spatial-Spectral Framework for On-Board Hyperspectral Classification
**Version** — v1.0.0 · built 2026-10-21

## Contents

| Path | Contents |
|---|---|
| `hsbs/` | core library: criteria (JM, JMRED), optimisers, static selectors, spatial operators, classifiers, splits, HybridSN |
| `configs/` | 16 experiment configurations (JSON) — datasets, budget, k, seeds, spatial specs |
| `tools/` | wavelength traceability, result export, archive builder |
| `results/` | released evidence: selected bands, per-seed metrics, HybridSN five-arm runs, Friedman/Nemenyi, input SHA-256 |
| `data/` | derived wavelength tables + dataset manifest (**raw cubes not included**, see `data/README.md`) |
| `*.py` | 13 entry-point scripts, one per experiment group |

## What a reader can check without re-running anything

Every number in Tables 2, 3, A2 and 12, and the statistics of §4.5, are in
`results/`. `results/results_index.json` is the index.

## Known limits of this archive

1. **Raw cubes excluded** — third-party redistribution terms (see `data/README.md`).
   `results/data_provenance.json` carries their SHA-256 instead.
2. **GPU non-determinism** — HybridSN OA shifts by up to ~0.8 pp between runs on
   CUDA. All contrasts in the paper are paired within a seed.
3. **Budget cap ≠ budget spent** — the 3000-evaluation budget is a ceiling;
   realised counts (412–2986) are in `results/selection_*.csv`.
4. **Random-split rows of Table 12 use 5 seeds**, not 10: under a per-pixel split
   every arm exceeds 99.8 % OA, so additional seeds add no information. The `n`
   column of Table 12 states this.
5. **Timing is laptop-CPU timing** (Intel Core i9-12900H), not payload-processor
   timing. See Figure 10 and §4.10 of the paper.

## Before publishing

1. Replace `<OWNER>/<REPO>` in `CITATION.cff` with the real GitHub path.
2. Tag `v1.0.0` and enable the GitHub ↔ Zenodo integration.
3. Put the minted DOI in the manuscript's Data Availability Statement and in
   `CITATION.cff` under `identifiers:`.
