# -*- coding: utf-8 -*-
"""Merge a completed parallel-task run dir into the main run dir (the ACCEPT step).

Rows are appended by ``_key`` and de-duplicated, so re-running is idempotent.
Only call this AFTER a task reaches 100% (its jsonl is final). This mutates the
main run dirs, so it is the "accept" counterpart of the review-only
``review_update.py`` (which uses --extra-runs and never touches the originals).

    python merge.py --from output/runs/longkou_fullband --to output/runs/longkou_5cls
    python merge.py --from output/runs/indian_fullband  --to output/runs/indian_pines
    python merge.py --from output/runs/longkou_contrib2 --to output/runs/longkou_5cls
    python merge.py --from output/runs/indian_contrib2  --to output/runs/indian_pines
"""
from __future__ import annotations
import argparse
import json
import os


def merge(task_dir: str, main_dir: str) -> None:
    os.makedirs(main_dir, exist_ok=True)
    for fname in ('selection.jsonl', 'classification.jsonl'):
        tp = os.path.join(task_dir, fname)
        mp = os.path.join(main_dir, fname)
        if not os.path.isfile(tp):
            print('[merge] skip %s (no task file)' % tp)
            continue
        existing = set()
        if os.path.isfile(mp):
            with open(mp, encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        existing.add(json.loads(line).get('_key'))
                    except Exception:
                        pass
        added = 0
        with open(mp, 'a', encoding='utf-8') as out:
            with open(tp, encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        r = json.loads(line)
                    except Exception:
                        continue
                    k = r.get('_key')
                    if k in existing:
                        continue
                    out.write(json.dumps(r, ensure_ascii=False, default=str) + '\n')
                    existing.add(k)
                    added += 1
        print('[merge] %-20s +%4d rows -> %s' % (fname, added, mp))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--from', dest='task_dir', required=True)
    ap.add_argument('--to', dest='main_dir', required=True)
    a = ap.parse_args()
    merge(a.task_dir, a.main_dir)


if __name__ == '__main__':
    main()
