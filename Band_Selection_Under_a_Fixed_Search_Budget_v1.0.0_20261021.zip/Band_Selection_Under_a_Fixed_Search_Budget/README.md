# Band Selection Under a Fixed Search Budget

Code and released results for the manuscript

> **Band Selection Under a Fixed Search Budget: A Reproducible Spatial-Spectral
> Framework for On-Board Hyperspectral Classification**
> Dandan Zhang, Fangjian Liu, Lingling Ma, Ting Zhang, Tiejun Zhang
> *Applied Sciences* (under review), 2026.

A hyperspectral sensor acquires far more channels than a payload can downlink,
and the surplus is not free: neighbouring channels are near-duplicates, and
estimating class statistics in several hundred dimensions from a few hundred
labelled pixels degrades accuracy instead of improving it. This repository
selects channels rather than transforming them, and does so under a budget that
is **fixed before any method is ranked** — 3000 objective evaluations — so that
no method is tuned on a budget the others were denied.

Everything in the paper is reproducible from this repository: the 21-method
band-selection comparison, the spatial-spectral attribution over three
operators (EMP / EPF / Gabor), the runtime and model-size profile, the
wavelength traceability chain, and the HybridSN transfer experiment with its
five-arm control.

---

## 1. What is fixed, and why

| Quantity | Value | Where it is enforced |
|---|---|---|
| Search budget | `nfe_budget = 3000` distinct objective evaluations | `configs/*.json` |
| Subset size | `k_main = 4` (plus the sweep `2, 6, 8, 10, 15, 20, 30`) | `configs/*.json` |
| Objective | JM-sum, ceiling `sqrt(2) × C(5,2) = 14.1421`; optional redundancy penalty `β` | `hsbs/criteria.py` |
| Split (main tables) | stratified 20 % train / 80 % test, 10 seeds | `hsbs/split.py` |
| Split (HybridSN) | `random` (per-pixel) and `block` (spatially disjoint), 10 seeds | `run_hybridsn.py --split-mode` |
| Classifiers | `knn5`, `svm_rbf`, `rf` | `hsbs/evaluate.py` |
| Spatial operators | EMP (24 feat.), EPF (8), Gabor (1) | `configs/spatial_specs.json` |
| HybridSN | 100 epochs, batch 256, patch 11, Adam lr 1e-3 | `run_hybridsn.py` |

`hsbs/data.py` exposes one `FitnessSpec` per optimiser call, so all 21 methods
are charged the same currency. Any new method added to `hsbs/optim.py` or
`hsbs/selectors.py` is automatically compared on that same budget.

**The cap is a ceiling, not a consumption.** Realised evaluation counts range
from 412 (SA) to 2986 (IEPSO) because stagnation-based early stopping is left
enabled, as it is in normal use. The count actually spent is reported per method
in `results/selection_*.csv` (`nfe` column). Equalising *consumption* instead
would be a different experiment, and is listed as such in §4.10 of the paper.

---

## 2. Repository layout

```
hsbs/                  core library
  data.py              dataset container, loaders, synthetic generator
  split.py             shared stratified per-class train/test splits
  criteria.py          JM objective, JMRED redundancy penalty, fitness specs
  optim.py             PSO, SAPSO, MPSO, IEPSO, DESAPSO, GA, SA, GWO, DE
  selectors.py         static selectors: ASPS, FNGBS, HCBS, BDRLA, SCDBS, SNN-BS, CNN-GA
  spatial.py           EMP / EPF / Gabor operators
  evaluate.py          classifiers, metrics, paired tests
  runner.py            grid orchestration, caching, resume
  runtime_profile.py   timing and model-size profiling
  hybridsn.py          HybridSN baseline (torch)
  report.py            figure / table emission

configs/               dataset + experiment configurations (JSON, human-readable)
tools/                 wavelength traceability; result export; archive builder
results/               released machine-readable evidence (see §5)
data/                  derived wavelength tables, manifest, provenance hashes
                       (raw cubes are NOT redistributed -- see §3)

run_pipeline.py                 main 21-method comparison
batch7_8_run.py                 spatial-spectral attribution, robustness, sensitivity
run_sapso_all_operators.py      SAPSO k=4 x three operators
run_sapso_three_classifiers.py  SAPSO k=4 x three classifiers
run_runtime_profile.py          timing / model-size profile
make_runtime_tables.py          -> Tables 9, 10, 11
run_hybridsn.py                 HybridSN five-arm transfer experiment
make_spatial_split_table.py     -> Table 12
aggregate_results.py, merge.py, progress.py, prep_dataset.py, run_selftest.py
```

---

## 3. Data

The two cubes are **third-party and are not redistributed here.** Place them at:

```
data/raw/WHU_Hi_LongKou.mat
data/raw/WHU_Hi_LongKou_gt.mat
data/raw/Indian_pines_corrected.mat
data/raw/Indian_pines_gt.mat
```

| Scene | Source |
|---|---|
| WHU-Hi-LongKou | RSIDEA group, Wuhan University — http://rsidea.whu.edu.cn/resource_WHUHi_sharing.htm |
| Indian Pines | Purdue University Research Repository — doi:10.4231/R7RX991C (AVIRIS 1992) |

Verify the cubes load and refresh the manifest:

```bash
python prep_dataset.py
```

`results/data_provenance.json` records the **SHA-256 of the exact four `.mat`
files** every released number was computed from, so a reader who downloads the
same files can prove they hold the same bytes.

Band-centre wavelength tables are **not** shipped with either dataset. They are
reconstructed from official sensor documentation by the tools in `tools/`
(ENVI header for LongKou, AVIRIS-1992 calibration for Indian Pines); the
reconstructed tables themselves are released under `data/meta/`.

---

## 4. Installation

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

PyTorch is **optional**: it is only needed for the HybridSN transfer experiment
(`run_hybridsn.py`) and for the CNN-GA static selector. Everything else runs on
NumPy / SciPy / scikit-learn alone.

```bash
pip install torch --index-url https://download.pytorch.org/whl/cpu   # only if needed
```

Sanity check — runs end-to-end on synthetic data, no dataset required:

```bash
python run_selftest.py
```

---

## 5. Released results

`results/` holds the derived evidence behind every number in the paper, so the
tables can be checked without re-running anything. `results/results_index.json`
lists each file with a one-line description.

| Paper object | Released file |
|---|---|
| Tables 2, 3, A2 — selection and classification | `results/selection_*.csv`, `results/classification_*.csv` |
| Table 2 — budget consumption | `results/selection_*.csv`, column `nfe` |
| Table 6 — spatial-spectral attribution | regenerate with `batch7_8_run.py` (see §6.2) |
| Tables 9–11 — runtime, model size | regenerate with `run_runtime_profile.py` |
| Table 12 — HybridSN five-arm transfer | `results/hybridsn/t94_m8c_*_block/`, `results/hybridsn/t94_m8c_*_random/` |
| §4.7 — leak-free band-selection control | `results/hybridsn/t105_tb_hybridsn/`, `results/hybridsn/longkou_trainblock_control/`, `results/statistics/longkou_trainblock_sel4_vs_fulltr.json` |
| §4.5 — Friedman / Nemenyi | `results/statistics/` |
| §4.9 — wavelength provenance | `data/meta/`, `tools/` |
| Input-byte provenance | `results/data_provenance.json` |

To regenerate `results/` from a populated run cache:

```bash
python tools/export_results.py                       # defaults to ../output/runs
python tools/export_results.py --runs <dir> --out <dir>
```

The large run caches (`output/runs/`, hundreds of MB) are **not** part of the
release; they are regenerable and are listed in `.gitignore`.

---

## 6. Reproducing the paper

### 6.1 Main comparison — 21 methods × 10 seeds (Tables 2, 3, A2; Figures 7, 8)

```bash
python run_pipeline.py --config configs/longkou.json          # WHU-Hi-LongKou
python run_pipeline.py --config configs/indian_pines.json     # Indian Pines
```

Resumable: re-running continues from the JSONL caches under `output/runs/`.
Watch progress with `python progress.py`.

### 6.2 Spatial-spectral attribution (Table 6)

Compact layout — the spatial block is computed on the **k selected bands**
(dim `k + F`), which is the layout the deployment analysis costs:

```bash
# EMP, all 11 search methods x 10 seeds  (38.6 min on LongKou, 1.1 min on Indian Pines)
python batch7_8_run.py crosstable --dataset configs/longkou.json \
       --runs output/runs/longkou_5cls --protocol A
python batch7_8_run.py crosstable --dataset configs/indian_pines.json \
       --runs output/runs/indian_pines --protocol A

# Full-band layout (dim B + F)
python batch7_8_run.py crosstable --dataset configs/longkou.json \
       --runs output/runs/longkou_5cls --protocol B

# SAPSO k=4 with all three operators, three classifiers (EPF / Gabor rows of Table 6)
python run_sapso_all_operators.py

# Same, in the full-band layout (dim B + F) — the Gabor rows of Table 6 after the
# four-orientation bank of §3.2 was re-implemented; resumable with --resume
python run_allops_protocolB.py --resume

# SAPSO k=4, three classifiers, EMP  (three-classifier rows of Table 6)
python run_sapso_three_classifiers.py
```

### 6.3 Robustness (Tables 4, 5) and sensitivity

```bash
python run_pipeline.py --config configs/longkou_6cls.json
python run_pipeline.py --config configs/longkou_9cls.json
python batch7_8_run.py sensitivity --dataset configs/longkou.json \
       --runs output/runs/longkou_5cls
python batch7_8_run.py disjoint  --dataset configs/longkou.json \
       --runs output/runs/longkou_5cls
```

### 6.4 Runtime, model size and inference latency (Tables 9, 10, 11)

```bash
python run_runtime_profile.py
python make_runtime_tables.py
```

Measured on an idle machine (Intel Core i9-12900H, 32 GB RAM, Windows 11,
Python 3.13 + NumPy/scikit-learn), 5 repeats, median reported, no GPU.
**These are CPU timings on a laptop-class processor, not on a payload
processor** — see Figure 10 and §4.10 of the paper.

### 6.5 HybridSN transfer — five arms (Table 12, §4.7)

The manuscript compares five CNN input configurations so that the effect of
band selection cannot be confused with the effect of simply having fewer input
dimensions, nor with the PCA basis having already seen the test blocks:

| Arm | Input | PCA basis fitted on | Isolates |
|---|---|---|---|
| `full` | 270 bands → 30 PCs | every pixel | the published HybridSN reference |
| `full-tr` | 270 bands → 30 PCs | **training pixels only** | fitting asymmetry at 30-D |
| `sel4` | 4 selected bands | — | the proposed pipeline |
| `pca4` | 270 bands → 4 PCs | every pixel | dimensionality vs. selection at 4-D |
| `pca4-tr` | 270 bands → 4 PCs | **training pixels only** | fitting asymmetry at 4-D |

```bash
# spatially disjoint split (the honest read for a neighbourhood classifier)
python run_hybridsn.py run --dataset configs/longkou.json \
       --runs output/runs/longkou_5cls --out output/runs/hybridsn_longkou_block \
       --split-mode block --pca-control --pca-fit-train --max-seeds 10

# per-pixel random split (optimistic; all arms saturate above 99.8 % OA)
python run_hybridsn.py run --dataset configs/longkou.json \
       --runs output/runs/longkou_5cls --out output/runs/hybridsn_longkou_random \
       --split-mode random --pca-control --pca-fit-train --max-seeds 10

python make_spatial_split_table.py
```

Long runs are interruptible: every finished arm is flushed to disk immediately
and `--resume` skips work already done, so a killed run loses at most one arm.

```bash
python run_hybridsn.py run ... --resume --max-seeds 5    # top up to 5 seeds
```

### 6.6 Leak-free band-selection control (§4.7, fifth methodological point)

The main tables select bands from a 20 % draw of labelled pixels taken over the
whole scene, so under the spatially disjoint split that draw contains pixels that
later serve as test data — about one fifth of them. This control closes the leak
instead of arguing around it: the JM statistics are recomputed inside the
training blocks of each split, the search is rerun on them, and HybridSN is
retrained on the resulting subsets.

```bash
# re-select with the JM statistics restricted to the training blocks
python run_trainblock_selection.py --dataset configs/longkou.json \
       --split-mode block --k 4 --seeds 1-10 --out output/runs/longkou_tbselection

# retrain HybridSN on those subsets (skip-full drops the band-independent arm)
python run_hybridsn.py run --dataset configs/longkou.json \
       --runs output/runs/longkou_tbselection --out output/runs/t105_tb_hybridsn \
       --split-mode block --bands-method SAPSO-TB --pca-fit-train --skip-full \
       --resume --epochs 100 --batch 256 --max-seeds 10
```

Released outcome on WHU-Hi-LongKou (10 seeds, disjoint split): the leak-free
subsets differ from the leaked ones on every seed (mean Jaccard 0.043, 0 of 10
identical), and `sel4 - full-tr` is **+8.52 pp** (paired t = +3.22, p = 0.011,
7 of 10 seeds agreeing, Wilcoxon signed-rank p = 0.027) against +9.03 pp for the
leaked run. The 0.51 pp difference is below the 1.1 pp run-to-run spread of this
protocol, so the leak cannot be shown to have inflated the headline.

### 6.7 Wavelength traceability (§4.9)

```bash
python tools/extract_wavelengths.py
python tools/verify_wavelengths.py
python tools/band_wavelength_report.py
```

---

## 7. Reproducibility notes — read before comparing numbers

1. **Budget cap ≠ budget spent.** The ranking is *equal-opportunity*, not
   *equal-cost* (§1). Realised `nfe` is disclosed per method.
2. **GPU non-determinism.** HybridSN runs on CUDA are not bit-reproducible;
   re-running shifts per-seed OA by up to ~0.8 pp on LongKou. All reported
   contrasts are paired within a seed, so this does not move the conclusions.
3. **The operator comparison is confounded by dimensionality.** EMP, EPF and
   Gabor contribute 24, 8 and 1 features respectively, and the observed
   `EMP > EPF > Gabor` ordering coincides with that ordering. It supports
   "adding a spatial block helps", not "morphology beats edge preservation".
4. **Random-split rows of Table 12 carry no discriminating power.** Under a
   per-pixel split every arm exceeds 99.8 % OA on LongKou, so those rows exist
   to delimit the claim, not to support it. They are run at the same 10 seeds
   as the disjoint rows. Do not read the LongKou `sel4 - full` entry as a null
   result: the paired difference is -0.04 pp with t = -3.78, i.e. the sign is
   reproducible across 9 of 10 seeds while the magnitude is two orders below
   the +14.89 pp obtained under the disjoint split. What the row shows is a
   ceiling, not an absence of effect.
5. **On-board latency is measured on a laptop CPU**, not on a payload
   processor. The deployment claim is made for the Figure 10A architecture
   only (selected channels downlinked, everything else after the link).

---

## 8. Archiving on GitHub and Zenodo

This repository is set up to be archived with a DOI:

1. Push to GitHub, then replace the two `https://github.com/<OWNER>/<REPO>`
   placeholders in `CITATION.cff` with the real repository URL.
2. Enable the GitHub ↔ Zenodo integration (or upload the release archive at
   <https://zenodo.org/deposit>) and publish a release tagged `v1.0.0`.
   Zenodo reads `CITATION.cff` and mints a DOI automatically.
3. Fill the minted DOI into the manuscript's *Data Availability Statement*
   and into `CITATION.cff` under `identifiers:`.

A ready-to-upload archive, named after the article, is produced by:

```bash
python tools/build_release.py
```

---

## 9. Citation

If you use this code or these results, please cite the paper; `CITATION.cff`
carries the same metadata in machine-readable form.

```bibtex
@article{zhang2026bandselection,
  title   = {Band Selection Under a Fixed Search Budget: A Reproducible
             Spatial-Spectral Framework for On-Board Hyperspectral Classification},
  author  = {Zhang, Dandan and Liu, Fangjian and Ma, Lingling and Zhang, Ting
             and Zhang, Tiejun},
  journal = {Applied Sciences},
  year    = {2026}
}
```

---

## 10. License

MIT — see `LICENSE`. The manuscript itself is published under CC BY 4.0.
The third-party datasets are governed by their own terms (§3).
