"""Runtime and model-footprint profiling for the UAV real-time argument (M-P2-1 / T10).

Why this module exists
----------------------
Two reviewers independently flagged the same gap: the manuscript motivates the
work with on-board UAV processing under a limited downlink, yet reports no
runtime, parameter-count or model-size evidence (Reviewer 1 M9; Reviewer 2 P2-9).
The band-selection stage already records ``runtime_s`` in ``selection.jsonl``,
but the classification stage records nothing, so the "end-to-end cost" claim
cannot currently be substantiated. This module fills exactly that gap.

Measurement protocol
--------------------
1. **Fit and predict are timed separately.** In the motivating scenario the
   model is trained off-line on the ground station and only inference runs
   on-board, so inference latency -- not training time -- is the real-time
   metric. Reporting them separately also keeps the comparison honest when a
   reviewer asks "is the UAV retraining in flight?".
2. **The full-image pass is measured, not just the test split.** Downlink cost
   scales with the whole scene (LongKou 550x400 = 220,000 pixels), so the
   headline latency number is a full-scene inference pass, with throughput
   reported in pixels/second.
3. **Model footprint uses one口径 for all three classifiers.** "Number of
   learned parameters" is meaningless for a lazy learner (KNN has none yet
   stores the entire training set). We therefore report *resident elements*
   -- the number of floating point values that must be held in memory for
   inference -- alongside the raw byte count. This is comparable across
   KNN / RBF-SVM / RF and is what actually constrains an embedded payload.
4. **Every timing is the median of repeated runs.** Single-shot timings on
   Windows fluctuate by orders of magnitude under load.
"""
from __future__ import annotations

import json
import os
import statistics
import time
from contextlib import contextmanager
from typing import Dict, List, Optional, Sequence

import numpy as np

__all__ = [
    'Timer', 'profile_spatial', 'fit_timed', 'model_footprint',
    'predict_full_image', 'profile_classifier',
    'summarize_timings', 'runtime_table_markdown', 'footprint_table_markdown',
]


# --------------------------------------------------------------------- timing
@contextmanager
def Timer():
    """Minimal wall-clock timer; ``t.elapsed`` holds seconds after the block.

    ``time.perf_counter`` is used because it is monotonic and has the highest
    available resolution on Windows, where ``time.time`` resolution is poor.
    """
    t = _T()
    t.start = time.perf_counter()
    try:
        yield t
    finally:
        t.elapsed = time.perf_counter() - t.start


class _T:
    start: float = 0.0
    elapsed: float = 0.0


def _median_repeat(fn, repeats: int = 3) -> Dict[str, float]:
    """Run ``fn`` ``repeats`` times and return median/min/max wall-clock seconds."""
    vals = []
    for _ in range(max(1, int(repeats))):
        with Timer() as t:
            fn()
        vals.append(float(t.elapsed))
    return {'median_s': float(statistics.median(vals)),
            'min_s': float(min(vals)),
            'max_s': float(max(vals)),
            'n_repeats': int(len(vals))}


# --------------------------------------------------------------------- stage 2: spatial features
def profile_spatial(cube: np.ndarray, spec, repeats: int = 3) -> Dict[str, object]:
    """Time one spatial operator (EM / SRF / RV) over the full cube.

    The operator is applied to the whole scene, because that is what the
    on-board pipeline would do -- not only to the labelled subset.
    """
    from . import spatial as hssp

    out: Dict[str, object] = {'operator': getattr(spec, 'operator', str(spec)),
                              'eta': list(getattr(spec, 'eta', [])),
                              'lam': float(getattr(spec, 'lam', 0.0)),
                              'n_pc': int(getattr(spec, 'n_pc', 0))}
    timing = _median_repeat(lambda: hssp.extract_features(cube, spec), repeats=repeats)
    feats = hssp.extract_features(cube, spec)
    out.update(timing)
    out['output_shape'] = list(feats.shape)
    out['n_feature_bands'] = int(feats.shape[-1])
    return out


# --------------------------------------------------------------------- stage 3: classifier
def _standardize(Xtr: np.ndarray, Xte: np.ndarray):
    Xtr = np.asarray(Xtr, dtype=np.float64)
    Xte = np.asarray(Xte, dtype=np.float64)
    mu = Xtr.mean(axis=0, keepdims=True)
    sd = Xtr.std(axis=0, keepdims=True)
    sd[sd < 1e-12] = 1e-12
    return (Xtr - mu) / sd, (Xte - mu) / sd


def fit_timed(spec, Xtr: np.ndarray, ytr: np.ndarray,
              standardize: bool = True, repeats: int = 1):
    """Fit ``spec`` and return ``(fitted_model, train_X, timing_dict)``."""
    if standardize:
        Xtr_s, _ = _standardize(Xtr, Xtr)
    else:
        Xtr_s = np.asarray(Xtr, dtype=np.float64)
    clf = spec.make()
    timing = _median_repeat(lambda: clf.fit(Xtr_s, ytr), repeats=repeats)
    return clf, Xtr_s, timing


def model_footprint(clf, key: str, n_features: int) -> Dict[str, object]:
    """Resident-model accounting under one口径 for KNN / RBF-SVM / RF.

    ``resident_elements`` counts the floating point values that must be held in
    memory at inference time. For KNN this is the stored training matrix (there
    are no learned parameters, but the payload is real); for RBF-SVM it is the
    support vectors plus the dual coefficients; for RF it is every split node
    plus its leaf distributions.

    ``learned_params`` is reported separately and is 0 for the lazy learner --
    reporting it as "parameter count" without this caveat is exactly the kind of
    claim a reviewer will attack.
    """
    out: Dict[str, object] = {'classifier': key, 'n_features': int(n_features),
                              'learned_params': 0, 'resident_elements': 0,
                              'resident_bytes': 0, 'detail': {}}

    if key.startswith('knn'):
        # Lazy learner: no training, but the whole training matrix is the model.
        X = getattr(clf, '_fit_X', None)
        y = getattr(clf, '_y', None)
        n_tr = int(np.asarray(X).shape[0]) if X is not None else 0
        elems = int(np.asarray(X).size) if X is not None else 0
        if y is not None:
            elems += int(np.asarray(y).size)
        nbytes = int(np.asarray(X).nbytes) if X is not None else 0
        if y is not None:
            nbytes += int(np.asarray(y).nbytes)
        out.update({'learned_params': 0, 'resident_elements': elems,
                    'resident_bytes': nbytes,
                    'detail': {'n_training_samples_stored': n_tr,
                               'storage_per_sample_bytes': int(round(nbytes / n_tr * 8)) if n_tr else 0,
                               'note': 'lazy learner: the stored training set IS the model'}})

    elif key == 'svm_rbf':
        sv = getattr(clf, 'support_vectors_', None)
        dc = getattr(clf, 'dual_coef_', None)
        ic = getattr(clf, 'intercept_', None)
        elems = 0
        nbytes = 0
        for a in (sv, dc, ic):
            if a is not None:
                arr = np.asarray(a)
                elems += int(arr.size)
                nbytes += int(arr.nbytes)
        n_sv = int(np.asarray(sv).shape[0]) if sv is not None else 0
        out.update({'learned_params': elems, 'resident_elements': elems,
                    'resident_bytes': nbytes,
                    'detail': {'n_support_vectors': n_sv,
                               'sv_dim': int(np.asarray(sv).shape[1]) if sv is not None and np.asarray(sv).ndim > 1 else 0,
                               'note': 'support vectors are a subset of the training set retained at inference'}})

    elif key == 'rf':
        ests = list(getattr(clf, 'estimators_', []))
        n_nodes = 0
        n_leaves = 0
        for e in ests:
            tree = getattr(e, 'tree_', None)
            if tree is None:
                continue
            n_nodes += int(tree.node_count)
            n_leaves += int(np.sum(tree.children_left < 0))
        # children_left/right (int) + feature (int) + threshold (float) + value (float)
        elems = 0
        nbytes = 0
        for e in ests:
            tree = getattr(e, 'tree_', None)
            if tree is None:
                continue
            for arr in (tree.children_left, tree.children_right, tree.feature,
                        tree.threshold, tree.value):
                elems += int(np.asarray(arr).size)
                nbytes += int(np.asarray(arr).nbytes)
        out.update({'learned_params': elems, 'resident_elements': elems,
                    'resident_bytes': nbytes,
                    'detail': {'n_trees': int(len(ests)),
                               'n_nodes_total': int(n_nodes),
                               'n_leaves_total': int(n_leaves),
                               'note': 'each split node stores child ids, feature index, threshold and class distribution'}})
    return out


def predict_full_image(clf, X: np.ndarray, block: int = 20000) -> Dict[str, float]:
    """Time a full-scene inference pass, chunked to bound peak memory.

    Chunking changes the wall clock slightly (per-call overhead) but keeps the
    measurement from being dominated by paging on a 220k x d array.
    """
    X = np.asarray(X, dtype=np.float64)
    n = int(X.shape[0])
    block = max(1, int(block))
    preds: List[np.ndarray] = []
    t0 = time.perf_counter()
    for i in range(0, n, block):
        preds.append(np.asarray(clf.predict(X[i:i + block])).ravel())
    dt = time.perf_counter() - t0
    return {'total_s': float(dt), 'n_pixels': n,
            'throughput_px_per_s': float(n / dt) if dt > 0 else float('nan'),
            'n_blocks': int((n + block - 1) // block)}


def profile_classifier(spec, Xtr: np.ndarray, ytr: np.ndarray,
                       Xte: np.ndarray, standardize: bool = True,
                       full_image: Optional[np.ndarray] = None,
                       block: int = 20000) -> Dict[str, object]:
    """One classifier: fit time, test-split predict time, footprint, full-scene pass."""
    if standardize:
        Xtr_s, Xte_s = _standardize(Xtr, Xte)
    else:
        Xtr_s, Xte_s = (np.asarray(Xtr, dtype=np.float64),
                        np.asarray(Xte, dtype=np.float64))

    clf = spec.make()
    with Timer() as tf:
        clf.fit(Xtr_s, ytr)
    fit_s = float(tf.elapsed)

    with Timer() as tp:
        _ = np.asarray(clf.predict(Xte_s)).ravel()
    pred_s = float(tp.elapsed)

    out: Dict[str, object] = {
        'classifier': spec.key,
        'label': spec.label,
        'n_features': int(Xtr_s.shape[1]),
        'n_train': int(Xtr_s.shape[0]),
        'n_test': int(Xte_s.shape[0]),
        'fit_s': fit_s,
        'predict_test_s': pred_s,
        'predict_test_throughput_px_per_s': (float(Xte_s.shape[0] / pred_s)
                                             if pred_s > 0 else float('nan')),
    }
    out['footprint'] = model_footprint(clf, spec.key, int(Xtr_s.shape[1]))

    if full_image is not None:
        F = np.asarray(full_image, dtype=np.float64)
        if standardize:
            # Standardisation statistics come from TRAIN only; applying them to
            # the full scene is what the deployed pipeline does.
            mu = np.asarray(Xtr, dtype=np.float64).mean(axis=0, keepdims=True)
            sd = np.asarray(Xtr, dtype=np.float64).std(axis=0, keepdims=True)
            sd[sd < 1e-12] = 1e-12
            F = (F - mu) / sd
        out['full_image'] = predict_full_image(clf, F, block=block)
    return out


# --------------------------------------------------------------------- aggregation
def summarize_timings(records: Sequence[Dict[str, object]]) -> Dict[str, object]:
    """Mean +/- std over seeds for every timing key present in ``records``."""
    keys = ['fit_s', 'predict_test_s', 'predict_test_throughput_px_per_s']
    agg: Dict[str, object] = {}
    for k in keys:
        vals = [float(r[k]) for r in records if k in r and np.isfinite(float(r[k]))]
        if vals:
            agg[k] = {'mean': float(np.mean(vals)),
                      'std': float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0,
                      'n': int(len(vals))}
    fi = [r['full_image'] for r in records if 'full_image' in r]
    if fi:
        tot = [float(x['total_s']) for x in fi]
        th = [float(x['throughput_px_per_s']) for x in fi]
        agg['full_image_total_s'] = {'mean': float(np.mean(tot)),
                                     'std': float(np.std(tot, ddof=1)) if len(tot) > 1 else 0.0,
                                     'n': int(len(tot))}
        agg['full_image_throughput_px_per_s'] = {'mean': float(np.mean(th)),
                                                 'std': float(np.std(th, ddof=1)) if len(th) > 1 else 0.0,
                                                 'n': int(len(th))}
        agg['full_image_n_pixels'] = int(fi[0]['n_pixels'])
    return agg


# --------------------------------------------------------------------- tables
def runtime_table_markdown(rows: Sequence[Dict[str, object]]) -> str:
    """Runtime table: per classifier, fit / test-predict / full-scene latency."""
    head = ['classifier', 'n_features', 'n_train', 'fit (s)', 'test predict (s)',
            'full-scene (s)', 'throughput (px/s)']
    lines = ['| ' + ' | '.join(head) + ' |',
             '|' + '|'.join(['---'] * len(head)) + '|']
    for r in rows:
        fi = r.get('full_image', {})
        lines.append('| %s | %d | %d | %.3f | %.3f | %s | %s |' % (
            r.get('label', r.get('classifier', '?')),
            int(r.get('n_features', 0)),
            int(r.get('n_train', 0)),
            float(r.get('fit_s', float('nan'))),
            float(r.get('predict_test_s', float('nan'))),
            ('%.2f' % fi['total_s']) if fi else 'n/a',
            ('%.0f' % fi['throughput_px_per_s']) if fi else 'n/a'))
    return '\n'.join(lines)


def footprint_table_markdown(rows: Sequence[Dict[str, object]]) -> str:
    """Model-size table: learned params vs resident elements and bytes."""
    head = ['classifier', 'learned params', 'resident elements', 'resident (KB)', 'detail']
    lines = ['| ' + ' | '.join(head) + ' |',
             '|' + '|'.join(['---'] * len(head)) + '|']
    for r in rows:
        fp = r.get('footprint', {})
        det = fp.get('detail', {})
        bits = []
        for k in ('n_training_samples_stored', 'n_support_vectors', 'n_trees',
                  'n_nodes_total'):
            if k in det:
                bits.append('%s=%s' % (k, det[k]))
        lines.append('| %s | %s | %s | %.1f | %s |' % (
            r.get('label', r.get('classifier', '?')),
            '{:,}'.format(int(fp.get('learned_params', 0))),
            '{:,}'.format(int(fp.get('resident_elements', 0))),
            float(fp.get('resident_bytes', 0)) / 1024.0,
            ', '.join(bits) if bits else det.get('note', '')))
    return '\n'.join(lines)
