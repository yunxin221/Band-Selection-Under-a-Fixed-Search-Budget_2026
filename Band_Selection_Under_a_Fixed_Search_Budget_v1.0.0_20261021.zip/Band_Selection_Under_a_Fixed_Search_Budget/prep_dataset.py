"""Dataset preparation & validation for batches 7-8 experiments.

Confirms both benchmark cubes are present and loadable, prints the dataset
fingerprint and per-class support, and writes ``data/dataset_manifest.json`` so
the batch-7/8 driver (and a future session after context compression) can verify
data readiness without re-reading the heavy ``.mat`` files.

Usage:
    python prep_dataset.py
"""
from __future__ import annotations

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = HERE
sys.path.insert(0, HERE)

from hsbs import data as hsdata  # noqa: E402
from hsbs.runner import dataset_fingerprint  # noqa: E402

# (config_dataset_entry, label) -- mirrors code/configs/*.json dataset blocks.
DATASETS = [
    ('data/raw/WHU_Hi_LongKou.mat', 'data/raw/WHU_Hi_LongKou_gt.mat', 'WHU-Hi-LongKou'),
    ('data/raw/Indian_pines_corrected.mat', 'data/raw/Indian_pines_gt.mat', 'Indian Pines'),
]


def main(argv=None) -> int:
    manifest: dict = {'datasets': [], 'ok': True}
    for cube_path, gt_path, name in DATASETS:
        abs_cube = os.path.join(ROOT, cube_path)
        abs_gt = os.path.join(ROOT, gt_path)
        entry = {'name': name, 'cube': cube_path, 'gt': gt_path, 'present': False}
        if not (os.path.isfile(abs_cube) and os.path.isfile(abs_gt)):
            entry['error'] = 'missing file(s) on disk'
            manifest['ok'] = False
            manifest['datasets'].append(entry)
            print('[MISS] %s : %s' % (name, entry['error']), flush=True)
            continue
        try:
            ds = hsdata.load_dataset(abs_cube, gt_path=abs_gt, name=name)
        except Exception as exc:  # pragma: no cover
            entry['error'] = 'load failed: %s' % exc
            manifest['ok'] = False
            manifest['datasets'].append(entry)
            print('[FAIL] %s : %s' % (name, exc), flush=True)
            continue
        counts = ds.counts()
        entry.update({
            'present': True,
            'shape': list(ds.cube.shape),
            'n_bands': ds.n_bands,
            'n_classes': len(ds.classes),
            'fingerprint': dataset_fingerprint(ds),
            'n_labelled': int(sum(counts.values())),
            'class_counts': {int(c): int(counts[c]) for c in ds.classes},
            'wavelengths_nm': ([float(ds.wavelengths[0]), float(ds.wavelengths[-1])]
                               if ds.wavelengths is not None else None),
        })
        manifest['datasets'].append(entry)
        print('[OK]   %s  cube=%s  bands=%d  classes=%d  labelled=%d  fp=%s'
              % (name, list(ds.cube.shape), ds.n_bands, len(ds.classes),
                 entry['n_labelled'], entry['fingerprint']), flush=True)
        # flag tiny classes (the M-P2-5 / Indian-Pines small-sample risk)
        tiny = {c: counts[c] for c in ds.classes if counts[c] < 30}
        if tiny:
            print('        tiny classes (<30 px): %s' % tiny, flush=True)
            entry['tiny_classes'] = {int(c): int(n) for c, n in tiny.items()}

    out_path = os.path.join(ROOT, 'data', 'dataset_manifest.json')
    with open(out_path, 'w', encoding='utf-8') as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=2)
    print('\nmanifest -> %s' % out_path)
    print('ALL PRESENT' if manifest['ok'] else 'SOME DATASETS MISSING')
    return 0 if manifest['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
