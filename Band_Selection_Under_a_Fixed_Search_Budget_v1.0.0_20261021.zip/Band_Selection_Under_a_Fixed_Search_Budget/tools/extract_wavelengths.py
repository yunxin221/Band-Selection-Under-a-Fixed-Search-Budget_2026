# -*- coding: utf-8 -*-
"""
t42_wavelengths.py
------------------
把两个数据集的"波段索引 -> 中心波长(nm)"映射固化到 data/meta/ 下。

数据来源（官方）：
1) WHU-Hi-LongKou : RSIDEA(武汉大学) 官方发布的 ENVI 标准格式头文件
   WHU-Hi-LongKou.hdr（wavelength = {...} 270 个中心波长）
   官方页面: https://rsidea.whu.edu.cn/resource_WHUHi_sharing.htm
   本文件通过官方 ENVI 分发的镜像获取(hf-mirror -> danaroth/whu_hi)。

2) Indian Pines : Purdue 官方 AVIRIS 1992 220 通道光谱定标文档
   "Information on 220 Channel AVIRIS Data Set"
   https://engineering.purdue.edu/~biehl/MultiSpec/aviris_documentation.html
   (= PURR doi:10.4231/R7RX991C 随附文件
     Calibration_Information_for_220_Channel_Data_Band_Set.txt 的网页版)
   原始 220 通道 -> 去掉水体吸收通道 [104-108]、[150-163]、220
   -> 200 波段（即 indian_pines_corrected.mat）。

输出：
  data/meta/longkou_wavelengths_270.json / .csv
  data/meta/indian_pines_wavelengths_200.json / .csv
  data/dataset_manifest.json 回填 wavelengths_file / wavelengths_source
"""
import csv
import json
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
META = os.path.join(ROOT, "data", "meta")
RAW = os.path.join(ROOT, "data", "raw")
os.makedirs(META, exist_ok=True)

# --------------------------------------------------------------------------
# 1) LongKou: 解析官方 ENVI .hdr
# --------------------------------------------------------------------------
hdr_path = os.path.join(META, "WHU-Hi-LongKou.hdr")
txt = open(hdr_path, encoding="utf-8", errors="ignore").read()

def hdr_int(key):
    m = re.search(rf"^{key}\s*=\s*(\d+)", txt, re.M)
    return int(m.group(1)) if m else None

lk_bands = hdr_int("bands")
m = re.search(r"wavelength\s*=\s*\{(.*?)\}", txt, re.S)
lk_wl = [float(x) for x in re.split(r"[,\s]+", m.group(1).strip()) if x]
assert lk_bands == 270, lk_bands
assert len(lk_wl) == 270, len(lk_wl)
units = re.search(r"wavelength units\s*=\s*(\S+)", txt).group(1)
lk_steps = [round(lk_wl[i + 1] - lk_wl[i], 4) for i in range(len(lk_wl) - 1)]

lk_rec = {
    "dataset": "WHU-Hi-LongKou",
    "n_bands": 270,
    "wavelength_units": units,
    "range_nm": [lk_wl[0], lk_wl[-1]],
    "mean_spacing_nm": round(sum(lk_steps) / len(lk_steps), 4),
    "spacing_min_max_nm": [min(lk_steps), max(lk_steps)],
    "source": {
        "file": "data/meta/WHU-Hi-LongKou.hdr",
        "origin": "RSIDEA (Wuhan University) WHU-Hi ENVI standard format distribution",
        "url": "https://rsidea.whu.edu.cn/resource_WHUHi_sharing.htm",
        "note": "UAV Headwall Nano-Hyperspec, 400-1000 nm, 270 bands; "
                "header wavelengths 401.809998-999.280029 nm, near-uniform 2.221 nm.",
    },
    "wavelengths_nm": [round(v, 3) for v in lk_wl],
}
with open(os.path.join(META, "longkou_wavelengths_270.json"), "w", encoding="utf-8") as f:
    json.dump(lk_rec, f, ensure_ascii=False, indent=1)
with open(os.path.join(META, "longkou_wavelengths_270.csv"), "w", newline="", encoding="utf-8-sig") as f:
    w = csv.writer(f)
    w.writerow(["band_index_1based", "wavelength_nm"])
    for i, v in enumerate(lk_wl, 1):
        w.writerow([i, round(v, 3)])

# --------------------------------------------------------------------------
# 2) Indian Pines: Purdue 官方 220 通道定标表
#    列: AVIRIS Data Band # | Channel # | Center Wavelength (nm) | FWHM (nm)
# --------------------------------------------------------------------------
RAW_TBL = """
   1     (not used - the band was all 0's)
   2       1     400.02     9.78
   3       2     409.82     9.82
   4       3     419.62     9.85
   5       4     429.43     9.89
   6       5     439.25     9.92
   7       6     449.07     9.94
   8       7     458.90     9.97
   9       8     468.73     9.99
  10       9     478.57    10.01
  11      10     488.41    10.02
  12      11     498.26    10.04
  13      12     508.12    10.05
  14      13     517.98    10.05
  15      14     527.85    10.06
  16      15     537.72    10.06
  17      16     547.60    10.06
  18      17     557.49    10.05
  19      18     567.38    10.04
  20      19     577.28    10.03
  21      20     587.18    10.02
  22      21     597.09    10.00
  23      22     607.01     9.98
  24      23     616.93     9.96
  25      24     626.85     9.94
  26      25     636.78     9.91
  27      26     646.72     9.88
  28      27     656.67     9.84
  29      28     666.61     9.81
  30      29     676.57     9.77
  31      30     686.53     9.73
  32      31     696.50     9.68
  33     (not used - the band was all 0's)
  34      32     686.91     8.87
  35      33     696.55     8.87
  36      34     706.19     8.88
  37      35     715.83     8.88
  38      36     725.47     8.88
  39      37     735.11     8.89
  40      38     744.74     8.89
  41      39     754.38     8.89
  42      40     764.01     8.90
  43      41     773.64     8.90
  44      42     783.27     8.90
  45      43     792.91     8.91
  46      44     802.53     8.91
  47      45     812.21     8.91
  48      46     821.79     8.92
  49      47     831.41     8.92
  50      48     841.04     8.92
  51      49     850.66     8.93
  52      50     860.28     8.93
  53      51     869.91     8.93
  54      52     879.53     8.93
  55      53     889.14     8.94
  56      54     898.76     8.94
  57      55     908.38     8.94
  58      56     917.99     8.94
  59      57     927.61     8.95
  60      58     937.22     8.95
  61      59     946.83     8.95
  62      60     956.45     8.95
  63      61     966.06     8.95
  64      62     975.66     8.96
  65      63     985.27     8.96
  66      64     994.88     8.96
  67      65    1004.48     8.96
  68      66    1014.09     8.96
  69      67    1023.69     8.97
  70      68    1033.29     8.97
  71      69    1042.89     8.97
  72      70    1052.49     8.97
  73      71    1062.09     8.97
  74      72    1071.69     8.97
  75      73    1081.29     8.97
  76      74    1090.88     8.98
  77      75    1100.48     8.98
  78      76    1110.07     8.98
  79      77    1119.66     8.98
  80      78    1129.25     8.98
  81      79    1138.84     8.98
  82      80    1148.43     8.98
  83      81    1158.02     8.98
  84      82    1167.61     8.98
  85      83    1177.19     8.98
  86      84    1186.77     8.99
  87      85    1196.36     8.99
  88      86    1205.94     8.99
  89      87    1215.52     8.99
  90      88    1225.10     8.99
  91      89    1234.68     8.99
  92      90    1244.26     8.99
  93      91    1253.83     8.99
  94      92    1263.41     8.99
  95      93    1272.98     8.99
  96      94    1282.55     8.99
  97     (not used - the band was all 0's)
  98      95    1273.00     9.18
  99      96    1282.96     9.20
 100      97    1292.93     9.22
 101      98    1302.89     9.24
 102      99    1312.85     9.26
 103     100    1322.81     9.28
 104     101    1332.77     9.30
 105     102    1342.73     9.32
 106     103    1352.68     9.34
 107     104    1362.64     9.36
 108     105    1372.59     9.37
 109     106    1382.54     9.39
 110     107    1392.49     9.41
 111     108    1402.44     9.43
 112     109    1412.39     9.44
 113     110    1422.34     9.46
 114     111    1432.28     9.47
 115     112    1442.23     9.49
 116     113    1452.17     9.51
 117     114    1462.11     9.52
 118     115    1472.05     9.54
 119     116    1481.99     9.55
 120     117    1491.92     9.57
 121     118    1501.86     9.58
 122     119    1511.79     9.59
 123     120    1521.73     9.61
 124     121    1531.66     9.62
 125     122    1541.59     9.63
 126     123    1551.52     9.65
 127     124    1561.44     9.66
 128     125    1571.37     9.67
 129     126    1581.30     9.68
 130     127    1591.22     9.70
 131     128    1601.14     9.71
 132     129    1611.06     9.72
 133     130    1620.98     9.73
 134     131    1630.90     9.74
 135     132    1640.81     9.75
 136     133    1650.73     9.76
 137     134    1660.64     9.77
 138     135    1670.56     9.78
 139     136    1680.47     9.79
 140     137    1690.38     9.80
 141     138    1700.28     9.81
 142     139    1710.19     9.82
 143     140    1720.10     9.82
 144     141    1730.00     9.83
 145     142    1739.90     9.84
 146     143    1749.81     9.85
 147     144    1759.71     9.85
 148     145    1769.60     9.86
 149     146    1779.50     9.87
 150     147    1789.40     9.87
 151     148    1799.29     9.88
 152     149    1809.19     9.89
 153     150    1819.08     9.89
 154     151    1828.97     9.90
 155     152    1838.86     9.90
 156     153    1848.75     9.91
 157     154    1858.63     9.91
 158     155    1868.52     9.91
 159     156    1878.40     9.92
 160     157    1888.28     9.92
 161     (not used - the band was all 0's)
 162     158    1883.24    13.72
 163     159    1893.25    13.75
 164     160    1903.26    13.79
 165     161    1913.26    13.82
 166     162    1923.27    13.85
 167     163    1933.27    13.88
 168     164    1943.27    13.91
 169     165    1953.26    13.95
 170     166    1963.25    13.97
 171     167    1973.24    14.00
 172     168    1983.23    14.03
 173     169    1993.22    14.06
 174     170    2003.20    14.09
 175     171    2013.18    14.11
 176     172    2023.16    14.14
 177     173    2033.13    14.16
 178     174    2043.10    14.19
 179     175    2053.07    14.21
 180     176    2063.04    14.23
 181     177    2073.00    14.26
 182     178    2082.97    14.28
 183     179    2092.92    14.30
 184     180    2102.88    14.32
 185     181    2112.83    14.34
 186     182    2122.78    14.36
 187     183    2132.73    14.38
 188     184    2142.68    14.39
 189     185    2152.62    14.41
 190     186    2162.56    14.43
 191     187    2172.50    14.44
 192     188    2182.43    14.46
 193     189    2192.37    14.47
 194     190    2202.30    14.49
 195     191    2260.22    14.50
 196     192    2270.15    14.51
 197     193    2232.07    14.52
 198     194    2241.99    14.53
 199     195    2251.90    14.54
 200     196    2261.82    14.55
 201     197    2271.73    14.56
 202     198    2281.64    14.57
 203     199    2291.54    14.58
 204     200    2301.45    14.58
 205     201    2311.35    14.59
 206     202    2321.25    14.60
 207     203    2331.14    14.60
 208     204    2341.03    14.61
 209     205    2350.92    14.61
 210     206    2360.81    14.61
 211     207    2370.70    14.61
 212     208    2380.58    14.61
 213     209    2390.46    14.62
 214     210    2400.33    14.62
 215     211    2410.21    14.62
 216     212    2420.08    14.61
 217     213    2429.95    14.61
 218     214    2439.81    14.61
 219     215    2449.68    14.61
 220     216    2459.54    14.60
 221     217    2469.40    14.60
 222     218    2479.25    14.59
 223     219    2489.11    14.59
 224     220    2498.96    14.58
"""

rows = []
for line in RAW_TBL.strip().splitlines():
    line = line.strip()
    if not line or "not used" in line:
        continue
    p = line.split()
    rows.append((int(p[0]), int(p[1]), float(p[2]), float(p[3])))

assert len(rows) == 220, len(rows)
chan = [r[1] for r in rows]
assert sorted(chan) == list(range(1, 221)), "channel numbering broken"

# 存档：Purdue 官方 220 通道定标表（转写自官方网页，作为可追溯的源数据）
with open(os.path.join(META, "AVIRIS_1992_220ch_calibration.txt"), "w", encoding="utf-8") as f:
    f.write("# Source: Purdue MultiSpec, 'Information on 220 Channel AVIRIS Data Set'\n")
    f.write("# https://engineering.purdue.edu/~biehl/MultiSpec/aviris_documentation.html\n")
    f.write("# = PURR doi:10.4231/R7RX991C 随附 "
            "Calibration_Information_for_220_Channel_Data_Band_Set.txt\n")
    f.write("# AVIRIS(1992-06-12, Indian Pine Site 3), columns:\n")
    f.write("# aviris_data_band  channel  center_wavelength_nm  fwhm_nm\n")
    for r in rows:
        f.write("%4d %5d %10.2f %8.2f\n" % r)

# 官方 200 波段集 = 220 通道去掉水体吸收通道 [104-108]、[150-163] 与 220
REMOVED = set(range(104, 109)) | set(range(150, 164)) | {220}
kept = [r for r in rows if r[1] not in REMOVED]
assert len(kept) == 200, len(kept)

ip_rec = {
    "dataset": "Indian Pines (corrected, 200 bands)",
    "n_bands": 200,
    "wavelength_units": "Nanometers",
    "range_nm": [kept[0][2], kept[-1][2]],
    "removed_channels_of_220": sorted(REMOVED),
    "source": {
        "origin": "Purdue MultiSpec / PURR AVIRIS 1992 spectral calibration "
                  "(Calibration_Information_for_220_Channel_Data_Band_Set.txt)",
        "url": "https://engineering.purdue.edu/~biehl/MultiSpec/aviris_documentation.html",
        "doi": "10.4231/R7RX991C",
        "note": "220 channels -> drop water-absorption channels "
                "[104-108]=1362.64-1402.44 nm, [150-163]=1848.75-1933.27 nm and 220=2498.96 nm.",
    },
    "bands": [
        {"band_index_1based": i, "channel_of_220": r[1],
         "wavelength_nm": r[2], "fwhm_nm": r[3]}
        for i, r in enumerate(kept, 1)
    ],
}
with open(os.path.join(META, "indian_pines_wavelengths_200.json"), "w", encoding="utf-8") as f:
    json.dump(ip_rec, f, ensure_ascii=False, indent=1)
with open(os.path.join(META, "indian_pines_wavelengths_200.csv"), "w", newline="", encoding="utf-8-sig") as f:
    w = csv.writer(f)
    w.writerow(["band_index_1based", "channel_of_220", "wavelength_nm", "fwhm_nm"])
    for b in ip_rec["bands"]:
        w.writerow([b["band_index_1based"], b["channel_of_220"], b["wavelength_nm"], b["fwhm_nm"]])

print("[LongKou] 270 bands: %.3f - %.3f nm, spacing %.4f nm (min %.4f max %.4f)"
      % (lk_wl[0], lk_wl[-1], lk_rec["mean_spacing_nm"], min(lk_steps), max(lk_steps)))
print("[Indian ] 200 bands: %.2f - %.2f nm ; removed channels %s"
      % (ip_rec["range_nm"][0], ip_rec["range_nm"][1], sorted(REMOVED)))
print("[Indian ] removed wavelength ranges: "
      "%.2f-%.2f nm and %.2f-%.2f nm and %.2f nm"
      % (rows[[r[1] for r in rows].index(104)][2], rows[[r[1] for r in rows].index(108)][2],
         rows[[r[1] for r in rows].index(150)][2], rows[[r[1] for r in rows].index(163)][2],
         rows[[r[1] for r in rows].index(220)][2]))

# --------------------------------------------------------------------------
# 3) 回填 dataset_manifest.json
# --------------------------------------------------------------------------
mf_path = os.path.join(ROOT, "data", "dataset_manifest.json")
mf = json.load(open(mf_path, encoding="utf-8"))
for ds in mf["datasets"]:
    if ds["name"] == "WHU-Hi-LongKou":
        ds["wavelengths_file"] = "data/meta/longkou_wavelengths_270.json"
        ds["wavelengths_nm_range"] = [round(lk_wl[0], 3), round(lk_wl[-1], 3)]
        ds["wavelengths_source"] = "RSIDEA WHU-Hi official ENVI header (WHU-Hi-LongKou.hdr)"
        ds.pop("wavelengths_nm", None)
    if ds["name"] == "Indian Pines":
        ds["wavelengths_file"] = "data/meta/indian_pines_wavelengths_200.json"
        ds["wavelengths_nm_range"] = [kept[0][2], kept[-1][2]]
        ds["wavelengths_source"] = ("Purdue AVIRIS-1992 220-channel calibration "
                                    "(doi:10.4231/R7RX991C), channels [104-108],[150-163],220 removed")
        ds.pop("wavelengths_nm", None)
json.dump(mf, open(mf_path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("[manifest] updated:", mf_path)
