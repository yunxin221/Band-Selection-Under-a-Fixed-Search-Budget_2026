# -*- coding: utf-8 -*-
"""Aggregate R1-2 comparison runs and back-fill the record xlsx + figures.

Reads the three runner outputs (longkou_5cls main, longkou_9cls / longkou_6cls
robustness), computes the summary numbers the manuscript and the record table
need, then (a) writes summary.json, (b) updates the xlsx record table, and
(c) renders the figures the design calls for (convergence / k-sweep / time).

Run AFTER the runner finished:
    python aggregate_results.py
"""
from __future__ import annotations
import json, os, statistics, shutil
from typing import Dict, List, Optional

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = r'E:/WorkBuddy/文章/mpdi'
RUNS = {
    '5cls': os.path.join(ROOT, 'output/runs/longkou_5cls'),
    '6cls': os.path.join(ROOT, 'output/runs/longkou_6cls'),
    '9cls': os.path.join(ROOT, 'output/runs/longkou_9cls'),
    'ip': os.path.join(ROOT, 'output/runs/indian_pines'),
}
XLSX_SRC = os.path.join(ROOT, 'output/r1-2-20261015/R1-2_对比实验配置与结果记录表.xlsx')
# Write the back-filled results to a NEW file. The original is occasionally
# locked by an external handler (OneDrive / antivirus / preview), and writing
# it directly raises PermissionError on save. The new file is based on a copy
# of the original so layout/colums are preserved.
XLSX = os.path.join(ROOT, 'output/r1-2-20261015/R1-2_对比实验配置与结果记录表_回填.xlsx')
FIG_DIR = os.path.join(ROOT, 'output/runs/figures')
K_MAIN = 4

# order used everywhere (PSO == manuscript "SPSO")
METHOD_ORDER = ['PSO', 'SAPSO', 'MPSO', 'MPSO-0.4', 'IEPSO', 'DESAPSO',
                'GA', 'SA', 'GWO', 'DE',
                'ASPS', 'FNGBS', 'HCBS', 'BDRLA', 'SCDBS', 'SNN-BS', 'CNN-GA',
                'JMRED0', 'JMRED3', 'JMRED6', 'SUBSPACEDIV', 'FULLBAND']
METHOD_LABEL = {  # xlsx / manuscript label
    'PSO': 'SPSO', 'SAPSO': 'SAPSO', 'MPSO': 'MPSO', 'MPSO-0.4': 'MPSO (thr=0.4)',
    'IEPSO': 'IEPSO', 'DESAPSO': 'DESAPSO', 'GA': 'GA', 'SA': 'SA', 'GWO': 'GWO',
    'DE': 'DE',
    'ASPS': 'ASPS', 'FNGBS': 'FNGBS', 'HCBS': 'HCBS', 'BDRLA': 'BDRLA',
    'SCDBS': 'SCDBS', 'SNN-BS': 'SNN-BS', 'CNN-GA': 'CNN-GA',
    'JMRED0': 'JMRED (beta=0)', 'JMRED3': 'JMRED (beta=0.3)', 'JMRED6': 'JMRED (beta=0.6)',
    'SUBSPACEDIV': 'SubspaceDiv (Ye [39])',
    'FULLBAND': 'Full-band',
}
# Extra run directories merged in for aggregation (review mode / parallel tasks).
# Keyed by the same names as RUNS; rows from these dirs are appended (deduped by _key).
EXTRA_RUNS: Dict[str, List[str]] = {}
# Category-I (iterative optimisers) vs Category II-IV (static selectors)
STATIC_METHODS = {'ASPS', 'FNGBS', 'HCBS', 'BDRLA', 'SCDBS', 'SNN-BS', 'CNN-GA'}
CLF_ORDER = ['knn5', 'svm_rbf', 'rf']
CLF_LABEL = {'knn5': 'KNN', 'svm_rbf': 'RBF-SVM', 'rf': '随机森林'}


def load_jsonl(path: str) -> List[dict]:
    if not os.path.isfile(path):
        return []
    with open(path, encoding='utf-8') as f:
        return [json.loads(l) for l in f]


def _load_run(run_key: str, fname: str) -> List[dict]:
    """Rows from the primary run dir plus any EXTRA_RUNS dirs (review mode)."""
    rows = load_jsonl(os.path.join(RUNS[run_key], fname))
    for d in EXTRA_RUNS.get(run_key, []):
        rows += load_jsonl(os.path.join(d, fname))
    return rows


def _mean(xs):
    return statistics.mean(xs) if xs else float('nan')


def _std(xs):  # population std
    return statistics.pstdev(xs) if len(xs) > 1 else 0.0


def _var(xs):
    return statistics.pvariance(xs) if len(xs) > 1 else 0.0


def agg_selection(run_key: str, k: int = K_MAIN) -> Dict[str, dict]:
    rows = [r for r in _load_run(run_key, 'selection.jsonl') if r['k'] == k]
    out: Dict[str, dict] = {}
    for m in METHOD_ORDER:
        sub = [r for r in rows if r['method'] == m]
        if not sub:
            continue
        objs = [r['objective'] for r in sub]
        corrs = [r.get('mean_abs_corr', float('nan')) for r in sub]
        rts = [r['runtime_s'] for r in sub]
        rep = [r for r in sub if r['seed'] == 1] or sub
        out[m] = dict(
            jm_mean=_mean(objs), jm_std=_std(objs), variance=_var(objs),
            mean_abs_corr=_mean(corrs), runtime=_mean(rts),
            nfe=sub[0]['nfe'], bands=rep[0]['bands_1based'], n=len(sub),
        )
    return out


def agg_classification(run_key: str, k: int = K_MAIN) -> Dict[str, Dict[str, dict]]:
    rows = [r for r in _load_run(run_key, 'classification.jsonl') if r['k'] == k]
    out: Dict[str, Dict[str, dict]] = {}
    for m in METHOD_ORDER:
        out[m] = {}
        for c in CLF_ORDER:
            sub = [r for r in rows if r['method'] == m and r['classifier'] == c]
            if not sub:
                continue
            out[m][c] = dict(
                OA=(_mean([x['OA'] for x in sub]), _std([x['OA'] for x in sub])),
                AA=(_mean([x['AA'] for x in sub]), _std([x['AA'] for x in sub])),
                Kappa=(_mean([x['Kappa'] for x in sub]), _std([x['Kappa'] for x in sub])),
                n=len(sub),
            )
    return out


def agg_robustness() -> Dict[str, Dict[str, float]]:
    res = {}
    for name, rk in [('5cls', '5cls'), ('6cls', '6cls'), ('9cls', '9cls')]:
        rows = [r for r in _load_run(rk, 'classification.jsonl')
                if r['k'] == K_MAIN and r['classifier'] == 'knn5']
        d = {}
        for m in METHOD_ORDER:
            sub = [r for r in rows if r['method'] == m]
            if sub:
                d[m] = _mean([x['OA'] for x in sub])
        res[name] = d
    return res


def agg_ksweep(run_key: str) -> Dict[str, Dict[int, float]]:
    rows = _load_run(run_key, 'classification.jsonl')
    rows = [r for r in rows if r['classifier'] == 'knn5']
    out: Dict[str, Dict[int, float]] = {}
    for m in METHOD_ORDER:
        sub = [r for r in rows if r['method'] == m]
        if not sub:
            continue
        d = {}
        for k in sorted({r['k'] for r in sub}):
            kk = [r for r in sub if r['k'] == k]
            d[k] = _mean([x['OA'] for x in kk])
        out[m] = d
    return out


def build_summary() -> dict:
    return dict(
        selection_5cls=agg_selection('5cls'),
        classification_5cls=agg_classification('5cls'),
        robustness=agg_robustness(),
        ksweep=agg_ksweep('5cls'),
        selection_ip=agg_selection('ip'),
        classification_ip=agg_classification('ip'),
    )


def update_xlsx(summary: dict, xlsx_out: Optional[str] = None) -> None:
    import openpyxl
    xlsx_out = xlsx_out or XLSX
    if not os.path.isfile(XLSX_SRC):
        print('[xlsx] source not found:', XLSX_SRC)
        return
    if not os.path.isfile(xlsx_out):
        shutil.copy(XLSX_SRC, xlsx_out)  # base the new file on the original
    bak = XLSX + '.bak-agg'
    if not os.path.isfile(bak):
        shutil.copy(XLSX, bak)
    wb = openpyxl.load_workbook(XLSX)
    sel = summary['selection_5cls']
    clf = summary['classification_5cls']

    # ---- 波段选择层结果 ----
    ws = wb['波段选择层结果']
    # header row is row 1; data rows 2.. ; col B = 方法(label)
    label_to_row = {}
    for r in range(2, ws.max_row + 1):
        v = ws.cell(r, 2).value
        if v:
            label_to_row[str(v).strip()] = r
    for m in METHOD_ORDER:
        lab = METHOD_LABEL[m]
        if lab not in label_to_row:
            continue
        r = label_to_row[lab]
        s = sel.get(m)
        if not s:
            continue
        ws.cell(r, 4).value = round(s['jm_mean'], 4)      # JM 均值
        ws.cell(r, 5).value = round(s['jm_std'], 4)       # JM 标准差
        ws.cell(r, 6).value = K_MAIN                       # 选中波段数 k
        ws.cell(r, 7).value = ' '.join(str(b) for b in s['bands'])  # 选中波段编号
        ws.cell(r, 8).value = round(s['mean_abs_corr'], 4) if s['mean_abs_corr'] == s['mean_abs_corr'] else None  # 冗余度
        # col 9 平均信息熵 / col 10 OIF: 暂缺（runner 未计算），留空
        ws.cell(r, 11).value = round(s['runtime'], 2)     # 运行时间 s
        ws.cell(r, 12).value = s['nfe']                    # NFE
        # 备注: 标记实测回填
        ws.cell(r, 13).value = (ws.cell(r, 13).value or '') + ' [实测回填]'

    # ---- 分类层结果 ----
    ws2 = wb['分类层结果']
    label_to_row2 = {}
    for r in range(2, ws2.max_row + 1):
        v = ws2.cell(r, 2).value
        if v:
            label_to_row2.setdefault(str(v).strip(), []).append(r)
    for m in METHOD_ORDER:
        lab = METHOD_LABEL[m]
        rows_for_m = label_to_row2.get(lab, [])
        # rows are in classifier order KNN / RBF-SVM / 随机森林 (col D)
        for r in rows_for_m:
            cname = str(ws2.cell(r, 4).value or '').strip()
            cmap = {'KNN': 'knn5', 'RBF-SVM': 'svm_rbf', '随机森林': 'rf'}
            key = cmap.get(cname)
            if not key:
                continue
            cd = clf.get(m, {}).get(key)
            if not cd:
                continue
            ws2.cell(r, 5).value = round(cd['OA'][0], 2)
            ws2.cell(r, 6).value = round(cd['OA'][1], 2)
            ws2.cell(r, 7).value = round(cd['AA'][0], 2)
            ws2.cell(r, 8).value = round(cd['AA'][1], 2)
            ws2.cell(r, 9).value = round(cd['Kappa'][0], 2)
            ws2.cell(r, 10).value = round(cd['Kappa'][1], 2)
            ws2.cell(r, 11).value = (ws2.cell(r, 11).value or '') + ' [实测回填]'

    # ---- 类别子集与稳健性 (appendix) ----
    # Idempotent: remove any pre-existing "实测回填" block before writing one.
    rob = summary['robustness']
    if '类别子集与稳健性' in wb.sheetnames:
        ws3 = wb['类别子集与稳健性']
        # find the first row that holds the回填 block header
        hdr_row = None
        for ri in range(1, ws3.max_row + 1):
            if str(ws3.cell(ri, 1).value or '').startswith('实测回填'):
                hdr_row = ri
                break
        if hdr_row is not None:
            # delete from header to end (covers header + header row + 10 methods + Full-band)
            ws3.delete_rows(hdr_row, ws3.max_row - hdr_row + 1)
        start = ws3.max_row + 2
        ws3.cell(start, 1).value = '实测回填（KNN, k=4, OA %）'
        hdr = ['方法'] + ['5类(C1-C5)', '6类(含水稻)', '9类(全)']
        for j, h in enumerate(hdr, 1):
            ws3.cell(start + 1, j).value = h
        rr = start + 2
        for m in METHOD_ORDER:
            ws3.cell(rr, 1).value = METHOD_LABEL[m]
            for j, key in enumerate(['5cls', '6cls', '9cls'], 2):
                v = rob.get(key, {}).get(m)
                ws3.cell(rr, j).value = round(v, 2) if v is not None else None
            rr += 1

    # ---- Indian Pines classification results (second benchmark) ----
    ip_clf = summary.get('classification_ip', {})
    if ip_clf:
        ip_sheet = 'Indian Pines 分类结果'
        if ip_sheet not in wb.sheetnames:
            ws_ip = wb.create_sheet(ip_sheet)
            ws_ip.append(['方法', '分类器', 'OA', 'OA_std', 'AA', 'AA_std',
                          'Kappa', 'Kappa_std', '备注'])
        else:
            ws_ip = wb[ip_sheet]
            if ws_ip.max_row > 1:
                ws_ip.delete_rows(2, ws_ip.max_row - 1)
        for m in METHOD_ORDER:
            if m == 'Full-band':
                continue
            cd = ip_clf.get(m)
            if not cd:
                continue
            for c in CLF_ORDER:
                d = cd.get(c)
                if not d:
                    continue
                ws_ip.append([METHOD_LABEL[m], CLF_LABEL[c],
                              round(d['OA'][0], 2), round(d['OA'][1], 2),
                              round(d['AA'][0], 2), round(d['AA'][1], 2),
                              round(d['Kappa'][0], 2), round(d['Kappa'][1], 2),
                              ' [实测回填]'])

    wb.save(xlsx_out)
    print('[xlsx] updated ->', xlsx_out, '(backup', bak + ')')


def make_figures(summary: dict) -> None:
    os.makedirs(FIG_DIR, exist_ok=True)
    sel = summary['selection_5cls']
    # Fig 1: convergence of several methods (seed 1, k=4)
    srows = _load_run('5cls', 'selection.jsonl')
    plt.figure(figsize=(6, 4))
    for m in ['PSO', 'SAPSO', 'MPSO', 'IEPSO', 'DESAPSO', 'GA', 'GWO', 'DE']:
        hs = [r for r in srows
              if r['method'] == m and r['seed'] == 1 and r['k'] == K_MAIN]
        if hs:
            plt.plot(hs[0]['history'], label=METHOD_LABEL[m])
    plt.xlabel('NFE evaluation step'); plt.ylabel('JM-sum objective')
    plt.title('Convergence (seed 1, k=4)'); plt.legend(fontsize=7); plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, 'fig_convergence.png'), dpi=130); plt.close()

    # Fig 2: k-sweep OA (KNN)
    ks = sorted({k for m in summary['ksweep'].values() for k in m})
    plt.figure(figsize=(6, 4))
    for m, d in summary['ksweep'].items():
        if not d:
            continue
        xs = sorted(d); plt.plot(xs, [d[k] for k in xs], marker='o', label=METHOD_LABEL[m], ms=3)
    plt.xlabel('Number of selected bands k'); plt.ylabel('OA (%) [KNN]')
    plt.title('Band number vs OA'); plt.legend(fontsize=7); plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, 'fig_ksweep.png'), dpi=130); plt.close()

    # Fig 3: time cost (selection runtime, log scale)
    methods = [m for m in METHOD_ORDER if m in sel]
    rt = [sel[m]['runtime'] for m in methods]
    plt.figure(figsize=(7, 4))
    plt.bar([METHOD_LABEL[m] for m in methods], rt, color='steelblue')
    plt.ylabel('Selection runtime (s, mean of 10 seeds)')
    plt.title('Time cost (NFE=3000 for optimisers; static selectors excluded from NFE)')
    plt.xticks(rotation=45, ha='right', fontsize=7)
    plt.tight_layout(); plt.savefig(os.path.join(FIG_DIR, 'fig_timecost.png'), dpi=130); plt.close()
    print('[fig] saved to', FIG_DIR)


def main():
    import argparse
    ap = argparse.ArgumentParser(description='Aggregate R1-2 runs and back-fill record xlsx + figures.')
    ap.add_argument('--extra-runs', default='',
                    help='Extra run dirs merged in (review mode). Format: "5cls:/p,ip:/q"')
    ap.add_argument('--xlsx-out', default=None,
                    help='Write the back-filled xlsx to this path instead of the canonical one '
                         '(review mode: produce a proposed file without overwriting the original).')
    a = ap.parse_args()
    if a.extra_runs:
        for tok in a.extra_runs.split(','):
            tok = tok.strip()
            if not tok:
                continue
            rk, d = tok.split(':', 1)
            EXTRA_RUNS.setdefault(rk, []).append(d)
    summary = build_summary()
    os.makedirs(os.path.join(ROOT, 'output/runs'), exist_ok=True)
    with open(os.path.join(ROOT, 'output/runs/summary.json'), 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2, default=str)
    # console preview
    print('=== Band-selection layer (5-class, k=4) ===')
    print('%-14s %10s %8s %10s %8s %6s' % ('method', 'JMmean', 'JMstd', 'redund|r|', 'rt(s)', 'NFE'))
    for m in METHOD_ORDER:
        s = summary['selection_5cls'].get(m)
        if s:
            print('%-14s %10.4f %8.4f %10.4f %8.2f %6d' % (
                METHOD_LABEL[m], s['jm_mean'], s['jm_std'], s['mean_abs_corr'], s['runtime'], s['nfe']))
    print('\n=== Classification layer (5-class, k=4, OA%) ===')
    for m in METHOD_ORDER:
        cd = summary['classification_5cls'].get(m, {})
        parts = []
        for c in CLF_ORDER:
            if c in cd:
                parts.append('%s %.2f±%.2f' % (CLF_LABEL[c], cd[c]['OA'][0], cd[c]['OA'][1]))
        if parts:
            print('%-14s %s' % (METHOD_LABEL[m], ' | '.join(parts)))
    print('\n=== Robustness (KNN OA%) ===')
    for key in ['5cls', '6cls', '9cls']:
        print(key, {METHOD_LABEL[m]: round(v, 2) for m, v in summary['robustness'].get(key, {}).items()})
    print('\n=== Indian Pines classification layer (16-class, k=4, OA%) ===')
    for m in METHOD_ORDER:
        cd = summary.get('classification_ip', {}).get(m, {})
        parts = []
        for c in CLF_ORDER:
            if c in cd:
                parts.append('%s %.2f±%.2f' % (CLF_LABEL[c], cd[c]['OA'][0], cd[c]['OA'][1]))
        if parts:
            print('%-14s %s' % (METHOD_LABEL[m], ' | '.join(parts)))
    update_xlsx(summary, xlsx_out=a.xlsx_out)
    make_figures(summary)
    print('\n[done] summary.json + xlsx + figures written.')


if __name__ == '__main__':
    main()
