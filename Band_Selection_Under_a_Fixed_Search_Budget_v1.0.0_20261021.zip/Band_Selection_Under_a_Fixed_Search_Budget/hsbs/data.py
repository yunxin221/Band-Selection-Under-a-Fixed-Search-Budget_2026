"""Dataset container, loaders and a synthetic hyperspectral generator.

The synthetic generator exists so that the whole pipeline can be developed and
self-tested before the real cube is available. Swapping in a real dataset only
requires a loader: nothing above this module knows where the cube came from.
"""
from __future__ import annotations

import os
import struct
from dataclasses import dataclass, field
from typing import Dict, Iterable, Optional, Sequence, Tuple

import numpy as np

__all__ = [
    'HSDataset', 'load_dataset', 'load_envi', 'load_mat', 'load_tif',
    'make_synthetic', 'describe',
]


# --------------------------------------------------------------------- container
@dataclass
class HSDataset:
    """A hyperspectral cube plus its ground truth.

    Parameters
    ----------
    cube : (H, W, B) array
    gt : (H, W) integer array, 0 marks unlabelled pixels
    wavelengths : optional (B,) array in nanometres
    class_names : mapping class id -> readable name
    """

    name: str
    cube: np.ndarray
    gt: np.ndarray
    wavelengths: Optional[np.ndarray] = None
    class_names: Dict[int, str] = field(default_factory=dict)
    meta: Dict[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.cube = np.ascontiguousarray(self.cube, dtype=np.float32)
        gt = np.asarray(self.gt)
        if gt.ndim == 3 and gt.shape[-1] == 1:
            gt = gt[..., 0]
        self.gt = np.ascontiguousarray(np.squeeze(gt), dtype=np.int32)

        if self.cube.ndim != 3:
            raise ValueError('cube must be (H, W, B), got %r' % (self.cube.shape,))
        if self.gt.shape != self.cube.shape[:2]:
            raise ValueError('gt %r does not match cube %r' % (self.gt.shape, self.cube.shape[:2]))
        if self.wavelengths is not None:
            wl = np.asarray(self.wavelengths, dtype=np.float64).ravel()
            if wl.size != self.cube.shape[2]:
                raise ValueError('wavelengths has %d entries, cube has %d bands' % (wl.size, self.cube.shape[2]))
            self.wavelengths = wl
        self.class_names = {int(k): str(v) for k, v in (self.class_names or {}).items()}

    # ------------------------------------------------------------- properties
    @property
    def height(self) -> int:
        return int(self.cube.shape[0])

    @property
    def width(self) -> int:
        return int(self.cube.shape[1])

    @property
    def n_bands(self) -> int:
        return int(self.cube.shape[2])

    @property
    def n_pixels(self) -> int:
        return self.height * self.width

    @property
    def classes(self) -> list:
        return sorted(int(c) for c in np.unique(self.gt) if int(c) != 0)

    def counts(self) -> Dict[int, int]:
        return {c: int((self.gt == c).sum()) for c in self.classes}

    def label_of(self, c: int) -> str:
        return self.class_names.get(int(c), 'class %d' % int(c))

    # ------------------------------------------------------------- views
    def as_matrix(self) -> np.ndarray:
        """(H*W, B) float32 view -- row-major, matches gt.ravel()."""
        return self.cube.reshape(self.n_pixels, self.n_bands)

    def labels(self) -> np.ndarray:
        """(H*W,) int32 view."""
        return self.gt.reshape(self.n_pixels)

    def labeled_mask(self) -> np.ndarray:
        return self.labels() != 0

    # ------------------------------------------------------------- helpers
    def subset(self, bands: Sequence[int]) -> np.ndarray:
        """(H*W, k) matrix restricted to `bands`."""
        idx = np.asarray(list(bands), dtype=np.int64)
        if idx.size == 0:
            raise ValueError('empty band subset')
        if idx.min() < 0 or idx.max() >= self.n_bands:
            raise IndexError('band index out of range 0..%d' % (self.n_bands - 1))
        return self.cube[:, :, idx].reshape(self.n_pixels, idx.size)

    def rgb(self, bands: Optional[Tuple[int, int, int]] = None, stretch: float = 2.0) -> np.ndarray:
        """False-colour composite, percentile stretched to [0, 1]."""
        if bands is None:
            b = self.n_bands
            third = max(1, b // 3)
            bands = (third, 2 * third, min(b - 1, 3 * third)) if b >= 9 else (0, b // 2, b - 1)
        img = self.cube[:, :, list(np.clip(bands, 0, self.n_bands - 1))].astype(np.float32)
        out = np.empty_like(img)
        for i in range(3):
            lo, hi = np.percentile(img[:, :, i], [100 - 100 * 0.995, 99.5]) if stretch else (img[:, :, i].min(), img[:, :, i].max())
            span = max(float(hi - lo), 1e-6)
            out[:, :, i] = np.clip((img[:, :, i] - lo) / span, 0.0, 1.0)
        return out

    def band_indices_1based(self, bands: Sequence[int]) -> list:
        """The paper reports band numbers 1-based."""
        return [int(b) + 1 for b in bands]


# --------------------------------------------------------------------- ENVI
_ENVI_DTYPE = {
    1: 'u1', 2: 'i2', 3: 'i4', 4: 'f4', 5: 'f8', 6: 'c8', 9: 'c16', 12: 'u2', 13: 'u4', 14: 'i8', 15: 'u8',
}
_INTERLEAVE = {'bsq': 0, 'bil': 1, 'bip': 2}


def _read_envi_header(path: str) -> Dict[str, str]:
    with open(path, 'r', encoding='latin-1') as fh:
        raw = fh.read()
    hdr: Dict[str, str] = {}
    body = raw.split('{', 1)[1] if '{' in raw else raw
    for line in body.splitlines():
        line = line.split(';')[0].strip()
        if '=' not in line:
            continue
        key, val = line.split('=', 1)
        hdr[key.strip().lower()] = val.strip()
    return hdr


def load_envi(header_path: str, cube_key: Optional[str] = None) -> np.ndarray:
    """Read an ENVI cube (.hdr + .img/.dat/.bil/...). Returns (H, W, B)."""
    if not os.path.isfile(header_path):
        raise FileNotFoundError(header_path)
    hdr = _read_envi_header(header_path)
    for req in ('samples', 'lines', 'bands', 'data type'):
        if req not in hdr:
            raise ValueError('ENVI header missing required key %r' % req)
    samples = int(hdr['samples'])
    lines = int(hdr['lines'])
    bands = int(hdr['bands'])
    dtype = _ENVI_DTYPE[int(hdr['data type'])]
    interleave = _INTERLEAVE.get(str(hdr.get('interleave', 'bsq')).lower(), 0)

    base = header_path.rsplit('.', 1)[0]
    data_path = None
    for ext in ('.img', '.dat', '.raw', '.bil', '.bsq', '.bip', '.cub', '.cube'):
        if os.path.isfile(base + ext):
            data_path = base + ext
            break
    if data_path is None:
        data_path = str(hdr.get('data file', '')) or base
    if not os.path.isfile(data_path):
        raise FileNotFoundError('ENVI data file not found next to %s' % header_path)

    order = hdr.get('byte order', '0').strip()
    endian = '>' if order == '1' else '<'
    count = samples * lines * bands

    with open(data_path, 'rb') as fh:
        buf = fh.read()
    if struct.calcsize(dtype) * count > len(buf):
        raise ValueError('ENVI data file shorter than header claims (%d < %d bytes)' % (len(buf), struct.calcsize(dtype) * count))

    arr = np.frombuffer(buf, dtype=np.dtype(endian + dtype), count=count)
    if interleave == 0:       # BSQ
        cube = arr.reshape(bands, lines, samples)
    elif interleave == 1:     # BIL
        cube = arr.reshape(lines, bands, samples).transpose(1, 0, 2)
    else:                     # BIP
        cube = arr.reshape(lines, samples, bands).transpose(0, 1, 2)
    return np.ascontiguousarray(cube, dtype=np.float32)


def _envi_wavelengths(header_path: str) -> Optional[np.ndarray]:
    try:
        hdr = _read_envi_header(header_path)
    except Exception:
        return None
    for key in ('wavelength', 'wavelengths', 'wavelength units'):
        if key in hdr and key != 'wavelength units':
            nums = [float(x) for x in hdr[key].replace(',', ' ').split() if _is_number(x)]
            if nums:
                unit = hdr.get('wavelength units', 'nm').strip().lower()
                wl = np.asarray(nums, dtype=np.float64)
                if unit.startswith('um') or unit.startswith('\u00b5m'):
                    wl = wl * 1000.0
                return wl
    return None


def _is_number(tok: str) -> bool:
    try:
        float(tok)
        return True
    except ValueError:
        return False


# --------------------------------------------------------------------- .mat
def load_mat(path: str) -> Dict[str, np.ndarray]:
    """Read a .mat file. Falls back to an explicit error for v7.3 (HDF5)."""
    try:
        from scipy.io import loadmat
        raw = loadmat(path)
    except NotImplementedError as exc:
        raise NotImplementedError(
            'This .mat file is v7.3 (HDF5). Install h5py and re-run, or re-save '
            'the file from MATLAB with -v7.') from exc
    except Exception as exc:                      # pragma: no cover - corrupt file
        raise IOError('cannot read %s: %s' % (path, exc)) from exc
    return {k: v for k, v in raw.items() if not k.startswith('__')}


def load_gt_mat(path: str) -> Dict[str, np.ndarray]:
    return load_mat(path)


# --------------------------------------------------------------------- .tif
def load_tif(path: str) -> np.ndarray:
    import tifffile
    arr = tifffile.imread(path)
    if arr.ndim == 3 and arr.shape[0] < arr.shape[-1] and arr.shape[-1] > 32:
        # (H, W, B) is the convention we want; most writers already use it
        pass
    return np.ascontiguousarray(arr, dtype=np.float32)


# --------------------------------------------------------------------- loader
def load_dataset(path: str, gt_path: Optional[str] = None, name: Optional[str] = None,
                 cube_key: Optional[str] = None, gt_key: Optional[str] = None,
                 class_names: Optional[Dict[int, str]] = None,
                 wavelengths: Optional[Sequence[float]] = None) -> HSDataset:
    """Load a dataset from a single file or a cube/gt pair.

    Supported extensions: .hdr (ENVI, paired with .img), .mat, .npy, .npz, .tif/.tiff.
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    ext = os.path.splitext(path)[1].lower()
    wl = np.asarray(wavelengths, dtype=np.float64) if wavelengths is not None else None

    if ext == '.hdr':
        cube = load_envi(path)
        wl = wl if wl is not None else _envi_wavelengths(path)
        if gt_path is None:
            raise ValueError('an ENVI cube needs an explicit gt_path')
        gt = load_envi(gt_path) if gt_path.lower().endswith('.hdr') else np.load(gt_path)
        gt = gt[..., 0] if gt.ndim == 3 else gt
    elif ext == '.mat':
        cube, gt, wl = _from_mat(path, gt_path, cube_key, gt_key, wl)
    elif ext == '.npz':
        z = np.load(path)
        cube_key = cube_key or next(k for k in z.files if 'gt' not in k.lower())
        gt_key = gt_key or next((k for k in z.files if 'gt' in k.lower()), None)
        cube = z[cube_key]
        if gt_path:
            gt = np.load(gt_path)
        elif gt_key:
            gt = z[gt_key]
        else:
            raise ValueError('no ground truth found in %s (keys=%r)' % (path, z.files))
    elif ext == '.npy':
        cube = np.load(path)
        if gt_path is None:
            raise ValueError('a bare .npy cube needs an explicit gt_path')
        gt = np.load(gt_path)
    elif ext in ('.tif', '.tiff'):
        cube = load_tif(path)
        if gt_path is None:
            raise ValueError('a .tif cube needs an explicit gt_path')
        gt = np.load(gt_path) if gt_path.lower().endswith('.npy') else load_tif(gt_path)
    else:
        raise ValueError('unsupported extension %r' % ext)

    if cube.ndim != 3:
        raise ValueError('expected a 3-D cube, got %r' % (cube.shape,))
    gt_arr = np.asarray(gt)
    if gt_arr.ndim == 3:
        gt_arr = gt_arr[..., 0]

    return HSDataset(name=name or os.path.splitext(os.path.basename(path))[0],
                     cube=cube, gt=gt_arr, wavelengths=wl,
                     class_names=class_names or {},
                     meta={'source': os.path.abspath(path), 'gt': os.path.abspath(gt_path) if gt_path else None})


def _from_mat(path, gt_path, cube_key, gt_key, wl):
    if gt_path:
        cub = load_mat(path)
        g = load_mat(gt_path)
        # NOTE: _largest_3d / _first_2d return the *key*, so index once more.
        cube = cub[cube_key] if cube_key else cub[_largest_3d(cub)]
        gt = g[gt_key] if gt_key else g[_first_2d(g)]
    else:
        both = load_mat(path)
        cube_key = cube_key or _guess_cube_key(both)
        gt_key = gt_key or _guess_gt_key(both, cube_key)
        if cube_key is None or gt_key is None:
            raise ValueError('cannot infer cube/gt keys in %s (keys=%r); pass cube_key/gt_key'
                             % (path, sorted(both)))
        cube = both[cube_key]
        gt = both[gt_key]
        wl = wl if wl is not None else _maybe_wavelengths(both)
    cube = np.squeeze(cube)
    if cube.ndim != 3:
        raise ValueError('cube in %s is not 3-D: %r' % (path, cube.shape))
    return cube, np.squeeze(gt), wl


def _largest_3d(d) -> str:
    cands = [(np.prod(v.shape), k) for k, v in d.items() if np.asarray(v).ndim == 3]
    if not cands:
        raise ValueError('no 3-D array found; keys=%r' % sorted(d))
    return max(cands)[1]


def _first_2d(d) -> str:
    for k, v in sorted(d.items()):
        if np.asarray(v).ndim == 2 and np.issubdtype(np.asarray(v).dtype, np.number):
            return k
    raise ValueError('no 2-D array found; keys=%r' % sorted(d))


def _guess_cube_key(d) -> Optional[str]:
    for k, v in d.items():
        if np.asarray(v).ndim == 3:
            return k
    return None


def _guess_gt_key(d, cube_key: Optional[str]) -> Optional[str]:
    for k, v in d.items():
        if k == cube_key:
            continue
        a = np.asarray(v)
        if a.ndim in (2, 3) and np.issubdtype(a.dtype, np.integer):
            return k
    return None


def _maybe_wavelengths(d) -> Optional[np.ndarray]:
    for k, v in d.items():
        a = np.asarray(v).ravel()
        if 'wave' in k.lower() or 'band' in k.lower() or 'wavelength' in k.lower():
            if a.size >= 8 and np.issubdtype(a.dtype, np.number):
                return a.astype(np.float64)
    return None


# --------------------------------------------------------------------- synthetic
def make_synthetic(height: int = 60, width: int = 60, n_bands: int = 40, n_classes: int = 5,
                   seed: int = 20261015, noise: float = 0.06, sample_ratio: float = 0.6,
                   spatial_smooth: int = 3, wavelength_range: Tuple[float, float] = (400.0, 1000.0),
                   separability: float = 1.0) -> HSDataset:
    """Build a synthetic HSI with `n_classes` spectrally and spatially coherent classes.

    The point is not realism but a *known* optimum: each class has a distinct
    absorption feature, so a correct band selector should pick bands near those
    features. That makes the self-test meaningful rather than decorative.
    """
    rng = np.random.default_rng(seed)
    if height < n_classes or width < n_classes:
        raise ValueError('image smaller than the number of classes')

    wavelengths = np.linspace(wavelength_range[0], wavelength_range[1], n_bands)
    wl_norm = (wavelengths - wavelengths[0]) / max(wavelengths[-1] - wavelengths[0], 1e-9)

    # --- per-class target spectra: a Gaussian absorption dip at a distinct position
    centres = np.linspace(0.10, 0.90, n_classes)
    widths = np.full(n_classes, 0.030)
    spectra = np.empty((n_classes, n_bands), dtype=np.float32)
    for c in range(n_classes):
        dip = np.exp(-0.5 * ((wl_norm - centres[c]) / widths[c]) ** 2)
        baseline = 0.55 + 0.25 * np.sin(2 * np.pi * (wl_norm + 0.3 * c))
        spectra[c] = (baseline - separability * 0.55 * dip).astype(np.float32)

    # --- spatial layout: blocky regions per class (nearest-centroid Voronoi)
    gy, gx = np.mgrid[0:height, 0:width]
    seeds_y = rng.uniform(0.12 * height, 0.88 * height, size=n_classes)
    seeds_x = rng.uniform(0.12 * width, 0.88 * width, size=n_classes)
    d2 = (gy[..., None] - seeds_y) ** 2 + (gx[..., None] - seeds_x) ** 2
    region = np.argmin(d2, axis=-1)

    # --- random spatial jitter so boundaries are not perfectly clean
    flip = rng.random((height, width)) < 0.06
    region = np.where(flip, rng.integers(0, n_classes, size=(height, width)), region)

    # --- a background ring treated as unlabelled (gt == 0)
    dist = np.sqrt(d2[np.arange(height)[:, None], np.arange(width)[None, :], region])
    gt = (region + 1).astype(np.int32)
    gt[dist > 0.34 * max(height, width)] = 0

    # --- build the cube
    cube = np.empty((height, width, n_bands), dtype=np.float32)
    for c in range(n_classes):
        m = gt == (c + 1)
        if not m.any():
            continue
        n = int(m.sum())
        block = np.repeat(spectra[c][None, :], n, axis=0)
        block = block + rng.normal(0.0, noise, size=(n, n_bands)).astype(np.float32)
        # mild class-dependent brightness drift, as in real UAV imagery
        block = block * (1.0 + 0.04 * c)
        cube[m] = block
    cube[gt == 0] = 0.0

    if spatial_smooth and spatial_smooth > 1:
        from scipy.ndimage import uniform_filter
        smooth = uniform_filter(cube, size=(spatial_smooth, spatial_smooth, 1), mode='nearest')
        # keep ground truth pixels crisp, blend only a little
        cube = (0.85 * cube + 0.15 * smooth).astype(np.float32)

    names = {c + 1: 'synthetic class %d' % (c + 1) for c in range(n_classes)}
    ds = HSDataset(name='SYNTHETIC_%dx%dx%d' % (height, width, n_bands),
                   cube=cube, gt=gt, wavelengths=wavelengths, class_names=names,
                   meta={'synthetic': True, 'seed': seed, 'noise': noise,
                         'absorption_centres_nm': (centres * (wavelength_range[1] - wavelength_range[0]) + wavelength_range[0]).tolist(),
                         'sample_ratio': sample_ratio})
    return ds


def true_informative_bands(ds: HSDataset, tol: float = 0.08, top: int = 1) -> list:
    """Bands nearest each class absorption centre -- the expected optimum set."""
    centres = ds.meta.get('absorption_centres_nm')
    if not centres or ds.wavelengths is None:
        return []
    picked = []
    span = ds.wavelengths[-1] - ds.wavelengths[0]
    for c in centres:
        d = np.abs(ds.wavelengths - c)
        order = np.argsort(d)
        for b in order[:top]:
            if int(b) not in picked:
                picked.append(int(b))
    return sorted(picked)


# --------------------------------------------------------------------- describe
def describe(ds: HSDataset) -> str:
    lines = ['dataset : %s' % ds.name,
             'cube    : %d x %d x %d' % (ds.height, ds.width, ds.n_bands),
             'classes : %d' % len(ds.classes)]
    if ds.wavelengths is not None:
        lines.append('wavelengths : %.1f .. %.1f nm (%.2f nm step)'
                     % (ds.wavelengths[0], ds.wavelengths[-1],
                        (ds.wavelengths[-1] - ds.wavelengths[0]) / max(ds.n_bands - 1, 1)))
    counts = ds.counts()
    total = sum(counts.values())
    for c in ds.classes:
        lines.append('   %-4s %-28s %7d  (%.2f%%)' % (c, ds.label_of(c), counts[c], 100.0 * counts[c] / max(total, 1)))
    lines.append('   %-33s %7d' % ('labelled total', total))
    return '\n'.join(lines)
