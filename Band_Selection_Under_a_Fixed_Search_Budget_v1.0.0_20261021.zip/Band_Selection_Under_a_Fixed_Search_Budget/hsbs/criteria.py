"""Objective functions for band selection.

Two things matter here and both are deliberately configurable.

1. The *definition* of the objective. The manuscript reports a mean JM of
   13.6169 (SPSO) / 13.6763 (SAPSO) on WHU-Hi-LongKou. A single pairwise JM
   value is bounded by sqrt(2) ~= 1.4142, so 13.6 cannot be an average over
   pairs. It is consistent with a **sum over the 10 class pairs** of a 5-class
   problem (ceiling 14.1421, i.e. 96.3% of the ceiling). `probe_scale()` below
   makes that check explicit; `FitnessSpec.reduce` switches between the
   candidate conventions so the original numbers can be reproduced exactly
   once the author's code is available.

2. The *plugin point*. Every optimiser only ever sees a callable
   `f(band_indices) -> float`. Swapping the criterion does not touch any
   optimiser.
"""
from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

__all__ = [
    'bhattacharyya_distance', 'jm_distance', 'pairwise_jm', 'band_correlation',
    'redundancy_metrics', 'FitnessSpec', 'build_fitness', 'probe_scale',
    'JM_CEILING', 'explain_scale',
]

JM_CEILING = math.sqrt(2.0)


# --------------------------------------------------------------------- distance
def bhattacharyya_distance(x1: np.ndarray, x2: np.ndarray, reg: float = 1e-6) -> float:
    """Bhattacharyya distance between two samples (rows are observations)."""
    x1 = np.asarray(x1, dtype=np.float64)
    x2 = np.asarray(x2, dtype=np.float64)
    if x1.ndim == 1:
        x1 = x1[None, :]
    if x2.ndim == 1:
        x2 = x2[None, :]
    n1, d = x1.shape
    n2 = x2.shape[0]
    if n1 < 2 or n2 < 2:
        return 0.0
    mu1, mu2 = x1.mean(axis=0), x2.mean(axis=0)
    s1 = np.cov(x1, rowvar=False, bias=True).reshape(d, d)
    s2 = np.cov(x2, rowvar=False, bias=True).reshape(d, d)
    sm = 0.5 * (s1 + s2)
    eye = np.eye(d)
    scale = max(float(np.trace(sm)) / d, 1e-12)
    s1 = s1 + reg * scale * eye
    s2 = s2 + reg * scale * eye
    sm = sm + reg * scale * eye

    # NOTE: keep everything 1-D -- NumPy 2 refuses float() on a (1,1) array.
    diff = (mu1 - mu2).ravel()
    try:
        sol = np.linalg.solve(sm, diff)
        term1 = 0.125 * float(diff @ sol)
    except np.linalg.LinAlgError:                                    # pragma: no cover
        term1 = 0.125 * float(diff @ np.linalg.pinv(sm) @ diff)

    sign_m, logdet_m = np.linalg.slogdet(sm)
    sign_1, logdet_1 = np.linalg.slogdet(s1)
    sign_2, logdet_2 = np.linalg.slogdet(s2)
    if min(sign_m, sign_1, sign_2) <= 0:
        return float(max(term1, 0.0))
    term2 = 0.5 * (logdet_m - 0.5 * (logdet_1 + logdet_2))
    return float(term1) if term1 + term2 < 0 else float(term1 + term2)


def jm_distance(x1: np.ndarray, x2: np.ndarray, reg: float = 1e-6) -> float:
    """Jeffries-Matusita distance in [0, sqrt(2)]."""
    b = bhattacharyya_distance(x1, x2, reg=reg)
    val = 2.0 * (1.0 - math.exp(-max(b, 0.0)))
    return float(math.sqrt(max(val, 0.0)))


def pairwise_jm(X: np.ndarray, y: np.ndarray, classes: Optional[Sequence[int]] = None,
                reduce: str = 'sum', reg: float = 1e-6,
                max_per_class: Optional[int] = None,
                rng: Optional[np.random.Generator] = None) -> Tuple[float, int]:
    """Pairwise JM over class pairs on the matrix X (n_samples, k).

    Returns (value, n_pairs). `reduce` is one of 'sum', 'mean', 'max'.
    """
    X = np.asarray(X, dtype=np.float64)
    y = np.asarray(y).ravel()
    if X.ndim == 1:
        X = X[:, None]
    classes = list(classes) if classes is not None else sorted(int(c) for c in np.unique(y) if c != 0)
    if len(classes) < 2:
        return 0.0, 0

    pools: Dict[int, np.ndarray] = {}
    for c in classes:
        m = y == c
        if not m.any():
            continue
        rows = X[m]
        if max_per_class is not None and rows.shape[0] > max_per_class:
            pick = rng if rng is not None else np.random.default_rng(0)
            sel = pick.choice(rows.shape[0], size=int(max_per_class), replace=False)
            rows = rows[np.sort(sel)]
        pools[c] = rows
    live = sorted(pools)
    if len(live) < 2:
        return 0.0, 0

    vals = [jm_distance(pools[a], pools[b], reg=reg) for a, b in itertools.combinations(live, 2)]
    n_pairs = len(vals)
    if reduce == 'sum':
        return float(np.sum(vals)), n_pairs
    if reduce == 'mean':
        return float(np.mean(vals)), n_pairs
    if reduce == 'max':
        return float(np.max(vals)), n_pairs
    raise ValueError("reduce must be 'sum', 'mean' or 'max', got %r" % reduce)


# --------------------------------------------------------------------- redundancy
def band_correlation(X: np.ndarray) -> np.ndarray:
    """Absolute Pearson correlation matrix between the columns of X."""
    X = np.asarray(X, dtype=np.float64)
    if X.shape[1] < 2:
        return np.ones((X.shape[1], X.shape[1]))
    Xc = X - X.mean(axis=0, keepdims=True)
    sd = Xc.std(axis=0)
    sd[sd < 1e-12] = 1e-12
    Z = Xc / sd
    r = (Z.T @ Z) / max(Z.shape[0] - 1, 1)
    return np.abs(np.clip(r, -1.0, 1.0))


def redundancy_metrics(X: np.ndarray) -> Dict[str, float]:
    r = band_correlation(X)
    k = r.shape[0]
    if k < 2:
        return {'mean_abs_corr': 0.0, 'max_abs_corr': 0.0, 'mean_sq_corr': 0.0}
    iu = np.triu_indices(k, k=1)
    off = r[iu]
    return {'mean_abs_corr': float(off.mean()),
            'max_abs_corr': float(off.max()),
            'mean_sq_corr': float((off ** 2).mean())}


# --------------------------------------------------------------------- fitness spec
@dataclass
class FitnessSpec:
    """How to turn a band subset into a scalar objective (to be *maximised*)."""

    reduce: str = 'sum'
    """'sum' (manuscript-consistent), 'mean' or 'max' over class pairs."""

    normalize: str = 'none'
    """'none', 'zscore' (per band) or 'minmax' (per band)."""

    reg: float = 1e-6
    """Ridge added to the covariance matrices before inversion."""

    redundancy_penalty: float = 0.0
    """0.0 reproduces the manuscript (pure JM); >0 subtracts correlated-band mass."""

    max_eval_per_class: Optional[int] = None
    """Cap training pixels per class inside the criterion (speed vs fidelity)."""

    require_exact_k: Optional[int] = None
    """If set, a subset of a different size scores -inf (the harness usually repairs first)."""

    name: str = 'JM-sum'

    def as_dict(self) -> Dict[str, object]:
        return {'reduce': self.reduce, 'normalize': self.normalize, 'reg': self.reg,
                'redundancy_penalty': self.redundancy_penalty,
                'max_eval_per_class': self.max_eval_per_class,
                'require_exact_k': self.require_exact_k, 'name': self.name}

    def clone_with(self, **overrides) -> 'FitnessSpec':
        """Return a copy with the given (known) fields overridden.

        Used to give one band-selection method a different objective (e.g. the
        contribution-(ii) redundancy-penalty term) without forking the whole run
        config -- the run still shares one baseline FitnessSpec, and only the
        methods listed in ``SelectionConfig.method_fitness`` get a tailored copy.
        """
        d = self.as_dict()
        known = set(FitnessSpec.__dataclass_fields__)
        for k, v in overrides.items():
            if k in known:
                d[k] = v
        return FitnessSpec(**d)


def _preprocess(X: np.ndarray, mode: str) -> np.ndarray:
    X = np.asarray(X, dtype=np.float64)
    if mode == 'none':
        return X
    if mode == 'zscore':
        mu = X.mean(axis=0, keepdims=True)
        sd = X.std(axis=0, keepdims=True)
        sd[sd < 1e-12] = 1e-12
        return (X - mu) / sd
    if mode == 'minmax':
        lo = X.min(axis=0, keepdims=True)
        hi = X.max(axis=0, keepdims=True)
        span = hi - lo
        span[span < 1e-12] = 1e-12
        return (X - lo) / span
    raise ValueError('unknown normalize mode %r' % mode)


@dataclass
class FitnessFunction:
    """Callable objective carrying its own evaluation counter."""

    matrix: np.ndarray                 # (n_train, B) raw training pixels
    labels: np.ndarray                 # (n_train,)
    spec: FitnessSpec
    classes: List[int] = field(default_factory=list)
    nfe: int = 0
    _cache: Dict[Tuple[int, ...], float] = field(default_factory=dict, repr=False)

    def __post_init__(self) -> None:
        self.matrix = np.asarray(self.matrix, dtype=np.float64)
        self.labels = np.asarray(self.labels).ravel()
        if self.matrix.shape[0] != self.labels.size:
            raise ValueError('matrix rows (%d) != labels (%d)' % (self.matrix.shape[0], self.labels.size))
        if not self.classes:
            self.classes = sorted(int(c) for c in np.unique(self.labels) if c != 0)
        self._prep = _preprocess(self.matrix, self.spec.normalize)

    # ---------------------------------------------------------------- call
    def __call__(self, bands: Sequence[int]) -> float:
        key = tuple(int(b) for b in bands)
        hit = self._cache.get(key)
        if hit is not None:
            return hit
        self.nfe += 1
        if self.spec.require_exact_k is not None and len(key) != self.spec.require_exact_k:
            self._cache[key] = float('-inf')
            return float('-inf')
        if len(set(key)) != len(key):
            self._cache[key] = float('-inf')
            return float('-inf')

        sub = self._prep[:, list(key)]
        val, _ = pairwise_jm(sub, self.labels, classes=self.classes,
                             reduce=self.spec.reduce, reg=self.spec.reg,
                             max_per_class=self.spec.max_eval_per_class)
        if self.spec.redundancy_penalty:
            red = redundancy_metrics(sub)['mean_abs_corr']
            val = val - self.spec.redundancy_penalty * red * (1.0 + abs(val))
        self._cache[key] = float(val)
        return float(val)

    # ---------------------------------------------------------------- extras
    def components(self, bands: Sequence[int]) -> Dict[str, object]:
        """Full diagnostic breakdown for one subset (not counted against NFE)."""
        key = [int(b) for b in bands]
        sub = self._prep[:, key]
        raw = self.matrix[:, key]
        red = redundancy_metrics(sub)
        jm_by_pair: Dict[str, float] = {}
        pools = {c: sub[self.labels == c] for c in self.classes if (self.labels == c).any()}
        for a, b in itertools.combinations(sorted(pools), 2):
            jm_by_pair['%d-%d' % (a, b)] = jm_distance(pools[a], pools[b], reg=self.spec.reg)
        return {'bands_0based': key,
                'bands_1based': [b + 1 for b in key],
                'k': len(key),
                'objective': float(self(key)) if len(key) else 0.0,
                'jm_mean': float(np.mean(list(jm_by_pair.values()))) if jm_by_pair else 0.0,
                'jm_max': float(np.max(list(jm_by_pair.values()))) if jm_by_pair else 0.0,
                'jm_min': float(np.min(list(jm_by_pair.values()))) if jm_by_pair else 0.0,
                'jm_pairs': jm_by_pair,
                'n_pairs': len(jm_by_pair),
                **red,
                'raw_mean': float(raw.mean()),
                'raw_std': float(raw.std())}

    @property
    def cache_hits(self) -> int:
        return len(self._cache)

    @property
    def n_pairs(self) -> int:
        n = len(self.classes)
        return n * (n - 1) // 2


def build_fitness(ds, train_idx: Sequence[int], spec: Optional[FitnessSpec] = None) -> FitnessFunction:
    """Convenience wrapper: dataset + training pixel indices -> FitnessFunction."""
    spec = spec or FitnessSpec()
    mat = ds.as_matrix()
    labels = ds.labels()
    tr = np.asarray(list(train_idx), dtype=np.int64)
    return FitnessFunction(matrix=mat[tr], labels=labels[tr], spec=spec, classes=list(ds.classes))


# --------------------------------------------------------------------- scale probe
def probe_scale(target: float, n_classes: int, labels: Optional[np.ndarray] = None) -> Dict[str, object]:
    """Check which JM aggregation convention can produce `target`.

    A single JM is capped at sqrt(2). Aggregating over P class pairs caps the
    objective at P * sqrt(2) (sum) / sqrt(2) (mean|max). Reporting the ratio to
    the ceiling tells immediately whether 'mean' is even possible.
    """
    if labels is not None:
        live = sorted(int(c) for c in np.unique(np.asarray(labels)) if int(c) != 0)
        n_classes = len(live)
    p = n_classes * (n_classes - 1) // 2
    ceiling_sum = p * JM_CEILING
    out = {
        'target': float(target),
        'n_classes': int(n_classes),
        'n_pairs': int(p),
        'ceiling_mean': JM_CEILING,
        'ceiling_sum': ceiling_sum,
        'target_over_ceiling_sum': float(target) / max(ceiling_sum, 1e-12),
        'target_over_ceiling_mean': float(target) / JM_CEILING,
    }
    if target <= JM_CEILING + 1e-9:
        out['consistent_with'] = ['mean', 'sum', 'max']
    elif target <= ceiling_sum + 1e-9:
        out['consistent_with'] = ['sum']
    else:
        out['consistent_with'] = []
    return out


def explain_scale(target: float = 13.6169, n_classes: int = 5) -> str:
    """Human-readable version of probe_scale() for the manuscript's numbers."""
    p = probe_scale(target, n_classes)
    lines = ['target JM value          : %.4f' % p['target'],
             'classes / class pairs    : %d / %d' % (p['n_classes'], p['n_pairs']),
             'ceiling for mean | max   : %.4f' % p['ceiling_mean'],
             'ceiling for sum          : %.4f' % p['ceiling_sum'],
             'ratio to sum ceiling     : %.4f  (%.1f%% of maximum separable)' % (
                 p['target_over_ceiling_sum'], 100 * p['target_over_ceiling_sum']),
             'compatible conventions   : %s' % (', '.join(p['consistent_with']) or 'NONE')]
    if p['consistent_with'] == ['sum']:
        lines.append('=> a mean/max aggregation is arithmetically impossible; use reduce=\'sum\'.')
    elif not p['consistent_with']:
        lines.append('=> exceeds every ceiling: the objective is scaled or includes a penalty term.')
    return '\n'.join(lines)
