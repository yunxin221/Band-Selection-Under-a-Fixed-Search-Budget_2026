"""Figure and table generation.

Figures are written as vector PDF (for the manuscript) plus a 300 dpi PNG
preview. Tables are emitted in three flavours at once: Markdown, HTML and
LaTeX booktabs, so the same object can be dropped into the reply letter, the
revision-note document and the manuscript itself.
"""
from __future__ import annotations

import os
from typing import Dict, Iterable, List, Optional, Sequence

import numpy as np

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

__all__ = ['ensure_dir', 'save_fig', 'three_line_table', 'write_table',
           'plot_convergence', 'plot_oa_vs_k', 'plot_runtime_vs_oa',
           'plot_classification_map', 'plot_metric_boxplot', 'plot_confusion',
           'plot_rank_cd', 'set_style']

PALETTE = ['#185FA5', '#993C1D', '#0F6E56', '#7F77DD', '#854F0B', '#993556', '#5F5E5A', '#3B6D11']
MARKERS = ['o', 's', '^', 'v', 'D', 'P', 'X', '*']


def set_style() -> None:
    plt.rcParams.update({
        'figure.dpi': 110,
        'savefig.dpi': 300,
        'font.family': 'sans-serif',
        'font.sans-serif': ['DejaVu Sans', 'Arial', 'Helvetica'],
        'font.size': 9,
        'axes.titlesize': 10,
        'axes.labelsize': 9,
        'axes.linewidth': 0.6,
        'axes.grid': True,
        'grid.linewidth': 0.4,
        'grid.alpha': 0.35,
        'legend.fontsize': 8,
        'legend.frameon': False,
        'xtick.labelsize': 8,
        'ytick.labelsize': 8,
        'lines.linewidth': 1.4,
        'lines.markersize': 4,
        'figure.autolayout': True,
    })


def ensure_dir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path


def save_fig(fig, path_no_ext: str, formats: Sequence[str] = ('pdf', 'png')) -> List[str]:
    """Save a figure next to `path_no_ext`. Returns the paths written."""
    out = []
    base = os.path.splitext(path_no_ext)[0]
    ensure_dir(os.path.dirname(base) or '.')
    for fmt in formats:
        p = '%s.%s' % (base, fmt)
        fig.savefig(p, format=fmt, bbox_inches='tight')
        out.append(p)
    plt.close(fig)
    return out


# --------------------------------------------------------------------- tables
def three_line_table(headers: Sequence[str], rows: Sequence[Sequence[object]],
                     caption: str = '', label: str = '') -> Dict[str, str]:
    """Booktabs-style table in Markdown / HTML / LaTeX."""
    h = [str(x) for x in headers]
    r = [[('' if c is None else str(c)) for c in row] for row in rows]
    ncol = len(h)
    r = [row + [''] * (ncol - len(row)) if len(row) < ncol else row[:ncol] for row in r]

    def cap(kind: str) -> str:
        if not caption:
            return ''
        if kind == 'md':
            return '**%s**\n\n' % caption
        if kind == 'html':
            return '<caption>%s</caption>' % caption
        return ''

    md = cap('md') + '| ' + ' | '.join(h) + ' |\n|' + '|'.join(['---'] * ncol) + '|\n'
    md += '\n'.join('| ' + ' | '.join(row) + ' |' for row in r)

    html = '<table>%s<thead><tr>%s</tr></thead><tbody>%s</tbody></table>' % (
        cap('html'), ''.join('<th>%s</th>' % x for x in h),
        ''.join('<tr>%s</tr>' % ''.join('<td>%s</td>' % x for x in row) for row in r))

    tex = ['\\begin{table}[htbp]', '\\centering']
    if caption:
        tex.append('\\caption{%s}' % caption)
    if label:
        tex.append('\\label{%s}' % label)
    tex.append('\\begin{tabular}{%s}' % ('l' + 'c' * (ncol - 1)))
    tex.append('\\toprule')
    tex.append(' & '.join(h) + ' \\\\')
    tex.append('\\midrule')
    for row in r:
        tex.append(' & '.join(row) + ' \\\\')
    tex += ['\\bottomrule', '\\end{tabular}', '\\end{table}']
    return {'markdown': md, 'html': html, 'latex': '\n'.join(tex)}


def write_table(path: str, headers: Sequence[str], rows: Sequence[Sequence[object]],
                caption: str = '', label: str = '', fmt: str = 'markdown') -> str:
    t = three_line_table(headers, rows, caption=caption, label=label)
    ensure_dir(os.path.dirname(path) or '.')
    ext = os.path.splitext(path)[1].lower()
    if ext in ('.md', '.markdown'):
        body = t['markdown']
    elif ext in ('.html', '.htm'):
        body = t['html']
    elif ext == '.tex':
        body = t['latex']
    elif ext == '.csv':
        body = '\n'.join([','.join(str(x) for x in headers)] +
                         [','.join('"%s"' % str(c).replace('"', '""') for c in row) for row in rows])
    else:
        body = t[fmt]
    with open(path, 'w', encoding='utf-8') as fh:
        fh.write(body + '\n')
    return path


# --------------------------------------------------------------------- figures
def _axis_style(ax, xlabel='', ylabel='', title=''):
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title)
    for side in ('top', 'right'):
        ax.spines[side].set_visible(False)


def plot_convergence(histories: Dict[str, Sequence[float]], out_path: str,
                     title: str = '', xlabel: str = 'Iteration',
                     ylabel: str = 'Objective value (best so far)',
                     max_points: int = 400) -> str:
    set_style()
    fig, ax = plt.subplots(figsize=(4.6, 3.1))
    for i, (name, hist) in enumerate(histories.items()):
        y = np.asarray(hist, dtype=np.float64)
        if y.size == 0:
            continue
        if y.size > max_points:
            sel = np.unique(np.linspace(0, y.size - 1, max_points).astype(int))
            y = y[sel]
            x = sel
        else:
            x = np.arange(y.size)
        y = np.maximum.accumulate(y)
        ax.plot(x, y, color=PALETTE[i % len(PALETTE)], marker=MARKERS[i % len(MARKERS)],
                markevery=max(1, len(x) // 8), label=name)
    _axis_style(ax, xlabel, ylabel, title)
    if histories:
        ax.legend(loc='lower right')
    return save_fig(fig, out_path)[0]


def plot_oa_vs_k(curves: Dict[str, Sequence[float]], k_values: Sequence[int], out_path: str,
                 title: str = '', ylabel: str = 'OA (%)') -> str:
    set_style()
    fig, ax = plt.subplots(figsize=(4.6, 3.1))
    for i, (name, vals) in enumerate(curves.items()):
        ax.plot(list(k_values), np.asarray(vals, dtype=np.float64),
                color=PALETTE[i % len(PALETTE)], marker=MARKERS[i % len(MARKERS)], label=name)
    _axis_style(ax, 'Number of selected bands k', ylabel, title)
    ax.legend(loc='best')
    return save_fig(fig, out_path)[0]


def plot_runtime_vs_oa(runtime: Dict[str, float], oa: Dict[str, float], out_path: str,
                       title: str = '', annotate: bool = True) -> str:
    """Scatter used to compare paradigms: iterative search vs one-shot solutions."""
    set_style()
    fig, ax = plt.subplots(figsize=(4.6, 3.1))
    for i, name in enumerate(runtime):
        if name not in oa:
            continue
        ax.scatter(runtime[name], oa[name], color=PALETTE[i % len(PALETTE)],
                   marker=MARKERS[i % len(MARKERS)], s=34, zorder=3, label=name)
        if annotate:
            ax.annotate(name, (runtime[name], oa[name]), textcoords='offset points',
                        xytext=(5, 3), fontsize=7)
    _axis_style(ax, 'Runtime (s)', 'OA (%)', title)
    return save_fig(fig, out_path)[0]


def plot_classification_map(pred_map: np.ndarray, gt: np.ndarray, out_path: str,
                            class_names: Optional[Dict[int, str]] = None,
                            title: str = '', ncols: int = 3,
                            panels: Optional[Dict[str, np.ndarray]] = None) -> str:
    """Draw one or several classification maps plus the ground truth."""
    set_style()
    items = []
    if gt is not None:
        items.append(('Ground truth', gt))
    if panels:
        items.extend(list(panels.items()))
    elif pred_map is not None:
        items.append((title or 'Prediction', pred_map))
    n = len(items)
    ncols = min(ncols, max(n, 1))
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(2.9 * ncols, 2.7 * nrows), squeeze=False)

    classes = set()
    for _, m in items:
        classes |= {int(c) for c in np.unique(m) if int(c) != 0}
    classes = sorted(classes)
    cmap = plt.get_cmap('tab20')
    lut = {c: cmap(i % 20) for i, c in enumerate(classes)}
    lut[0] = (1.0, 1.0, 1.0, 1.0)

    for ax in axes.ravel():
        ax.axis('off')
    for i, (name, m) in enumerate(items):
        ax = axes.ravel()[i]
        rgb = np.ones(m.shape + (3,), dtype=np.float32)
        for c in classes:
            mask = m == c
            if mask.any():
                rgb[mask] = lut[c][:3]
        ax.imshow(rgb)
        ax.set_title(name, fontsize=8)
    handles = [plt.Rectangle((0, 0), 1, 1, facecolor=lut[c][:3],
                             label=(class_names or {}).get(c, 'class %d' % c)) for c in classes]
    if handles:
        fig.legend(handles=handles, loc='lower center', ncol=min(len(handles), 6), fontsize=7,
                   bbox_to_anchor=(0.5, -0.02))
    return save_fig(fig, out_path)[0]


def plot_metric_boxplot(data: Dict[str, Sequence[float]], out_path: str,
                        title: str = '', ylabel: str = 'OA (%)') -> str:
    set_style()
    fig, ax = plt.subplots(figsize=(4.6, 3.1))
    names = list(data)
    vals = [np.asarray(data[n], dtype=np.float64) for n in names]
    try:
        bp = ax.boxplot(vals, tick_labels=names, patch_artist=True, widths=0.55)
    except TypeError:                              # matplotlib < 3.9
        bp = ax.boxplot(vals, labels=names, patch_artist=True, widths=0.55)
    for i, box in enumerate(bp['boxes']):
        box.set_facecolor(PALETTE[i % len(PALETTE)])
        box.set_alpha(0.35)
        box.set_edgecolor(PALETTE[i % len(PALETTE)])
    for med in bp['medians']:
        med.set_color('#2C2C2A')
        med.set_linewidth(1.2)
    _axis_style(ax, '', ylabel, title)
    ax.tick_params(axis='x', labelrotation=20)
    return save_fig(fig, out_path)[0]


def plot_confusion(cm: np.ndarray, labels: Sequence[int], out_path: str,
                   title: str = 'Confusion matrix', normalize: bool = True) -> str:
    set_style()
    cm = np.asarray(cm, dtype=np.float64)
    if normalize:
        row = cm.sum(axis=1, keepdims=True)
        row[row == 0] = 1
        cm = cm / row
    fig, ax = plt.subplots(figsize=(3.4, 3.0))
    im = ax.imshow(cm, cmap='Blues', vmin=0, vmax=1)
    ax.set_xticks(range(len(labels)), [str(c) for c in labels])
    ax.set_yticks(range(len(labels)), [str(c) for c in labels])
    ax.set_xlabel('Predicted')
    ax.set_ylabel('True')
    ax.set_title(title)
    ax.grid(False)
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            if cm[i, j] > 0.005:
                ax.text(j, i, '%.2f' % cm[i, j], ha='center', va='center',
                        fontsize=6.5, color='white' if cm[i, j] > 0.55 else '#2C2C2A')
    fig.colorbar(im, ax=ax, fraction=0.046)
    return save_fig(fig, out_path)[0]


def plot_rank_cd(avg_ranks: Dict[str, float], cd: float, out_path: str,
                 title: str = 'Average ranks (Nemenyi)', higher_rank_better: bool = False) -> str:
    """Classic Demsar-style rank axis with the critical-difference bar."""
    set_style()
    names = sorted(avg_ranks, key=lambda n: avg_ranks[n])
    fig, ax = plt.subplots(figsize=(5.0, 0.55 + 0.34 * len(names)))
    ranks = np.array([avg_ranks[n] for n in names], dtype=np.float64)
    ax.set_xlim(0.5, len(names) + 0.5)
    ax.set_ylim(-0.9, len(names) - 0.4)
    ax.set_yticks([])
    ax.set_xticks(range(1, len(names) + 1))
    ax.set_xlabel('Average rank (1 = best)')
    ax.grid(axis='x', alpha=0.3)
    for side in ('top', 'right', 'left'):
        ax.spines[side].set_visible(False)
    y0 = 0.0
    ax.plot([1, len(names)], [y0, y0], color='#5F5E5A', lw=0.8)
    for i, (n, r) in enumerate(zip(names, ranks)):
        y = i + 0.35
        ax.plot([r, r], [y0, y], color=PALETTE[i % len(PALETTE)], lw=1.0)
        ax.plot([r], [y], marker='o', color=PALETTE[i % len(PALETTE)], ms=4)
        ax.text(r, y + 0.16, '%s (%.2f)' % (n, r), ha='center', va='bottom', fontsize=7.5)
    best = float(ranks.min())
    ax.plot([best, min(best + cd, len(names))], [y0 + 0.28] * 2, color='#A32D2D', lw=2.0)
    ax.text(best + cd / 2, y0 + 0.42, 'CD = %.2f' % cd, ha='center', va='bottom',
            fontsize=7.5, color='#A32D2D')
    ax.set_title(title, fontsize=9)
    return save_fig(fig, out_path)[0]
