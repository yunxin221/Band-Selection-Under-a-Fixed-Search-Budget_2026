# -*- coding: utf-8 -*-
"""Fill the four missing cells of manuscript Table 6.

Table 6 currently reports, for the compact layout (SAPSO k = 4, protocol A,
dim = k + F), only the EMP row. The EPF and Gabor rows exist for the full-band
layout but were never computed for the selected-band layout, which is exactly
the row the manuscript's strongest engineering claim rests on (28-dim compact
vector reaching 96.63 on LongKou).

This script computes SAPSO k = 4 x {morph(EMP), epf, gabor} x {LongKou, IP}
x {knn5, svm_rbf, rf} x 10 seeds under protocol A.

The morph/EMP rows are recomputed on purpose: they must reproduce
output/runs/sapso3_protocolA.json (already in the manuscript) to two decimals.
If they do not, the new EPF/Gabor rows are not trustworthy and must not be
used.

Does not overwrite any existing result file.
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = HERE
sys.path.insert(0, HERE)

import batch7_8_run as B  # noqa: E402
from hsbs import evaluate, spatial as hssp  # noqa: E402

CLFS = ['knn5', 'svm_rbf', 'rf']
JOBS = [
    ('WHU-Hi-LongKou', 'configs/longkou.json', 'output/runs/longkou_5cls', 'SAPSO'),
    ('Indian Pines', 'configs/indian_pines.json', 'output/runs/indian_pines', 'SAPSO'),
]
# index in B.DEFAULT_SPATIAL -> 0 morph(EMP), 1 epf, 2 gabor
OPS = [('EMP', 0), ('EPF', 1), ('Gabor', 2)]


def agg(vals):
    v = np.asarray(vals, dtype=np.float64)
    return {'OA_mean': float(v.mean()),
            'OA_std': float(v.std(ddof=1)) if v.size > 1 else 0.0,
            'n': int(v.size)}


def main():
    # optional smoke switches:  python t76_sapso_allops.py --seeds 1 --ops Gabor
    seeds_limit = None
    ops_filter = None
    if '--seeds' in sys.argv:
        seeds_limit = int(sys.argv[sys.argv.index('--seeds') + 1])
    if '--ops' in sys.argv:
        ops_filter = sys.argv[sys.argv.index('--ops') + 1].split(',')
    use_ops = [(n, i) for n, i in OPS if ops_filter is None or n in ops_filter]

    out = {'protocol': 'A', 'method': 'SAPSO', 'k': 4,
           'classifiers': CLFS, 'operators': {}, 'datasets': {}}
    for op_name, si in use_ops:
        spec = hssp.SpatialSpec.from_dict(B.DEFAULT_SPATIAL[si])
        out['operators'][op_name] = spec.as_dict()
        for name, cfg, runs, method in JOBS:
            ds, splits, _scfg, _o = B.load_context(os.path.join(HERE, cfg))
            bands_map = B._read_selection_bands(os.path.join(ROOT, runs, 'selection.jsonl'), k=4)
            seeds_bands = sorted(bands_map.get(method, []))
            if seeds_limit:
                seeds_bands = seeds_bands[:seeds_limit]
            if not seeds_bands:
                print('[skip] %s: no %s k=4 rows' % (name, method), flush=True)
                continue
            acc_spectral = {c: [] for c in CLFS}
            acc_aug = {c: [] for c in CLFS}
            dim = None
            F_ = None
            for seed, bands in seeds_bands:
                tr = B._train(splits, seed)
                te = B._test(splits, seed)
                for c in CLFS:
                    e0 = evaluate.evaluate_subset(ds, tr, te, list(bands), evaluate.CLASSIFIERS[c])
                    acc_spectral[c].append(float(e0['OA']))
                aug, F, idx, _tag = B._augment_selected(ds, spec, bands, protocol='A')
                dim, F_ = len(idx), int(F)
                for c in CLFS:
                    eb = evaluate.evaluate_subset(aug, tr, te, idx, evaluate.CLASSIFIERS[c])
                    acc_aug[c].append(float(eb['OA']))
                print('  [%s][%s] seed %d: knn %.2f -> %.2f'
                      % (op_name, name, seed, acc_spectral['knn5'][-1], acc_aug['knn5'][-1]),
                      flush=True)
            out['datasets'].setdefault(name, {'n_bands_spectral': int(ds.n_bands),
                                              'n_seeds': len(seeds_bands),
                                              'spectral_only': {}, 'rows': {}})
            ds_rec = out['datasets'][name]
            ds_rec['spectral_only'] = {c: agg(acc_spectral[c]) for c in CLFS}
            ds_rec['rows'][op_name] = {
                'feature_dim': int(dim), 'F': int(F_),
                'OA': {c: agg(acc_aug[c]) for c in CLFS},
            }
            print('  [%s][%s] dim=%d F=%d knn %.2f+/-%.2f svm %.2f+/-%.2f rf %.2f+/-%.2f'
                  % (op_name, name, dim, F_,
                     agg(acc_aug['knn5'])['OA_mean'], agg(acc_aug['knn5'])['OA_std'],
                     agg(acc_aug['svm_rbf'])['OA_mean'], agg(acc_aug['svm_rbf'])['OA_std'],
                     agg(acc_aug['rf'])['OA_mean'], agg(acc_aug['rf'])['OA_std']), flush=True)

    dst = os.path.join(ROOT, 'output/runs/sapso_protocolA_allops.json')
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    with open(dst, 'w', encoding='utf-8') as fh:
        json.dump(out, fh, indent=2, ensure_ascii=False)

    # consistency check against the manuscript's existing EMP row
    try:
        ref = json.load(open(os.path.join(ROOT, 'output/runs/sapso3_protocolA.json'),
                             encoding='utf-8'))
        print('\n=== EMP reproduction check (must match to 2 decimals) ===')
        ok = True
        for name in out['datasets']:
            if 'EMP' not in out['datasets'][name].get('rows', {}):
                print('  (EMP not in this run; check skipped for %s)' % name)
                continue
            r = ref['datasets'][name]['plus_EMP']
            n = out['datasets'][name]['rows']['EMP']['OA']
            for c in CLFS:
                d = abs(r[c]['OA_mean'] - n[c]['OA_mean'])
                flag = 'OK' if d < 0.005 else 'MISMATCH'
                if d >= 0.005:
                    ok = False
                print('  %-16s %-8s ref %.4f new %.4f diff %.4f  %s'
                      % (name, c, r[c]['OA_mean'], n[c]['OA_mean'], d, flag))
        print('EMP reproduction:', 'PASS' if ok else 'FAIL')
    except FileNotFoundError:
        print('[warn] reference sapso3_protocolA.json not found; check skipped')

    print('[done] -> %s' % dst)


if __name__ == '__main__':
    main()
