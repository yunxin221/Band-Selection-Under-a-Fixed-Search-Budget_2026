"""T10 driver: runtime / model-footprint evidence for the UAV real-time claim (M-P2-1).

Complements ``batch7_8_run.py`` by measuring what that driver never recorded:
the wall-clock cost of the spatial-feature stage and of the classifier, and the
model footprint. Band-selection cost is read from the existing
``selection.jsonl`` instead of being paid again.

Feature-concatenation protocol (--protocol)
-------------------------------------------
The batch7-8 ``crosstable`` command used ``list(range(B)) + list(bands)`` as the
band index into an augmented cube laid out as ``[0..B-1]=spectral,
[B..B+F-1]=spatial``. Since ``bands`` always lies in ``[0, B-1]``, that selected
a *duplicate of spectral bands* and never reached the spatial block. Both
protocols below compute the spatial features on the **selected** sub-cube, which
is what makes band selection pay for itself downstream:

  A (compact)   X = [selected spectral bands] + [spatial features of the selected bands]
                -> dimension k + F. Shows the full compactness payoff.
  B (manuscript)X = [all spectral bands]      + [spatial features of the selected bands]
                -> dimension B + F. Conservative on accuracy; spatial stage still
                scales with k rather than B.

A is the honest end-to-end story; B is the safer accuracy story. Both are run by
default so the manuscript can report one and footnote the other.

Full-scene latency
------------------
Headline real-time metric is a full-scene inference pass (LongKou 550x400 =
220,000 px). For a brute-force KNN at high feature dimension this pass can run
long, so ``--full-image-limit`` subsamples with a fixed seed and extrapolates
linearly; the JSON records which path was taken so the table can be footnoted.

Usage
-----
  python t10_runtime_run.py profile --dataset configs/longkou.json \
      --runs output/runs/longkou_5cls --out output/runs/t10_longkou
  python t10_runtime_run.py profile --dataset configs/indian_pines.json \
      --runs output/runs/indian_pines --out output/runs/t10_indian
"""
from __future__ import annotations

import argparse
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from hsbs import spatial as hssp, evaluate, runner as hsrun          # noqa: E402
from hsbs import runtime_profile as rp                                # noqa: E402

DEFAULT_SPATIAL = os.path.join(HERE, 'configs', 'spatial_specs.json')
DEFAULT_CLASSIFIERS = ['knn5', 'svm_rbf', 'rf']


# --------------------------------------------------------------------- helpers
def _dump(out_dir: str, name: str, obj) -> str:
    os.makedirs(out_dir, exist_ok=True)
    p = os.path.join(out_dir, name)
    with open(p, 'w', encoding='utf-8') as fh:
        json.dump(obj, fh, indent=2, ensure_ascii=False)
    return p


def _train(splits, seed):
    for s in splits:
        if int(getattr(s, 'seed')) == int(seed):
            return s.train_idx
    return splits[0].train_idx


def _test(splits, seed):
    for s in splits:
        if int(getattr(s, 'seed')) == int(seed):
            return s.test_idx
    return splits[0].test_idx


def _read_selection(jsonl_path: str, k: int = 4) -> dict:
    """{method: {seed: {'bands': [...], 'runtime_s': float, 'nfe': int}}}"""
    out: dict = {}
    if not os.path.isfile(jsonl_path):
        return out
    with open(jsonl_path, 'r', encoding='utf-8') as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
            except Exception:
                continue
            if int(d.get('k', -1)) != int(k):
                continue
            b = d.get('bands_0based') or [x - 1 for x in d.get('bands_1based', [])]
            if not b:
                continue
            out.setdefault(str(d.get('method')), {})[int(d.get('seed', 0))] = {
                'bands': [int(x) for x in b],
                'runtime_s': float(d.get('runtime_s', float('nan'))),
                'nfe': int(d.get('nfe', 0) or 0),
            }
    return out


def _build_features(ds, spec: hssp.SpatialSpec, bands, protocol: str):
    """Return (aug_cube, feature_index_list, F, spectral_dim).

    Spatial features are ALWAYS computed on the selected sub-cube -- that is
    what makes band selection reduce downstream cost.
    """
    sub = ds.cube[:, :, list(bands)]
    feats = hssp.extract_features(sub, spec)
    F = int(feats.shape[-1])
    if protocol == 'A':
        cube = np.concatenate([sub, feats], axis=-1)
        idx = list(range(len(bands))) + list(range(len(bands), len(bands) + F))
        return np.ascontiguousarray(cube, dtype=np.float32), idx, F, len(bands)
    cube = np.concatenate([ds.cube, feats], axis=-1)
    idx = list(range(ds.n_bands)) + list(range(ds.n_bands, ds.n_bands + F))
    return np.ascontiguousarray(cube, dtype=np.float32), idx, F, ds.n_bands


def _maybe_subsample(X: np.ndarray, limit: int, seed: int = 0):
    """Deterministic subsample for the full-scene pass; returns (X, factor, note)."""
    n = int(X.shape[0])
    if limit and n > int(limit):
        rng = np.random.default_rng(seed)
        sel = np.sort(rng.choice(n, size=int(limit), replace=False))
        return X[sel], float(n) / float(int(limit)), 'subsampled %d/%d px (seed=%d), latency extrapolated x%.2f' % (
            int(limit), n, seed, n / float(int(limit)))
    return X, 1.0, 'full scene, no subsampling'


# --------------------------------------------------------------------- main command
def run_profile(args) -> dict:
    cfg_path = args.dataset
    ds, splits, _scfg, _out, _nj = hsrun.build_context(
        hsrun.load_config(cfg_path), seeds=args.seeds, verbose=False)

    with open(args.spatial, 'r', encoding='utf-8') as fh:
        specs_cfg = json.load(fh)
    op_list = specs_cfg.get('default_sweep') or list(specs_cfg['operators'].values())
    if args.operators:
        ops = args.operators
        want = set([o.strip().upper() for o in ops] if isinstance(ops, (list, tuple))
                   else [o.strip().upper() for o in str(ops).split(',')])
        op_list = [o for o in op_list if o.get('operator', '').upper() in want]

    sel = _read_selection(os.path.join(args.runs, 'selection.jsonl'), k=args.k)
    method = args.bands_method
    if method not in sel:
        avail = sorted(sel)
        if not avail:
            raise SystemExit('no k=%d selection records in %s' % (args.k, args.runs))
        method = avail[0]
        print('[warn] --bands-method %s not found; falling back to %s' % (args.bands_method, method))

    classifiers = [evaluate.CLASSIFIERS[c] for c in args.classifiers]
    results = {
        'dataset': ds.name,
        'n_bands': int(ds.n_bands),
        'cube_shape': [int(ds.height), int(ds.width), int(ds.n_bands)],
        'n_pixels': int(ds.n_pixels),
        'k': int(args.k),
        'bands_method': method,
        'protocol': args.protocol,
        'classifiers': list(args.classifiers),
        'selection_runtime_s': {},
        'spatial': [],
        'classification': [],
        'notes': [],
    }

    # ---- stage 1: band selection (reuse the recorded cost)
    for seed, rec in sorted(sel[method].items()):
        results['selection_runtime_s'][str(seed)] = rec['runtime_s']
    sel_vals = [v for v in results['selection_runtime_s'].values() if np.isfinite(v)]
    if sel_vals:
        results['selection_runtime_summary'] = {
            'mean_s': float(np.mean(sel_vals)),
            'std_s': float(np.std(sel_vals, ddof=1)) if len(sel_vals) > 1 else 0.0,
            'n': int(len(sel_vals)),
            'source': 'selection.jsonl (no re-run)'}

    # ---- stage 2: spatial feature construction
    print('[stage 2] spatial feature construction', flush=True)
    for sp_cfg in op_list:
        spec = hssp.SpatialSpec.from_dict(sp_cfg)
        bands0 = sel[method][sorted(sel[method])[0]]['bands']
        prof = rp.profile_spatial(ds.cube[:, :, bands0], spec, repeats=args.repeats)
        prof['ref'] = specs_cfg.get('operators', {}).get(
            str(spec.operator).upper(), {}).get('ref', '')
        results['spatial'].append(prof)
        print('  [%-5s] median %.3f s  -> %d feature bands'
              % (spec.operator, prof['median_s'], prof['n_feature_bands']), flush=True)

    # ---- stage 3: classification + footprint + full-scene latency
    print('[stage 3] classification timing', flush=True)
    for sp_cfg in op_list:
        spec = hssp.SpatialSpec.from_dict(sp_cfg)
        for seed in sorted(sel[method])[: args.max_seeds]:
            bands = sel[method][seed]['bands']
            aug_cube, idx, F, spec_dim = _build_features(ds, spec, bands, args.protocol)
            mat = aug_cube.reshape(ds.n_pixels, -1)[:, idx]
            tr, te = _train(splits, seed), _test(splits, seed)
            Xtr, Xte = mat[tr], mat[te]

            full = mat
            full, factor, note = _maybe_subsample(full, args.full_image_limit, seed=seed)
            if note not in results['notes']:
                results['notes'].append(note)

            for cspec in classifiers:
                rec = rp.profile_classifier(
                    cspec, Xtr, ds.labels()[tr], Xte,
                    standardize=True, full_image=full, block=args.block)
                if factor != 1.0 and 'full_image' in rec:
                    rec['full_image']['total_s_extrapolated'] = float(
                        rec['full_image']['total_s'] * factor)
                    rec['full_image']['extrapolated'] = True
                rec.update({'operator': spec.operator, 'seed': int(seed),
                            'protocol': args.protocol, 'F': F,
                            'spectral_dim': spec_dim,
                            'feature_dim': int(len(idx)),
                            'bands_1based': [int(b) + 1 for b in bands]})
                results['classification'].append(rec)
                fi = rec.get('full_image', {})
                print('  [%-5s seed=%s] %-8s fit %.3fs | test %.3fs | full-scene %s'
                      % (spec.operator, seed, cspec.label, rec['fit_s'],
                         rec['predict_test_s'],
                         ('%.2fs' % fi.get('total_s_extrapolated', fi.get('total_s')))
                         if fi else 'n/a'), flush=True)

    # ---- aggregate per (operator, classifier)
    grouped: dict = {}
    for r in results['classification']:
        grouped.setdefault((r['operator'], r['classifier']), []).append(r)
    results['summary'] = {}
    for (op, ckey), recs in sorted(grouped.items()):
        results['summary']['%s|%s' % (op, ckey)] = rp.summarize_timings(recs)

    _dump(args.out, 't10_runtime_summary.json', results)
    _write_md(args.out, results)
    print('[done] -> %s' % os.path.join(args.out, 't10_runtime_summary.json'), flush=True)
    return results


def _write_md(out_dir: str, results: dict) -> None:
    lines = ['# T10 runtime & model footprint -- %s' % results['dataset'],
             '',
             '- bands: **%s** (k=%d), protocol **%s**, classifiers: %s'
             % (results['bands_method'], results['k'], results['protocol'],
                ', '.join(results['classifiers'])),
             '- scene: %s = %s px'
             % ('x'.join(str(x) for x in results['cube_shape']),
                '{:,}'.format(results['n_pixels'])),
             '']
    ss = results.get('selection_runtime_summary')
    if ss:
        lines += ['## Stage 1 -- band selection (reused from selection.jsonl)',
                  '', 'mean **%.2f s** +/- %.2f (n=%d)' % (ss['mean_s'], ss['std_s'], ss['n']), '']

    lines += ['## Stage 2 -- spatial feature construction', '',
              '| operator | eta | lam | n_pc | median (s) | min (s) | max (s) | feature bands |',
              '|---|---|---|---|---|---|---|---|']
    for p in results['spatial']:
        lines.append('| %s | %s | %s | %d | %.3f | %.3f | %.3f | %d |'
                     % (p['operator'], p['eta'], p['lam'], p['n_pc'],
                        p['median_s'], p['min_s'], p['max_s'], p['n_feature_bands']))

    for op in sorted({r['operator'] for r in results['classification']}):
        rows = [r for r in results['classification'] if r['operator'] == op]
        lines += ['', '## Stage 3 -- classification (operator = %s, protocol %s)'
                  % (op, results['protocol']), '',
                  rp.runtime_table_markdown(rows), '',
                  rp.footprint_table_markdown(rows)]

    if results.get('notes'):
        lines += ['', '## Notes'] + ['- ' + n for n in results['notes']]
    with open(os.path.join(out_dir, 't10_runtime.md'), 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(lines) + '\n')


# --------------------------------------------------------------------- cli
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('cmd', choices=['profile'])
    ap.add_argument('--dataset', required=True)
    ap.add_argument('--runs', required=True, help='existing run dir with selection.jsonl')
    ap.add_argument('--out', required=True)
    ap.add_argument('--spatial', default=DEFAULT_SPATIAL)
    ap.add_argument('--operators', default=None,
                    help='comma list of morph/epf/gabor; default = all in spatial_specs.json')
    ap.add_argument('--bands-method', default='SAPSO')
    ap.add_argument('--k', type=int, default=4)
    ap.add_argument('--protocol', choices=['A', 'B'], default='B')
    ap.add_argument('--classifiers', default=','.join(DEFAULT_CLASSIFIERS))
    ap.add_argument('--seeds', default=None)
    ap.add_argument('--max-seeds', type=int, default=3,
                    help='cap seeds per operator: full-scene latency is expensive')
    ap.add_argument('--repeats', type=int, default=3)
    ap.add_argument('--full-image-limit', type=int, default=60000,
                    help='subsample the full-scene pass above this pixel count (0 = no limit)')
    ap.add_argument('--block', type=int, default=20000)
    args = ap.parse_args(argv)
    args.classifiers = [c.strip() for c in args.classifiers.split(',') if c.strip()]
    if args.operators:
        args.operators = [o.strip() for o in args.operators.split(',') if o.strip()]
    if args.cmd == 'profile':
        run_profile(args)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
