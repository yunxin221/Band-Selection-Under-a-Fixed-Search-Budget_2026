"""Live progress viewer + interruption diagnosis for run_pipeline.py.

Two modes:
  * default   : count the actual rows already written to the shared JSONL caches
    and report a live completion percentage. Works mid-method and even after a
    session compression -- just re-run this script.
  * --diagnose: print an interruption-troubleshooting report (also imported by
    run_watchdog.py to build last_interruption.json).

Usage:
  python progress.py <output_dir>
  python progress.py --diagnose <output_dir>
  python progress.py ../output/runs/longkou_5cls
"""
import argparse
import json
import os
import sys
from datetime import datetime, timezone


def _count_err(path, method=None):
    """Return (ok, err) row counts for `method` (or all) in a JSONL cache."""
    ok = err = 0
    if not os.path.isfile(path):
        return ok, err
    with open(path, 'r', encoding='utf-8') as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except json.JSONDecodeError:
                continue
            if method is not None and r.get('method') != method:
                continue
            if 'error' in r:
                err += 1
            else:
                ok += 1
    return ok, err


def diagnose_run(out_dir):
    """Build an interruption-troubleshooting report for a run directory.

    Reads run_manifest.json (expected per-method counts + status) and counts the
    actual rows already written to the shared JSONL caches. Returns a dict that
    run_watchdog.py can persist as last_interruption.json, and that --diagnose
    can print.
    """
    out_dir = os.path.abspath(out_dir)
    man_path = os.path.join(out_dir, 'run_manifest.json')
    sel_path = os.path.join(out_dir, 'selection.jsonl')
    cls_path = os.path.join(out_dir, 'classification.jsonl')
    prog_path = os.path.join(out_dir, 'progress.json')
    log_path = os.path.join(out_dir, 'run_pipeline.log')
    report = {'out_dir': out_dir}
    if not os.path.isfile(man_path):
        report['verdict'] = 'NO_MANIFEST'
        report['cause_guess'] = 'run_manifest.json 不存在：流水线尚未启动，或输出目录不对。'
        return report
    m = json.load(open(man_path, 'r', encoding='utf-8'))
    subtasks = m.get('subtasks', [])
    exp = m.get('expected', {})
    status = m.get('status', {})
    live = total = 0
    err_total = 0
    running = None
    per = []
    for meth in subtasks:
        e = exp.get(meth, {'sel': 0, 'cls': 0})
        s_ok, s_err = _count_err(sel_path, meth)
        c_ok, c_err = _count_err(cls_path, meth)
        err_total += s_err + c_err
        planned = e.get('sel', 0) + e.get('cls', 0)
        done = min(s_ok, e['sel']) + min(c_ok, e['cls'])
        live += done
        total += planned
        st = status.get(meth, '-')
        if st == 'running':
            running = meth
        elif st != 'done' and (s_ok < e['sel'] or c_ok < e['cls']):
            if running is None:
                running = meth
        per.append({'method': meth, 'sel_ok': s_ok, 'sel_exp': e['sel'],
                    'cls_ok': c_ok, 'cls_exp': e['cls'], 'sel_err': s_err,
                    'cls_err': c_err, 'status': st})
    pct = (live / total * 100.0) if total else 100.0
    report['percent'] = round(pct, 1)
    report['live'] = live
    report['total'] = total
    report['running_method'] = running
    report['error_rows'] = err_total
    report['per_method'] = per
    if os.path.isfile(prog_path):
        try:
            p = json.load(open(prog_path, 'r', encoding='utf-8'))
            report['progress_updated_at'] = p.get('updated_at')
        except Exception:
            pass
    signals = []
    if os.path.isfile(log_path):
        with open(log_path, 'r', encoding='utf-8', errors='replace') as fh:
            tail = fh.read().splitlines()[-40:]
        for ln in tail:
            if 'Traceback' in ln or '[FAIL]' in ln or 'Error' in ln:
                signals.append(ln.strip())
    report['log_signals'] = signals[-10:]
    if err_total > 0 and not signals:
        cause = ('缓存中存在 %d 个 error 行但无 traceback：通常是个别作业被兜底跳过，'
                 '不致命，可续跑。' % err_total)
    elif signals:
        cause = '日志末尾出现: %s —— 疑似代码层异常，需查看完整日志。' % ' | '.join(signals[:3])
    else:
        cause = ('无 [FAIL]/traceback、无 error 行但进度停滞 —— 进程被外部终止'
                 '（环境/沙箱/会话压缩），非代码崩溃，可安全续跑。')
    report['cause_guess'] = cause
    # Verdict: distinguish a genuinely *running* job from a *stalled* one.
    now = datetime.now(timezone.utc)
    age_min = None
    pua = report.get('progress_updated_at')
    if pua:
        try:
            ts = datetime.fromisoformat(pua.replace('Z', '+00:00'))
            age_min = (now - ts).total_seconds() / 60.0
        except Exception:
            age_min = None
    if live >= total:
        report['verdict'] = 'COMPLETE'
    elif running is not None and (age_min is None or age_min < 15):
        report['verdict'] = 'IN_PROGRESS'
    elif age_min is not None and age_min >= 15:
        report['verdict'] = 'STALLED_OR_INTERRUPTED'
    else:
        report['verdict'] = 'INCOMPLETE'
    if report['verdict'] == 'IN_PROGRESS':
        report['cause_guess'] = ('方法 %s 正在运行，进度 %.1f%% 持续推进（progress 更新于 %s），属正常进行中。'
                                 % (running, pct, report.get('progress_updated_at')))
    return report


def _print_diagnosis(r):
    print('=' * 60)
    print('中断排查报告 (diagnosis)')
    print('  out_dir      :', r.get('out_dir'))
    if r.get('verdict') == 'NO_MANIFEST':
        print('  结论        :', r.get('cause_guess'))
        print('=' * 60)
        return
    print('  进度        : %.1f%%  (%d/%d jobs)' % (r.get('percent', 0), r.get('live', 0), r.get('total', 0)))
    print('  运行中方法  :', r.get('running_method'))
    print('  error 行    :', r.get('error_rows'))
    print('  进度更新于  :', r.get('progress_updated_at'))
    print('  结论        :', r.get('verdict'))
    print('  排查        :', r.get('cause_guess'))
    if r.get('log_signals'):
        print('  日志信号    :')
        for s in r['log_signals']:
            print('     ', s)
    print('  PER-METHOD:')
    for p in r.get('per_method', []):
        print('    %-10s sel %4d/%-4d cls %5d/%-5d err %d [%s]'
              % (p['method'], p['sel_ok'], p['sel_exp'], p['cls_ok'], p['cls_exp'],
                 p['sel_err'] + p['cls_err'], p['status']))
    print('=' * 60)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog='python progress.py')
    ap.add_argument('out', nargs='?', default='.')
    ap.add_argument('--diagnose', action='store_true',
                    help='print an interruption-troubleshooting report')
    a = ap.parse_args(argv)
    out = os.path.abspath(a.out)
    if a.diagnose:
        _print_diagnosis(diagnose_run(out))
        return 0

    man = os.path.join(out, 'run_manifest.json')
    prog = os.path.join(out, 'progress.json')
    if not os.path.isfile(man):
        print('no run_manifest.json in %s -- pipeline has not started' % out)
        return 1
    m = json.load(open(man, 'r', encoding='utf-8'))
    subtasks = m.get('subtasks', [])
    exp = m.get('expected', {})
    status = m.get('status', {})
    sel_path = os.path.join(out, 'selection.jsonl')
    cls_path = os.path.join(out, 'classification.jsonl')

    live = total = 0
    per_method = []
    for meth in subtasks:
        e = exp.get(meth, {'sel': 0, 'cls': 0})
        s_act, _ = _count_err(sel_path, meth)
        c_act, _ = _count_err(cls_path, meth)
        done = min(s_act, e.get('sel', 0)) + min(c_act, e.get('cls', 0))
        planned = e.get('sel', 0) + e.get('cls', 0)
        live += done
        total += planned
        per_method.append((meth, s_act, e.get('sel', 0), c_act, e.get('cls', 0), status.get(meth, '-')))

    pct = (live / total * 100.0) if total else 100.0
    bar = int(round(pct / 5))
    print('=' * 60)
    print('LIVE PROGRESS: %.1f%%   jobs %d / %d' % (pct, live, total))
    print('  [%s%s]' % ('#' * bar, '-' * (20 - bar)))
    if os.path.isfile(prog):
        p = json.load(open(prog, 'r', encoding='utf-8'))
        if p.get('running_method'):
            print('running        : %s' % p['running_method'])
        print('updated(prog)   : %s' % p.get('updated_at'))
    n_done = len([mm for mm in subtasks if status.get(mm) == 'done'])
    print('methods verified: %d/%d' % (n_done, len(subtasks)))
    print('=' * 60)
    print('\nPER-METHOD (actual / expected):')
    for meth, s_act, s_exp, c_act, c_exp, st in per_method:
        mark = 'OK' if (s_act >= s_exp and c_act >= c_exp) else ''
        print('  %-10s sel %4d/%-4d  cls %5d/%-5d  [%s] %s'
              % (meth, s_act, s_exp, c_act, c_exp, st, mark))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
